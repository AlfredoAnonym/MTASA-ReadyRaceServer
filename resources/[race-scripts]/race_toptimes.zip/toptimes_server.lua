--
-- toptimes_server.lua
--

SToptimesManager = {}
SToptimesManager.__index = SToptimesManager
SToptimesManager.instances = {}


---------------------------------------------------------------------------
-- Server Interface
---------------------------------------------------------------------------

addEvent('onMapStarting')
addEventHandler('onMapStarting', root,
	function(mapInfo, mapOptions, gameOptions)
		if g_SToptimesManager then
			g_SToptimesManager:setModeAndMap( mapInfo.modename, mapInfo.name, gameOptions.statsKey )
		end
	end
)

addEvent('onPlayerFinish')
addEventHandler('onPlayerFinish', root,
	function(rank, time)
		if g_SToptimesManager then
			g_SToptimesManager:playerFinished( source, time)
		end
	end
)

addEventHandler('onResourceStop', resourceRoot,
	function()
		if g_SToptimesManager then
			g_SToptimesManager:unloadingMap()
		end
	end
)

addEventHandler('onPlayerQuit', root,
	function()
		if g_SToptimesManager then
			g_SToptimesManager:removePlayerFromUpdateList(source)
			g_SToptimesManager:unqueueUpdate(source)
		end
	end
)

addEventHandler('onResourceStart', resourceRoot,
	function()
		local raceInfo = getRaceInfo()
		if raceInfo and g_SToptimesManager then
			g_SToptimesManager:setModeAndMap( raceInfo.mapInfo.modename, raceInfo.mapInfo.name, raceInfo.gameOptions.statsKey )
		end
	end
)

function getRaceInfo()
	local raceResRoot = getResourceRootElement( getResourceFromName( "race" ) )
	return raceResRoot and getElementData( raceResRoot, "info" )
end

addEvent("onPlayerToptimeImprovement")

---------------------------------------------------------------------------
-- SToptimesManager
---------------------------------------------------------------------------
function SToptimesManager:create()
	local id = #SToptimesManager.instances + 1
	SToptimesManager.instances[id] = setmetatable(
		{
			id = id,
			playersWhoWantUpdates	= {},
			updateQueue			 = {},
			serviceQueueTimer		= nil,
			displayTopCount		 = 8,
            serverLimit          = 35,      -- Always send 35 items so client can choose how many to view
			mapTimes				= nil,
			serverRevision			= 0,
		},
		self
	)
	SToptimesManager.instances[id]:postCreate()
	return SToptimesManager.instances[id]
end

function SToptimesManager:destroy()
	SToptimesManager.instances[self.id] = nil
	self.id = 0
end

function SToptimesManager:postCreate()
	cacheSettings()
	self.displayTopCount = g_Settings.numtimes
end

function SToptimesManager:setModeAndMap( raceModeName, mapName, statsKey )
	outputDebug( 'TOPTIMES', 'SToptimesManager:setModeAndMap ' .. raceModeName .. '<>' .. mapName )
	self.playersWhoWantUpdates = {}
	self.updateQueue = {}
	if self.serviceQueueTimer then
		killTimer(self.serviceQueueTimer)
	end
	self.serviceQueueTimer = nil

	if self.mapTimes then
		self.mapTimes:flush()
		self.mapTimes:destroy()
	end

	self.mapTimes = SMaptimes:create( raceModeName, mapName, statsKey )
	self.mapTimes:load()
	self:updateTopText()
end

function SToptimesManager:unloadingMap()
	if self.mapTimes then
		self.mapTimes:flush()
	end
end

function SToptimesManager:playerFinished( player, newTime, dateRecorded )
	if getElementData ( player, "toptimes" ) == "off" then return end
	if not self.mapTimes then return end

	dateRecorded = dateRecorded or getRealDateTimeNowString()

	local oldTime	= self.mapTimes:getTimeForPlayer( player )
	local newPos	= self.mapTimes:getPositionForTime( newTime, dateRecorded )

	if not oldTime or newTime < oldTime then
		local oldPos = self.mapTimes:getIndexForPlayer( player )
		triggerEvent("onPlayerToptimeImprovement", player, newPos, newTime, oldPos, oldTime, self.displayTopCount, self.mapTimes:getValidEntryCount() )

		if newPos <= self.displayTopCount then
			outputDebug( 'TOPTIMES', getPlayerName(player) .. ' got toptime position ' .. newPos )
		end

		self.mapTimes:setTimeForPlayer( player, newTime, dateRecorded )

		if newPos <= self.serverLimit then
			self:updateTopText()
		end
	end
end

function SToptimesManager:updateTopText()
	if not self.mapTimes then return end
	
    -- Send 35 to client
	self.toptimesDataForMap = self.mapTimes:getToptimes( self.serverLimit )
	self.serverRevision = self.serverRevision + 1

	for i,player in ipairs(self.playersWhoWantUpdates) do
		self:queueUpdate(player)
	end
end

function SToptimesManager:onServiceQueueTimer()
	if #self.updateQueue > 0 and self.mapTimes then
		local player = self.updateQueue[1]
		local playerPosition = self.mapTimes:getIndexForPlayer( player )
		clientCall( player, 'onServerSentToptimes', self.toptimesDataForMap, self.serverRevision, playerPosition );
	end
	table.remove(self.updateQueue,1)
	if #self.updateQueue < 1 then
		killTimer(self.serviceQueueTimer)
		self.serviceQueueTimer = nil
	end
end

function SToptimesManager:addPlayerToUpdateList( player )
	if not table.find( self.playersWhoWantUpdates, player) then
		table.insert( self.playersWhoWantUpdates, player )
	end
end

function SToptimesManager:removePlayerFromUpdateList( player )
	table.removevalue( self.playersWhoWantUpdates, player )
end

function SToptimesManager:queueUpdate( player )
	if not table.find( self.updateQueue, player) then
		table.insert( self.updateQueue, player )
	end
	if not self.serviceQueueTimer then
		self.serviceQueueTimer = setTimer( function() self:onServiceQueueTimer() end, 100, 0 )
	end
end

function SToptimesManager:unqueueUpdate( player )
	table.removevalue( self.updateQueue, player )
end

function SToptimesManager:doOnClientRequestToptimesUpdates( player, bOn, clientRevision )
	if bOn then
		self:addPlayerToUpdateList(player)
		if clientRevision ~= self.serverRevision then
			self:queueUpdate(player)
		end
	else
		self:removePlayerFromUpdateList(player)
		self:unqueueUpdate(player)
	end
end

addEvent('onClientRequestToptimesUpdates', true)
addEventHandler('onClientRequestToptimesUpdates', root,
	function( bOn, clientRevision )
		g_SToptimesManager:doOnClientRequestToptimesUpdates( source, bOn, clientRevision )
	end
)

---------------------------------------------------------------------------
-- Commands
---------------------------------------------------------------------------
addCommandHandler( "deletetime",
	function( player, cmd, place )
		if not _TESTING and not isPlayerInACLGroup(player, g_Settings.admingroup) then
			return
		end
		if g_SToptimesManager and g_SToptimesManager.mapTimes then
			local row = g_SToptimesManager.mapTimes:deletetime(place)
			if row then
				g_SToptimesManager:updateTopText()
				local placeText = place and "#" .. tostring(place) .. " " or ""
				local slotDesc = "'" .. placeText .. "[" .. tostring(row.timeText) .. "] " .. tostring(row.playerName) .. "'"
				local adminName = tostring(getPlayerName(player))
				outputChatBox( "Top time " .. slotDesc .. " deleted by " .. adminName )
			end
		end
	end
)

---------------------------------------------------------------------------
-- Settings
---------------------------------------------------------------------------
function cacheSettings()
	g_Settings = {}
	g_Settings.numtimes		= getNumber('numtimes',8)
	g_Settings.startshow	= getBool('startshow',false)
	g_Settings.gui_x		= getNumber('gui_x',0.56)
	g_Settings.gui_y		= getNumber('gui_y',0.02)
	g_Settings.admingroup	= getString("admingroup","Admin")
end

addEvent ( "onSettingChange" )
addEventHandler('onSettingChange', resourceRoot,
	function(name, oldvalue, value, playeradmin)
		cacheSettings()
		if g_SToptimesManager then
			g_SToptimesManager.displayTopCount = g_Settings.numtimes
			g_SToptimesManager:updateTopText()
		end
		clientCall(root,'updateSettings', g_Settings, playeradmin)
	end
)

addEvent('onLoadedAtClient_tt', true)
addEventHandler('onLoadedAtClient_tt', root,
	function()
		clientCall(source,'updateSettings', g_Settings)
		local raceInfo = getRaceInfo()
		if raceInfo then
		    triggerClientEvent('onClientSetMapName', source, raceInfo.mapInfo.name )
		end
	end
)

g_SToptimesManager = SToptimesManager:create()