--
-- toptimes_client.lua
--

CToptimes = {}
CToptimes.__index = CToptimes
CToptimes.instances = {}
g_Settings = {}

---------------------------------------------------------------------------
-- Client Interface
---------------------------------------------------------------------------

addEventHandler('onClientResourceStart', resourceRoot,
	function()
		triggerServerEvent('onLoadedAtClient_tt', localPlayer)
	end
)

addEvent('onClientMapStarting', true)
addEventHandler('onClientMapStarting', root,
	function(mapinfo)
		if g_CToptimes then g_CToptimes:onMapStarting(mapinfo) end
	end
)

addEvent('onClientMapStopping', true)
addEventHandler('onClientMapStopping', root,
	function()
		if g_CToptimes then g_CToptimes:onMapStopping() end
	end
)

addEvent('onClientPlayerFinish', true)
addEventHandler('onClientPlayerFinish', root,
	function()
		if g_CToptimes then g_CToptimes:doAutoShow() end
	end
)

addEvent('onClientSetMapName', true)
addEventHandler('onClientSetMapName', root,
	function(manName)
		if g_CToptimes then g_CToptimes:setWindowTitle(manName) end
	end
)

function updateSettings(settings, playeradmin)
	if g_CToptimes then
		if settings and settings.gui_x and settings.gui_y then
			g_CToptimes:setWindowPosition( settings.gui_x, settings.gui_y )
			g_CToptimes.startshow = settings.startshow
			
			-- Only set default if user hasn't set custom tpos yet
			if not g_CToptimes.userNumTimes then
				g_CToptimes.userNumTimes = settings.numtimes or 8
			end
		end
		if playeradmin == localPlayer then
			g_CToptimes:doToggleToptimes(true)
		end
	end
end

---------------------------------------------------------------------------
-- CToptimes Implementation
---------------------------------------------------------------------------
function CToptimes:create()
	local id = #CToptimes.instances + 1
	CToptimes.instances[id] = setmetatable(
		{
			id = id,
			bManualShow		= false,
			bAutoShow		= false,
			bGettingUpdates = false,
			listStatus		= 'Empty',
			gui				= {},
			lastSeconds		= 0,
			targetFade		= 0,
			currentFade		= 0,
			autoOffTimer	= Timer:create(),
			userNumTimes    = 8, -- Default to 8 lines
			toptimesData    = {}, 
			myPosition      = 0,
		},
		self
	)

	CToptimes.instances[id]:postCreate()
	return CToptimes.instances[id]
end

function CToptimes:destroy()
	self:setHotKey(nil)
	self:closeWindow()
	self.autoOffTimer:destroy()
	CToptimes.instances[self.id] = nil
	self.id = 0
end

function CToptimes:postCreate()
	self:openWindow()
	self:setWindowPosition( 0.7, 0.02 )
	self:setHotKey('F5')
end

function CToptimes:openWindow ()
	if self.gui['container'] then return end

	self.size = {}
	self.size.x = 420 
	self.size.y = 46 + 15 * 8

	local sizeX = self.size.x
	local sizeY = self.size.y

	self.gui['windowbg'] = guiCreateStaticImage(100, 100, sizeX, sizeY, 'img/timepassedbg.png', false, nil)
	guiSetAlpha(self.gui['windowbg'], 0.4)
	guiSetVisible( self.gui['windowbg'], false )

	self.gui['container'] = guiCreateStaticImage(0,0,1,1, 'img/blank.png', true, self.gui['windowbg'])
	guiSetProperty ( self.gui['container'], 'InheritsAlpha', 'false' )

	self.gui['bar'] = guiCreateStaticImage(0, 0, sizeX, 18, 'img/timepassedbg.png', false, self.gui['container'])
	guiSetAlpha(self.gui['bar'], 0.4)

	self.gui['title'] = guiCreateLabel(0, 1, sizeX, 15, 'Top Times - ', false, self.gui['container'] )
	guiLabelSetHorizontalAlign ( self.gui['title'], 'center' )
	guiSetFont(self.gui['title'], 'default-bold-small')
	guiLabelSetColor ( self.gui['title'], 220, 220, 225 )

	local headerY = 21
	local hColor = {192, 192, 192}
	
	self.gui['hPos'] = guiCreateLabel(10, headerY, 30, 15, "Pos", false, self.gui['container'])
	self.gui['hName'] = guiCreateLabel(45, headerY, 120, 15, "Name", false, self.gui['container'])
	self.gui['hFlag'] = guiCreateLabel(170, headerY, 30, 15, "Flag", false, self.gui['container'])
	self.gui['hTime'] = guiCreateLabel(205, headerY, 60, 15, "Time", false, self.gui['container'])
	self.gui['hDiff'] = guiCreateLabel(270, headerY, 60, 15, "Diff", false, self.gui['container'])
	self.gui['hDate'] = guiCreateLabel(335, headerY, 80, 15, "Date", false, self.gui['container'])
	
	local headers = {self.gui['hPos'], self.gui['hName'], self.gui['hFlag'], self.gui['hTime'], self.gui['hDiff'], self.gui['hDate']}
	for _, lbl in ipairs(headers) do
		guiSetFont(lbl, 'default-small')
		guiLabelSetColor(lbl, unpack(hColor))
	end

	self.gui['headerul'] = guiCreateLabel(0, 21, sizeX, 15, string.rep('_', 58), false, self.gui['container'] )
	guiLabelSetHorizontalAlign ( self.gui['headerul'], 'center' )
	guiLabelSetColor ( self.gui['headerul'], 192, 192, 192 )

	self.gui['paneLoading'] = guiCreateStaticImage(0,0,1,1, 'img/blank.png', true, self.gui['container'])

	self.gui['busy'] = guiCreateLabel(sizeX/4, 38, sizeX/2, 15, 'Please wait', false, self.gui['paneLoading'] )
	self.gui['busy2'] = guiCreateLabel(sizeX/4, 53, sizeX/2, 15, 'until next map', false, self.gui['paneLoading'] )
	guiLabelSetHorizontalAlign ( self.gui['busy'], 'center' )
	guiLabelSetHorizontalAlign ( self.gui['busy2'], 'center' )
	guiSetFont(self.gui['busy'], 'default-bold-small')
	guiSetFont(self.gui['busy2'], 'default-bold-small')

	self.gui['paneTimes'] = guiCreateStaticImage(0,0,1,1, 'img/blank.png', true, self.gui['container'])
	
	self.gui['rows'] = {}
	self:updateLabelCount(8)
end

function CToptimes:closeWindow ()
	destroyElement( self.gui['windowbg'] )
	self.gui = {}
end

function CToptimes:setWindowPosition ( gui_x, gui_y )
	if self.gui['windowbg'] then
		local screenWidth, screenHeight = guiGetScreenSize()
		local posX, posY
		local posXCurve = { {0, 0}, {0.7, screenWidth/2 + 63}, {1, screenWidth - self.size.x} }
		local posYCurve = { {0, 0}, {0.02, 14}, {1, screenHeight - self.size.y} }
		posX = math.evalCurve( posXCurve, gui_x )
		posY = math.evalCurve( posYCurve, gui_y )
		guiSetPosition( self.gui['windowbg'], posX, posY, false )
	end
end

function CToptimes:setWindowTitle( mapName )
	if self.gui['title'] then
		guiSetText ( self.gui['title'], 'Top Times - ' .. mapName )
		guiSetVisible (self.gui['busy2'], false)
	end
end

function CToptimes:setHotKey ( hotkey )
	if self.hotkey then unbindKey ( self.hotkey, 'down', "showtimes" ) end
	self.hotkey = hotkey
	if self.hotkey then bindKey ( self.hotkey, 'down', "showtimes" ) end
end

function CToptimes:onMapStarting(mapinfo)
	self.bAutoShow			= false
	self.bGettingUpdates	= false
	self.listStatus		 = 'Empty'
	self.clientRevision	 = -1
	self.toptimesData    = {}
	self:updateShow()
	self:setWindowTitle( mapinfo.name )
	if self.startshow then self:doToggleToptimes( true ) end
end

function CToptimes:onMapStopping()
	self.bAutoShow			= false
	self.bGettingUpdates	= false
	self.listStatus		 = 'Empty'
	self.clientRevision	 = -1
	self:doToggleToptimes(false)
	self:setWindowTitle( '' )
end

function CToptimes:doAutoShow()
	self.bAutoShow = true
	self:updateShow()
end

function CToptimes:updateShow()
	local bShowAny = self.bAutoShow or self.bManualShow
	self:enableToptimeUpdatesFromServer( bShowAny )

	if not bShowAny then
		self.targetFade = 0
	elseif not self.bManualShow and self.listStatus ~= 'Full' then
		return true 
	else
		local bShowLoading	= self.listStatus=='Loading'
		local bShowTimes	= self.listStatus=='Full'

		self.targetFade = 1
		guiSetVisible (self.gui['paneLoading'], bShowLoading)
		guiSetVisible (self.gui['paneTimes'], bShowTimes)
	end
end

function CToptimes:enableToptimeUpdatesFromServer( bOn )
	if bOn ~= self.bGettingUpdates then
		self.bGettingUpdates = bOn
		triggerServerEvent('onClientRequestToptimesUpdates', localPlayer, bOn, self.clientRevision )
	end
	if self.bGettingUpdates and self.listStatus == 'Empty' then
		self.listStatus = 'Loading'
	end
end

-- Create Row GUI elements
function CToptimes:createRow(yIndex)
	local y = yIndex
	local parent = self.gui['paneTimes']
	local rowY = 38 + 15 * (y - 1)
	
	local row = {}
	
	row.pos = guiCreateLabel(10, rowY, 30, 15, "", false, parent)
	guiSetFont(row.pos, 'default-bold-small')
	
	row.name = guiCreateLabel(45, rowY, 120, 15, "", false, parent)
	guiSetFont(row.name, 'default-bold-small')
	
	row.flag = guiCreateStaticImage(170, rowY + 2, 16, 11, "img/blank.png", false, parent)
	
	row.time = guiCreateLabel(205, rowY, 60, 15, "", false, parent)
	guiSetFont(row.time, 'default-bold-small')
	
	row.diff = guiCreateLabel(270, rowY, 60, 15, "", false, parent)
	guiSetFont(row.diff, 'default-bold-small')
	
	row.date = guiCreateLabel(335, rowY, 80, 15, "", false, parent)
	guiSetFont(row.date, 'default-bold-small')
	
	return row
end

function CToptimes:updateLabelCount(numLines)
	local t = self.gui['rows']
	
	while #t < numLines do
		table.insert(t, self:createRow(#t + 1))
	end
	
	while #t > numLines do
		local row = table.popLast(t)
		destroyElement(row.pos)
		destroyElement(row.name)
		destroyElement(row.flag)
		destroyElement(row.time)
		destroyElement(row.diff)
		destroyElement(row.date)
	end
end

function CToptimes:formatDiff(ms)
    if ms == 0 then return "" end
    local minutes = math.floor(ms / 60000)
    ms = ms - minutes * 60000
    local seconds = math.floor(ms / 1000)
    local centi = ms - seconds * 1000
    return string.format("+%02d:%02d:%03d", minutes, seconds, centi)
end

function CToptimes:doOnServerSentToptimes( data, serverRevision, playerPosition )
    self.toptimesData = data
    self.myPosition = playerPosition
    self:refreshView()
    
	self.clientRevision = serverRevision
	self.listStatus = 'Full'
	self:updateShow()
end

function CToptimes:refreshView()
    local data = self.toptimesData or {}
    
    -- FORCE the list to show exactly userNumTimes, regardless of data size
    local displayCount = math.clamp(1, self.userNumTimes, 35)
    
    -- Resize window
    self.size.y = 46 + 15 * displayCount
	guiSetSize( self.gui['windowbg'], self.size.x, self.size.y, false )
    
    self:updateLabelCount(displayCount)
    
    local firstTime = 0
    if data[1] then firstTime = data[1].timeMs end
    
    for i=1, displayCount do
        local row = self.gui['rows'][i]
        local entry = data[i] -- This might be nil if we have empty slots
        
        guiSetText(row.pos, i .. ".")
        
        if entry then
            -- DATA EXISTS
            guiSetText(row.name, entry.playerName)
            guiSetText(row.time, entry.timeText)
            
            -- Date
            local dateShort = string.sub(entry.dateRecorded, 1, 10)
            guiSetText(row.date, dateShort)
            
            -- Diff
            if i == 1 then
                guiSetText(row.diff, "")
            else
                local diff = entry.timeMs - firstTime
                guiSetText(row.diff, self:formatDiff(diff))
            end
            
            -- Flag: Use ip2c path as requested
            local cCode = string.lower(entry.country or "xx")
            local path = ":ip2c/client/images/flags/"..cCode..".png"
            if fileExists(path) then 
                guiSetVisible(row.flag, true)
                guiStaticImageLoadImage(row.flag, path)
            else
                guiSetVisible(row.flag, false)
            end

            -- Colors
            local r, g, b = 255, 255, 255
            
            if i == 1 then r, g, b = 255, 215, 0    -- Gold
            elseif i == 2 then r, g, b = 192, 192, 192 -- Silver
            elseif i == 3 then r, g, b = 205, 127, 50  -- Bronze
            end
            
            guiLabelSetColor(row.pos, r, g, b)
            guiLabelSetColor(row.name, r, g, b)
            guiLabelSetColor(row.time, r, g, b)
            guiLabelSetColor(row.date, 150, 150, 150)
            
            -- Split Color (Red)
            guiLabelSetColor(row.diff, 255, 100, 100)
            
            -- Self Highlight
            if i == self.myPosition then
                 guiLabelSetColor(row.name, 0, 255, 255)
                 guiLabelSetColor(row.pos, 0, 255, 255)
            end
        else
            -- DATA IS EMPTY
            guiSetText(row.name, "-- Empty --")
            guiSetText(row.time, "")
            guiSetText(row.diff, "")
            guiSetText(row.date, "")
            guiSetVisible(row.flag, false)
            
            -- Reset Colors
            guiLabelSetColor(row.pos, 255, 255, 255)
            guiLabelSetColor(row.name, 150, 150, 150) -- Gray for empty
        end
    end
end

function onServerSentToptimes( data, serverRevision, playerPosition )
	g_CToptimes:doOnServerSentToptimes( data, serverRevision, playerPosition )
end

function CToptimes:doOnClientRender()
	if self.targetFade == self.currentFade then return end
	local currentSeconds = getTickCount() / 1000
	local deltaSeconds = currentSeconds - self.lastSeconds
	self.lastSeconds = currentSeconds
	deltaSeconds = math.clamp( 0, deltaSeconds, 1/25 )
	local fadeSpeed = self.targetFade < self.currentFade and 2 or 6
	local maxChange = deltaSeconds * fadeSpeed
	local dif = self.targetFade - self.currentFade
	dif = math.clamp( -maxChange, dif, maxChange )
	self.currentFade = self.currentFade + dif
	guiSetAlpha( self.gui['windowbg'], self.currentFade * 0.4 )
	guiSetAlpha( self.gui['container'], self.currentFade)
	guiSetVisible( self.gui['windowbg'], self.currentFade > 0 )
end

addEventHandler ( 'onClientRender', root,
	function(...)
		if g_CToptimes then g_CToptimes:doOnClientRender(...) end
	end
)

function CToptimes:doToggleToptimes( bOn )
	self.autoOffTimer:killTimer()
	if bOn ~= nil then
		self.bManualShow = bOn
	else
		self.bManualShow = not self.bManualShow
	end
	if self.bManualShow then
		self.autoOffTimer:setTimer( function() self:doToggleToptimes(false) end, 15000, 1 )
	end
	self:updateShow()
end

---------------------------------------------------------------------------
-- Commands
---------------------------------------------------------------------------

function onHotKey()
	if g_CToptimes then g_CToptimes:doToggleToptimes() end
end
addCommandHandler ( "showtimes", onHotKey )

addCommandHandler("tpos", 
    function(cmd, count)
        count = tonumber(count)
        if not count then
            outputChatBox("Usage: /tpos [number 1-35]", 255, 255, 0)
            return
        end
        
        if count < 1 then count = 1 end
        if count > 35 then count = 35 end
        
        if g_CToptimes then
            g_CToptimes.userNumTimes = count
            g_CToptimes:refreshView() -- Refresh immediately
            outputChatBox("Toptimes display count set to " .. count, 0, 255, 0)
        end
    end
)

addCommandHandler('doF5',
	function(player,command,...)
		if g_CToptimes then g_CToptimes:doToggleToptimes() end
	end
)

g_CToptimes = CToptimes:create()