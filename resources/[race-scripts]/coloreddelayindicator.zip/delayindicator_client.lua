local g_screenX,g_screenY = guiGetScreenSize()
local g_Root = getRootElement()
local g_ResRoot = getResourceRootElement(getThisResource())
local g_Me = getLocalPlayer()

local DISTANCE_FRONT_BEHIND = 0.03
local TIME_TO_DISPLAY = 2500
local SCALE = (g_screenY > 768) and 1.5 or 1.0

local frontTick, behindTick
local delayDisplayFront = dxText:create("", 0.5, 0.87, true, "default-bold", SCALE)
local delayDisplayBehind = dxText:create("", 0.5, 0.93, true, "default-bold", SCALE)

delayDisplayFront:type("shadow", 1)
delayDisplayBehind:type("shadow", 1)
delayDisplayFront:colorCode(true)
delayDisplayBehind:colorCode(true)

addEvent("showDelay", true)
addEventHandler("showDelay", g_Root,
    function(delayTime, optional)
        if tonumber(optional) then
            -- Behind someone (Green gap)
            local cps = getElementData(g_Me, "race.checkpoint") - optional
            local cpText = (cps < 2) and "" or "(-"..cps.."CPs) "
            delayDisplayBehind:text("-"..msToTime(delayTime).." "..cpText.."#FFFFFF"..addTeamColor(source))
            delayDisplayBehind:color(0, 255, 0) 
            delayDisplayBehind:visible(true)
            behindTick = getTickCount()
            setTimer(hideDelayDisplay, TIME_TO_DISPLAY, 1, false)

        elseif type(optional) == "table" then
            -- Rank 1: World Record Logic
            if delayTime >= 0 then
                delayDisplayFront:text("-"..msToTime(delayTime).." WORLD RECORD")
                delayDisplayFront:color(0, 255, 0) -- Green for beating record
            else
                delayDisplayFront:text("+"..msToTime(math.abs(delayTime)).." record #"..optional[1])
                delayDisplayFront:color(255, 0, 0) -- Red for being slower
            end
            delayDisplayFront:visible(true)
            frontTick = getTickCount()
            setTimer(hideDelayDisplay, TIME_TO_DISPLAY, 1, true)
        else
            -- Follower (Red gap)
            delayDisplayFront:text("+"..msToTime(delayTime).." #FFFFFF"..addTeamColor(source))
            delayDisplayFront:color(255, 0, 0)
            delayDisplayFront:visible(true)
            frontTick = getTickCount()
            setTimer(hideDelayDisplay, TIME_TO_DISPLAY, 1, true)
        end
    end
)

function hideDelayDisplay(front)
    if front == "both" then
        delayDisplayFront:visible(false)
        delayDisplayBehind:visible(false)
    elseif front then
        if frontTick and (getTickCount() - frontTick) >= TIME_TO_DISPLAY then delayDisplayFront:visible(false) end
    else
        if behindTick and (getTickCount() - behindTick) >= TIME_TO_DISPLAY then delayDisplayBehind:visible(false) end
    end
end

function addTeamColor(player)
    if not isElement(player) then return "Player" end
    local r,g,b = 255, 255, 255
    local team = getPlayerTeam(player)
    if team then r,g,b = getTeamColor(team) end
    return string.format("#%02X%02X%02X%s", r, g, b, getPlayerName(player))
end

function msToTime(ms)
    if not ms then return "0:00:000" end
    ms = math.abs(ms)
    local minutes = math.floor(ms / 60000)
    local seconds = math.floor((ms % 60000) / 1000)
    local centi = math.floor(ms % 1000)
    return string.format("%d:%02d:%03d", minutes, seconds, centi)
end

addEventHandler("onClientResourceStart", resourceRoot, function()
    triggerServerEvent("onClientShowCPDelays", resourceRoot)
end)