local g_Root = getRootElement()
local g_ResRoot = getResourceRootElement(getThisResource())

local mapName
local allCpTimes = {} 
local topTimeInterims
local topTimeRankPlayer = {10, "N/A"} 
local lastPlayer = {} 
local showClientDelays = {}

addEventHandler('onResourceStart', g_ResRoot,
    function()
        executeSQLQuery("CREATE TABLE IF NOT EXISTS mapinterims (mapname TEXT, playername TEXT, interims TEXT)")
        executeSQLQuery("CREATE UNIQUE INDEX IF NOT EXISTS IDX_MAPINTERIMS_MAPNAME on mapinterims(mapname)")
        updateMapNames()
        updatetopTimeInterims()
    end
)

addEventHandler('onGamemodeMapStart', g_Root,
    function(mapres)
        mapName = getResourceName(mapres)
        allCpTimes = {}
        topTimeInterims = nil
        topTimeRankPlayer = {10, "N/A"}
        lastPlayer = {}

        local sql = executeSQLQuery("SELECT playername, interims FROM mapinterims WHERE mapname = ?", mapName )
        if sql and #sql > 0 then
            topTimeRankPlayer = split(sql[1].playername, string.byte(' '))
            topTimeInterims = split(sql[1].interims, string.byte(','))
            topTimeRankPlayer[1] = tonumber(topTimeRankPlayer[1])
        end
    end
)

addEvent('onPlayerReachCheckpoint')
addEventHandler('onPlayerReachCheckpoint', g_Root,
    function(checkpointNum, timePassed)
        timePassed = math.floor(timePassed)
        if not allCpTimes[source] then allCpTimes[source] = {} end
        allCpTimes[source][checkpointNum] = timePassed
        
        local rank = getElementData(source, "race rank")
        
        if rank == 1 then
            if topTimeInterims then
                local recordTimeAtCP = tonumber(topTimeInterims[checkpointNum])
                if recordTimeAtCP then
                    local diff = recordTimeAtCP - timePassed
                    if showClientDelays[source] then
                        triggerClientEvent(source, "showDelay", source, diff, topTimeRankPlayer)
                    end
                end
            end
        else
            local frontPlayer = getPlayerFromRank(rank - 1)
            if not frontPlayer then
                if lastPlayer[checkpointNum] then frontPlayer = lastPlayer[checkpointNum] end
            else
                if allCpTimes[frontPlayer] and allCpTimes[frontPlayer][checkpointNum] then
                    local diff = timePassed - allCpTimes[frontPlayer][checkpointNum]
                    if showClientDelays[source] then
                        triggerClientEvent(source, "showDelay", frontPlayer, diff)
                    end
                end
            end
        end
        lastPlayer[checkpointNum] = source
    end
)

function getPlayerFromRank(rank)
    for i, player in ipairs(getElementsByType("player")) do
        if getElementData(player, "race rank") == rank then return player end
    end
    return false
end

addEvent("onPlayerToptimeImprovement")
addEventHandler("onPlayerToptimeImprovement", g_Root,
    function(newPos)
        if newPos <= (topTimeRankPlayer[1] or 10) and allCpTimes[source] then
            local playername = newPos.." "..getPlayerName(source)
            local interims = table.concat(allCpTimes[source], ",")
            executeSQLQuery("INSERT OR REPLACE INTO mapinterims (mapname, playername, interims) VALUES (?,?,?)", mapName, playername, interims)
            topTimeRankPlayer = {newPos, getPlayerName(source)}
            topTimeInterims = allCpTimes[source]
        end
    end
)

-- ADMIN COMMAND: /clearsplits
-- Use this after deleting a toptime to wipe the delay indicator cache for the map
addCommandHandler("clearsplits", 
    function(player)
        local accName = getAccountName(getPlayerAccount(player))
        if isObjectInACLGroup("user."..accName, aclGetGroup("Admin")) then
            if mapName then
                executeSQLQuery("DELETE FROM mapinterims WHERE mapname = ?", mapName)
                topTimeInterims = nil
                outputChatBox("Split cache cleared for: " .. mapName, player, 0, 255, 0)
            end
        end
    end
)

function updatetopTimeInterims()
    local sql = executeSQLQuery("SELECT * FROM mapinterims")
    if not sql then return end
    for _,row in ipairs(sql) do
        if not string.find(row.playername, " ") then
            executeSQLQuery("UPDATE mapinterims SET playername=? WHERE mapname=?", "1 "..row.playername, row.mapname )
        end
    end
end

function updateMapNames()
    local sql = executeSQLQuery("SELECT * FROM mapinterims")
    if not sql then return end
    local infoMaps = {}
    for _,map in ipairs(exports.mapmanager:getMaps()) do
        infoMaps[getResourceInfo(map, "name") or getResourceName(map)] = getResourceName(map)
    end
    for _,row in ipairs(sql) do
        if infoMaps[row.mapname] then
            executeSQLQuery("UPDATE mapinterims SET mapname=? WHERE mapname=?", infoMaps[row.mapname], row.mapname)
        elseif not getResourceFromName(row.mapname) then
            executeSQLQuery("DELETE FROM mapinterims WHERE mapname=?", row.mapname)
        end
    end
end

addCommandHandler("cpdelays", function(p)
    showClientDelays[p] = not showClientDelays[p]
    outputChatBox("Checkpoint delays: "..(showClientDelays[p] and "#00FF00ON" or "#FF0000OFF"), p, 255, 255, 255, true)
end)

addEvent("onClientShowCPDelays", true)
addEventHandler("onClientShowCPDelays", resourceRoot, function() showClientDelays[client] = true end)
addEvent("onClientHideCPDelays", true)
addEventHandler("onClientHideCPDelays", resourceRoot, function() showClientDelays[client] = false end)