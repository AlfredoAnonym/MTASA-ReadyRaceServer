-- server.lua
local STARTING_ELO = 100
local MAX_LEVEL = 10
local currentMultiplier = 1 -- Default multiplier

-- Set default global multiplier for the client UI
setElementData(root, "ELO_Multiplier", 1)

-- Elo Ranges 
local eloRanges = {
    {level=1, min=100, max=500},
    {level=2, min=501, max=750},
    {level=3, min=751, max=900},
    {level=4, min=901, max=1050},
    {level=5, min=1051, max=1200},
    {level=6, min=1201, max=1350},
    {level=7, min=1351, max=1530},
    {level=8, min=1531, max=1750},
    {level=9, min=1751, max=2000},
    {level=10, min=2001, max=999999}
}

local playerStreaks = {}

-- Helper function to find a player by partial name ignoring hex codes
local function getPlayerFromPartialName(name)
    local searchName = name and name:gsub("#%x%x%x%x%x%x", ""):lower() or ""
    if searchName == "" then return false end
    for _, player in ipairs(getElementsByType("player")) do
        local playerName = getPlayerName(player):gsub("#%x%x%x%x%x%x", ""):lower()
        if playerName:find(searchName, 1, true) then
            return player
        end
    end
    return false
end

function getPlayerElo(player)
    local account = getPlayerAccount(player)
    if isGuestAccount(account) then return STARTING_ELO end
    return getAccountData(account, "race.elo") or STARTING_ELO
end

function getLevelInfo(elo)
    for _, range in ipairs(eloRanges) do
        if elo >= range.min and elo <= range.max then
            return range.level, "images/lvl"..range.level..".png"
        end
    end
    return 1, "images/lvl1.png"
end

function setPlayerElo(player, amount)
    local account = getPlayerAccount(player)
    if isGuestAccount(account) or not amount then return end
    if amount < 100 then amount = 100 end
    
    -- Level up detection logic
    local oldElo = getAccountData(account, "race.elo") or STARTING_ELO
    local oldLevel = getLevelInfo(oldElo)
    local newLevel = getLevelInfo(amount)
    
    setAccountData(account, "race.elo", amount)
    
    -- Passing 'true' forces the TAB scoreboard to update immediately
    updatePlayerElementData(player, amount, true) 
    
    -- Check if level increased
    if newLevel > oldLevel then
        triggerClientEvent(player, "onClientPlayLevelUp", player)
        outputChatBox("#FF6400[ELO] #FFFFFF" .. getPlayerName(player):gsub("#%x%x%x%x%x%x", "") .. " has advanced to #FF6400Level " .. newLevel .. "#FFFFFF!", root, 255, 255, 255, true)
    end
end

-- Track 1st Place Top Times Native Helper
function getPlayerWins(player)
    local account = getPlayerAccount(player)
    if isGuestAccount(account) then return 0 end
    return getAccountData(account, "race.wins") or 0
end

function addPlayerWin(player)
    local account = getPlayerAccount(player)
    if isGuestAccount(account) then return end
    local wins = getPlayerWins(player) + 1
    setAccountData(account, "race.wins", wins)
    setElementData(player, "ELO_Wins", wins)
end

function updatePlayerElementData(player, elo, cleanScoreboard)
    if not elo then elo = getPlayerElo(player) end
    local level, imgPath = getLevelInfo(elo)
    
    setElementData(player, "ELO_Value", elo)
    setElementData(player, "Level_Img", imgPath)
    setElementData(player, "Level", level)
    setElementData(player, "ELO_Streak", playerStreaks[player] or 0)

    -- If cleanScoreboard is true, we update the TAB with the clean number
    if cleanScoreboard then
        setElementData(player, "ELO", tostring(elo))
    end
end

-- RESET SCOREBOARD ON NEW MAP
addEventHandler("onResourceStart", resourceRoot, function()
    call(getResourceFromName("scoreboard"), "addScoreboardColumn", "ELO", root, 4, 0.1)
    call(getResourceFromName("scoreboard"), "addScoreboardColumn", "Level", root, 5, 0.05)
end)

-- Detect when a new race map starts to clear the (+/-) text
local function clearEloScoreboard()
    for _, p in ipairs(getElementsByType("player")) do
        updatePlayerElementData(p, nil, true)
        if not getElementData(p, "ELO_Wins") then
            setElementData(p, "ELO_Wins", getPlayerWins(p))
        end
    end
    currentMultiplier = 1 -- Reset multiplier for the new map
    setElementData(root, "ELO_Multiplier", 1)
end

addEvent("onPostColor", true) 
addEventHandler("onPostColor", root, clearEloScoreboard)
addEvent("onMapStarting", true) -- Added standard MTA Race map start event to guarantee it clears
addEventHandler("onMapStarting", root, clearEloScoreboard)

-- LOGIN/QUIT
addEventHandler("onPlayerLogin", root, function(_, acc)
    playerStreaks[source] = 0
    setElementData(source, "ELO_Wins", getPlayerWins(source))
    updatePlayerElementData(source, nil, true)
end)

-- RACE FINISH LOGIC
addEvent("onPlayerFinish", true)
addEventHandler("onPlayerFinish", root, function(rank)
    local activePlayers = getElementsByType("player")
    
    -- Prevent solo ELO farming
    if #activePlayers <= 1 then
        outputChatBox("#FF6400[ELO] #FFFFFFNo ELO earned: Not enough players on the server.", source, 255, 255, 255, true)
        return
    end

    local currentElo = getPlayerElo(source)
    local eloChange = 0
    
    if rank == 1 then
        addPlayerWin(source)
        eloChange = math.random(20, 30) * ((playerStreaks[source] or 0) >= 2 and 1.5 or 1.0)
        playerStreaks[source] = (playerStreaks[source] or 0) + 1
    elseif rank == 2 then
        eloChange = math.random(10, 15)
        playerStreaks[source] = 0
    elseif rank == 3 then
        eloChange = math.random(5, 9)
        playerStreaks[source] = 0
    elseif rank == 4 then
        eloChange = math.random(1, 4)
        playerStreaks[source] = 0
    else
        -- 5th place and below loses ELO
        eloChange = -math.random(15, 25)
        playerStreaks[source] = 0
    end
    
    -- Apply Bonus Multiplier
    eloChange = math.floor(eloChange * currentMultiplier)
    
    local newElo = currentElo + eloChange
    
    -- Recalculate true change if they hit the 100 ELO floor
    if newElo < 100 then 
        newElo = 100 
        eloChange = newElo - currentElo
    end
    
    setPlayerElo(source, newElo)
    
    local sign = (eloChange >= 0) and "+" or ""
    local color = (eloChange >= 0) and "#00FF00" or "#FF0000"
    
    -- Update scoreboard with brackets
    setElementData(source, "ELO", newElo .. " (" .. sign .. eloChange .. ")")
    
    -- Output chat message
    if eloChange ~= 0 then
        outputChatBox("#FF6400[ELO] #FFFFFFYou finished rank " .. rank .. ". ELO updated: " .. color .. sign .. eloChange, source, 255, 255, 255, true)
    end
end)

-- DNF PENALTY (Player does not finish)
addEvent("onPlayerWasted", true)
addEventHandler("onPlayerWasted", root, function()
    local activePlayers = getElementsByType("player")
    
    -- Prevent solo ELO penalty
    if #activePlayers <= 1 then
        return
    end

    local currentElo = getPlayerElo(source)
    local penalty = math.random(2, 5)
    
    local newElo = currentElo - penalty
    
    -- Recalculate true penalty if they hit the 100 ELO floor
    if newElo < 100 then 
        newElo = 100 
        penalty = currentElo - newElo
    end
    
    setPlayerElo(source, newElo)
    setElementData(source, "ELO", newElo .. " (-" .. penalty .. " DNF)")
    
    if penalty > 0 then
        outputChatBox("#FF6400[ELO] #FFFFFFYou DNF'd! ELO updated: #FF0000-" .. penalty, source, 255, 255, 255, true)
    end
end)

-- ADMIN COMMANDS
addCommandHandler("bonuselo", function(player, cmd, val)
    local accName = getAccountName(getPlayerAccount(player))
    if isObjectInACLGroup("user."..accName, aclGetGroup("Admin")) then
        local mult = tonumber(val)
        if mult and mult >= 1 and mult <= 5 then
            currentMultiplier = mult
            setElementData(root, "ELO_Multiplier", mult)
            outputChatBox("#FF6400[ELO] #FFFFFFAdmin set ELO multiplier to #FF6400x" .. mult .. " #FFFFFFfor this round!", root, 255, 255, 255, true)
        else
            outputChatBox("Usage: /bonuselo [1-5]", player)
        end
    end
end)

addCommandHandler("giveelo", function(player, cmd, targetName, amount)
    local accName = getAccountName(getPlayerAccount(player))
    if isObjectInACLGroup("user."..accName, aclGetGroup("Admin")) then
        local target = getPlayerFromPartialName(targetName)
        local amt = tonumber(amount)
        if target and amt then
            local current = getPlayerElo(target)
            setPlayerElo(target, current + amt)
            outputChatBox("#FF6400[ELO] #FFFFFFAdmin gave " .. amt .. " ELO to " .. getPlayerName(target):gsub("#%x%x%x%x%x%x", ""), root, 255, 255, 255, true)
        else
            outputChatBox("Usage: /giveelo [PartialPlayerName] [Amount]", player)
        end
    end
end)

addCommandHandler("takeelo", function(player, cmd, targetName, amount)
    local accName = getAccountName(getPlayerAccount(player))
    if isObjectInACLGroup("user."..accName, aclGetGroup("Admin")) then
        local target = getPlayerFromPartialName(targetName)
        local amt = tonumber(amount)
        if target and amt then
            local current = getPlayerElo(target)
            local newElo = current - amt
            if newElo < 100 then newElo = 100 end
            setPlayerElo(target, newElo)
            outputChatBox("#FF6400[ELO] #FFFFFFAdmin took " .. amt .. " ELO from " .. getPlayerName(target):gsub("#%x%x%x%x%x%x", ""), root, 255, 255, 255, true)
        else
            outputChatBox("Usage: /takeelo [PartialPlayerName] [Amount]", player)
        end
    end
end)