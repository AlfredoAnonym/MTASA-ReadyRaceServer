-- server.lua
local STARTING_ELO = 100
local MAX_LEVEL = 10
local currentMultiplier = 1
local playerStreaks = {}
local activeBets = {} -- Table to handle /betelo logic

setElementData(root, "ELO_Multiplier", 1)

local eloRanges = {
    {level=1, min=100, max=500},
    {level=2, min=501, max=750},
    {level=3, min=751, max=900},
    {level=4, min=901, max=1050},
    {level=5, min=1051, max=1200},
    {level=6, min=1201, max=1350},
    {level=7, min=1351, max=1530},
    {level=8, min=1531, max=1750},
    {level=9, min=1751, max=2000},
    {level=10, min=2001, max=999999}
}

local function getPlayerFromPartialName(name)
    local searchName = name and name:gsub("#%x%x%x%x%x%x", ""):lower() or ""
    if searchName == "" then return false end
    for _, player in ipairs(getElementsByType("player")) do
        local playerName = getPlayerName(player):gsub("#%x%x%x%x%x%x", ""):lower()
        if playerName:find(searchName, 1, true) then
            return player
        end
    end
    return false
end

function getPlayerElo(player)
    local account = getPlayerAccount(player)
    if isGuestAccount(account) then return STARTING_ELO end
    return getAccountData(account, "race.elo") or STARTING_ELO
end

function getLevelInfo(elo)
    for _, range in ipairs(eloRanges) do
        if elo >= range.min and elo <= range.max then
            return range.level, "images/lvl"..range.level..".png"
        end
    end
    return 1, "images/lvl1.png"
end

function setPlayerElo(player, amount)
    local account = getPlayerAccount(player)
    if isGuestAccount(account) or not amount then return end
    if amount < 100 then amount = 100 end
    
    local oldElo = getAccountData(account, "race.elo") or STARTING_ELO
    local oldLevel = getLevelInfo(oldElo)
    local newLevel = getLevelInfo(amount)
    
    setAccountData(account, "race.elo", amount)
    updatePlayerElementData(player, amount, true) 
    
    if newLevel > oldLevel then
        triggerClientEvent(player, "onClientPlayLevelUp", player)
        outputChatBox("#FF6400[ELO] #FFFFFF" .. getPlayerName(player):gsub("#%x%x%x%x%x%x", "") .. " has advanced to #FF6400Level " .. newLevel .. "#FFFFFF!", root, 255, 255, 255, true)
    end
end

-- Helper to safely increment any account stat
local function incrementAccountStat(player, statName)
    local account = getPlayerAccount(player)
    if isGuestAccount(account) then return end
    local current = getAccountData(account, statName) or 0
    setAccountData(account, statName, current + 1)
end

function getPlayerWins(player)
    local account = getPlayerAccount(player)
    if isGuestAccount(account) then return 0 end
    return getAccountData(account, "race.wins") or 0
end

function updatePlayerElementData(player, elo, cleanScoreboard)
    if not elo then elo = getPlayerElo(player) end
    local level, imgPath = getLevelInfo(elo)
    
    -- Save the player's last known clean name to the account for the offline GUI
    local account = getPlayerAccount(player)
    if not isGuestAccount(account) then
        setAccountData(account, "race.last_name", getPlayerName(player):gsub("#%x%x%x%x%x%x", ""))
    end
    
    setElementData(player, "ELO_Value", elo)
    setElementData(player, "Level_Img", imgPath)
    setElementData(player, "Level", level)
    setElementData(player, "ELO_Streak", playerStreaks[player] or 0)

    if cleanScoreboard then
        setElementData(player, "ELO", tostring(elo))
    end
end

-- Serve Data to Client for F6 Menu
addEvent("onRequestEloLeaderboard", true)
addEventHandler("onRequestEloLeaderboard", root, function()
    local allData = {}
    for _, acc in ipairs(getAccounts()) do
        if not isGuestAccount(acc) then
            local elo = getAccountData(acc, "race.elo") or STARTING_ELO
            -- Only send accounts that have actually played to save bandwidth
            if elo > STARTING_ELO or getAccountData(acc, "race.wins") then
                local name = getAccountData(acc, "race.last_name") or getAccountName(acc)
                local level = getLevelInfo(elo)
                local wins = getAccountData(acc, "race.wins") or 0
                local seconds = getAccountData(acc, "race.2nd") or 0
                local thirds = getAccountData(acc, "race.3rd") or 0
                local deaths = getAccountData(acc, "race.deaths") or 0
                
                table.insert(allData, {name=name, elo=elo, level=level, wins=wins, seconds=seconds, thirds=thirds, deaths=deaths})
            end
        end
    end
    triggerClientEvent(client, "onClientReceiveEloData", resourceRoot, allData)
end)

addEventHandler("onResourceStart", resourceRoot, function()
    call(getResourceFromName("scoreboard"), "addScoreboardColumn", "ELO", root, 4, 0.1)
    call(getResourceFromName("scoreboard"), "addScoreboardColumn", "Level", root, 5, 0.05)
end)

local function clearEloScoreboard()
    for _, p in ipairs(getElementsByType("player")) do
        updatePlayerElementData(p, nil, true)
    end
    currentMultiplier = 1
    setElementData(root, "ELO_Multiplier", 1)
    activeBets = {} -- Clear pending bets when a new map starts
end

addEvent("onPostColor", true) 
addEventHandler("onPostColor", root, clearEloScoreboard)
addEvent("onMapStarting", true)
addEventHandler("onMapStarting", root, clearEloScoreboard)

addEventHandler("onPlayerLogin", root, function(_, acc)
    playerStreaks[source] = 0
    updatePlayerElementData(source, nil, true)
end)

addEventHandler("onPlayerQuit", root, function()
    if activeBets[source] then activeBets[source] = nil end
end)

-- BETTING SYSTEM
addCommandHandler("betelo", function(player, cmd, targetName, amount)
    amount = tonumber(amount)
    if not amount or amount <= 0 or not targetName then
        outputChatBox("#FF6400[ELO] #FFFFFFUsage: /betelo [PlayerName] [Amount]", player, 255, 255, 255, true)
        return
    end
    
    if activeBets[player] then
        outputChatBox("#FF6400[ELO] #FFFFFFYou have already placed a bet for this race.", player, 255, 255, 255, true)
        return
    end

    local target = getPlayerFromPartialName(targetName)
    if not target then
        outputChatBox("#FF6400[ELO] #FFFFFFPlayer not found.", player, 255, 255, 255, true)
        return
    end
    
    if target == player then
        outputChatBox("#FF6400[ELO] #FFFFFFYou cannot bet on yourself.", player, 255, 255, 255, true)
        return
    end
    
    local currentElo = getPlayerElo(player)
    if currentElo - amount < 100 then
        outputChatBox("#FF6400[ELO] #FFFFFFYou don't have enough ELO to make this bet. (You cannot drop below 100)", player, 255, 255, 255, true)
        return
    end
    
    -- Deduct ELO immediately as the bet is placed
    setPlayerElo(player, currentElo - amount)
    activeBets[player] = {target = target, amount = amount}
    outputChatBox("#FF6400[ELO] #FFFFFFYou bet #00FF00" .. amount .. " ELO #FFFFFFon " .. getPlayerName(target):gsub("#%x%x%x%x%x%x", "") .. " to win!", player, 255, 255, 255, true)
end)

-- RACE FINISH LOGIC
addEvent("onPlayerFinish", true)
addEventHandler("onPlayerFinish", root, function(rank)
    local activePlayers = getElementsByType("player")
    if #activePlayers <= 1 then
        outputChatBox("#FF6400[ELO] #FFFFFFNo ELO earned: Not enough players on the server.", source, 255, 255, 255, true)
        return
    end

    local currentElo = getPlayerElo(source)
    local eloChange = 0
    
    if rank == 1 then
        incrementAccountStat(source, "race.wins")
        eloChange = math.random(20, 30) * ((playerStreaks[source] or 0) >= 2 and 1.5 or 1.0)
        playerStreaks[source] = (playerStreaks[source] or 0) + 1
        
        -- Handle Bet Payouts
        for bettor, betData in pairs(activeBets) do
            if isElement(bettor) then
                if betData.target == source then
                    local reward = betData.amount * 2
                    setPlayerElo(bettor, getPlayerElo(bettor) + reward)
                    outputChatBox("#FF6400[BET] #FFFFFFYour player won! You received #00FF00" .. reward .. " ELO#FFFFFF.", bettor, 255, 255, 255, true)
                else
                    outputChatBox("#FF6400[BET] #FFFFFFYour player did not win 1st place. You lost your bet of #FF0000" .. betData.amount .. " ELO#FFFFFF.", bettor, 255, 255, 255, true)
                end
            end
        end
        activeBets = {} -- Clear bets after 1st place crosses the line
        
    elseif rank == 2 then
        incrementAccountStat(source, "race.2nd")
        eloChange = math.random(10, 15)
        playerStreaks[source] = 0
    elseif rank == 3 then
        incrementAccountStat(source, "race.3rd")
        eloChange = math.random(5, 9)
        playerStreaks[source] = 0
    elseif rank == 4 then
        eloChange = math.random(1, 4)
        playerStreaks[source] = 0
    else
        eloChange = -math.random(15, 25)
        playerStreaks[source] = 0
    end
    
    eloChange = math.floor(eloChange * currentMultiplier)
    local newElo = currentElo + eloChange
    
    if newElo < 100 then 
        newElo = 100 
        eloChange = newElo - currentElo
    end
    
    setPlayerElo(source, newElo)
    
    local sign = (eloChange >= 0) and "+" or ""
    local color = (eloChange >= 0) and "#00FF00" or "#FF0000"
    
    setElementData(source, "ELO", newElo .. " (" .. sign .. eloChange .. ")")
    
    if eloChange ~= 0 then
        outputChatBox("#FF6400[ELO] #FFFFFFYou finished rank " .. rank .. ". ELO updated: " .. color .. sign .. eloChange, source, 255, 255, 255, true)
    end
end)

addEvent("onPlayerWasted", true)
addEventHandler("onPlayerWasted", root, function()
    local activePlayers = getElementsByType("player")
    if #activePlayers <= 1 then return end

    incrementAccountStat(source, "race.deaths")

    local currentElo = getPlayerElo(source)
    local penalty = math.random(2, 5)
    
    local newElo = currentElo - penalty
    if newElo < 100 then 
        newElo = 100 
        penalty = currentElo - newElo
    end
    
    setPlayerElo(source, newElo)
    setElementData(source, "ELO", newElo .. " (-" .. penalty .. " DNF)")
    
    if penalty > 0 then
        outputChatBox("#FF6400[ELO] #FFFFFFYou DNF'd! ELO updated: #FF0000-" .. penalty, source, 255, 255, 255, true)
    end
end)

-- ADMIN COMMANDS
addCommandHandler("bonuselo", function(player, cmd, val)
    local accName = getAccountName(getPlayerAccount(player))
    if isObjectInACLGroup("user."..accName, aclGetGroup("Admin")) then
        local mult = tonumber(val)
        if mult and mult >= 1 and mult <= 5 then
            currentMultiplier = mult
            setElementData(root, "ELO_Multiplier", mult)
            outputChatBox("#FF6400[ELO] #FFFFFFAdmin set ELO multiplier to #FF6400x" .. mult .. " #FFFFFFfor this round!", root, 255, 255, 255, true)
        else
            outputChatBox("Usage: /bonuselo [1-5]", player)
        end
    end
end)

addCommandHandler("giveelo", function(player, cmd, targetName, amount)
    local accName = getAccountName(getPlayerAccount(player))
    if isObjectInACLGroup("user."..accName, aclGetGroup("Admin")) then
        local target = getPlayerFromPartialName(targetName)
        local amt = tonumber(amount)
        if target and amt then
            local current = getPlayerElo(target)
            setPlayerElo(target, current + amt)
            outputChatBox("#FF6400[ELO] #FFFFFFAdmin gave " .. amt .. " ELO to " .. getPlayerName(target):gsub("#%x%x%x%x%x%x", ""), root, 255, 255, 255, true)
        else
            outputChatBox("Usage: /giveelo [PartialPlayerName] [Amount]", player)
        end
    end
end)

addCommandHandler("takeelo", function(player, cmd, targetName, amount)
    local accName = getAccountName(getPlayerAccount(player))
    if isObjectInACLGroup("user."..accName, aclGetGroup("Admin")) then
        local target = getPlayerFromPartialName(targetName)
        local amt = tonumber(amount)
        if target and amt then
            local current = getPlayerElo(target)
            local newElo = current - amt
            if newElo < 100 then newElo = 100 end
            setPlayerElo(target, newElo)
            outputChatBox("#FF6400[ELO] #FFFFFFAdmin took " .. amt .. " ELO from " .. getPlayerName(target):gsub("#%x%x%x%x%x%x", ""), root, 255, 255, 255, true)
        else
            outputChatBox("Usage: /takeelo [PartialPlayerName] [Amount]", player)
        end
    end
end)