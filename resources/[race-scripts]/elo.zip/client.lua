-- client.lua
local screenW, screenH = guiGetScreenSize()
local eloWindow = nil
local eloGrid = nil
local eloImage = nil
local eloNameLabel = nil
local statsLabel = nil
local isMenuVisible = false
local currentLeaderboardData = {}

-- 1. Create the Classic GUI
function createEloMenu()
    local w, h = 600, 500
    local x, y = (screenW - w) / 2, (screenH - h) / 2
    
    eloWindow = guiCreateWindow(x, y, w, h, "ELO LEADERBOARD", false)
    guiWindowSetSizable(eloWindow, false)
    guiSetVisible(eloWindow, false)
    
    eloGrid = guiCreateGridList(0.03, 0.06, 0.60, 0.90, true, eloWindow)
    
    guiGridListAddColumn(eloGrid, "Rank", 0.15)
    guiGridListAddColumn(eloGrid, "Lvl", 0.15) 
    guiGridListAddColumn(eloGrid, "Player", 0.45)
    guiGridListAddColumn(eloGrid, "ELO", 0.2)
    
    guiGridListSetSortingEnabled(eloGrid, true)

    eloNameLabel = guiCreateLabel(0.65, 0.1, 0.32, 0.05, "Select a Player", true, eloWindow)
    guiLabelSetHorizontalAlign(eloNameLabel, "center")
    guiSetFont(eloNameLabel, "default-bold-small")

    eloImage = guiCreateStaticImage(0.68, 0.2, 0.26, 0.32, "images/lvl1.png", true, eloWindow)
    
    -- Adjusted positioning and size slightly to fit the new stats
    statsLabel = guiCreateLabel(0.65, 0.52, 0.32, 0.45, "Loading stats...", true, eloWindow)
    guiLabelSetHorizontalAlign(statsLabel, "center")
    
    addEventHandler("onClientGUIClick", eloGrid, updatePreviewImage, false)
end
addEventHandler("onClientResourceStart", resourceRoot, createEloMenu)

function updatePreviewImage()
    local row, col = guiGridListGetSelectedItem(eloGrid)
    
    if not row or row == -1 then return end
    
    -- Retrieve the original index we saved in the grid list
    local dataIndex = guiGridListGetItemData(eloGrid, row, 1)
    local pData = currentLeaderboardData[dataIndex]
    if not pData then return end
    
    guiSetText(eloNameLabel, pData.name)
    
    local path = "images/lvl" .. pData.level .. ".png"
    if fileExists(path) then
        guiStaticImageLoadImage(eloImage, path)
    else
        guiStaticImageLoadImage(eloImage, "images/lvl1.png")
    end

    -- Check if player is currently online to grab their streak, otherwise assume 0
    local streak = 0
    for _, p in ipairs(getElementsByType("player")) do
        if getPlayerName(p):gsub("#%x%x%x%x%x%x", "") == pData.name then
            streak = getElementData(p, "ELO_Streak") or 0
            break
        end
    end

    local mult = getElementData(root, "ELO_Multiplier") or 1
    local streakBonus = (streak >= 2) and 1.5 or 1.0
    local expectedWin = math.floor(25 * streakBonus * mult)
    local expectedLoss = math.floor(-20 * mult)

    local nextLevelElo = "MAX"
    local eloRanges = {
        {level=1, max=500}, {level=2, max=750}, {level=3, max=900},
        {level=4, max=1050}, {level=5, max=1200}, {level=6, max=1350},
        {level=7, max=1530}, {level=8, max=1750}, {level=9, max=2000}
    }
    
    if pData.level < 10 then
        for _, r in ipairs(eloRanges) do
            if pData.level == r.level then
                nextLevelElo = tostring(r.max + 1)
                break
            end
        end
    end

    local statsText = string.format(
        "Current ELO: %d\nNext Level At: %s\n\n1st Places: %d | 2nd Places: %d\n3rd Places: %d | Deaths: %d\nWin Streak: %d\n\nExpected ELO (+/-):\nWin: +%d | Loss: %d",
        pData.elo, nextLevelElo, pData.wins, pData.seconds, pData.thirds, pData.deaths, streak, expectedWin, expectedLoss
    )
    guiSetText(statsLabel, statsText)
end

function toggleEloMenu()
    isMenuVisible = not isMenuVisible
    if not eloWindow then return end
    
    guiSetVisible(eloWindow, isMenuVisible)
    showCursor(isMenuVisible)
    
    if isMenuVisible then
        guiGridListClear(eloGrid)
        guiSetText(statsLabel, "Fetching data from server...")
        -- Request all offline and online player stats from the server
        triggerServerEvent("onRequestEloLeaderboard", localPlayer)
    end
end
bindKey("F6", "down", toggleEloMenu)

addEvent("onClientReceiveEloData", true)
addEventHandler("onClientReceiveEloData", root, function(data)
    currentLeaderboardData = data
    guiGridListClear(eloGrid)
    
    -- Initial Sort (Highest ELO at top)
    table.sort(currentLeaderboardData, function(a, b) return a.elo > b.elo end)
    
    for i, pData in ipairs(currentLeaderboardData) do
        local row = guiGridListAddRow(eloGrid)
        
        guiGridListSetItemText(eloGrid, row, 1, tostring(i), false, true)
        guiGridListSetItemText(eloGrid, row, 2, tostring(pData.level), false, true)
        guiGridListSetItemText(eloGrid, row, 3, pData.name, false, false)
        guiGridListSetItemText(eloGrid, row, 4, tostring(pData.elo), false, true)
        
        -- Store the array index invisibly so we can fetch all offline stats on click
        guiGridListSetItemData(eloGrid, row, 1, i)
        
        if i == 1 then
            for col = 1, 4 do guiGridListSetItemColor(eloGrid, row, col, 255, 215, 0) end
        elseif i == 2 then
            for col = 1, 4 do guiGridListSetItemColor(eloGrid, row, col, 192, 192, 192) end
        elseif i == 3 then
            for col = 1, 4 do guiGridListSetItemColor(eloGrid, row, col, 205, 127, 50) end
        end
    end
    
    guiSetText(statsLabel, "Select a player to view stats.")
end)

addEvent("onClientPlayLevelUp", true)
addEventHandler("onClientPlayLevelUp", root, function()
    local sound = playSound("sounds/levelup.mp3")
    setSoundVolume(sound, 0.8)
end)