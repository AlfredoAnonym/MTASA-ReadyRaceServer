-- client.lua
local screenW, screenH = guiGetScreenSize()
local eloWindow = nil
local eloGrid = nil
local eloImage = nil
local eloNameLabel = nil
local statsLabel = nil
local isMenuVisible = false

-- 1. Create the Classic GUI
function createEloMenu()
    -- Width for list + preview panel
    local w, h = 600, 500
    local x, y = (screenW - w) / 2, (screenH - h) / 2
    
    eloWindow = guiCreateWindow(x, y, w, h, "ELO LEADERBOARD", false)
    guiWindowSetSizable(eloWindow, false)
    guiSetVisible(eloWindow, false)
    
    -- GridList (Left Side) - Holds the list and vertical slider
    eloGrid = guiCreateGridList(0.03, 0.06, 0.60, 0.90, true, eloWindow)
    
    -- Add Columns (Clicking these will sort Most/Least ELO)
    guiGridListAddColumn(eloGrid, "Rank", 0.15)
    guiGridListAddColumn(eloGrid, "Lvl", 0.15) 
    guiGridListAddColumn(eloGrid, "Player", 0.45)
    guiGridListAddColumn(eloGrid, "ELO", 0.2)
    
    guiGridListSetSortingEnabled(eloGrid, true)

    -- Preview Panel (Right Side)
    eloNameLabel = guiCreateLabel(0.65, 0.1, 0.32, 0.05, "Select a Player", true, eloWindow)
    guiLabelSetHorizontalAlign(eloNameLabel, "center")
    guiSetFont(eloNameLabel, "default-bold-small")

    -- The Level Image (Changes based on selection)
    eloImage = guiCreateStaticImage(0.68, 0.2, 0.26, 0.32, "images/lvl1.png", true, eloWindow)
    
    -- Dynamic Stats Label (Replaces static info label)
    statsLabel = guiCreateLabel(0.65, 0.55, 0.32, 0.40, "Loading stats...", true, eloWindow)
    guiLabelSetHorizontalAlign(statsLabel, "center")
    
    -- Event: Update preview image when clicking a row
    addEventHandler("onClientGUIClick", eloGrid, updatePreviewImage, false)
end
addEventHandler("onClientResourceStart", resourceRoot, createEloMenu)

function updatePreviewImage()
    local row, col = guiGridListGetSelectedItem(eloGrid)
    local targetPlayer = localPlayer
    
    -- Determine which player is selected from the grid
    if row and row ~= -1 then
        local playerName = guiGridListGetItemText(eloGrid, row, 3)
        for _, p in ipairs(getElementsByType("player")) do
            if getPlayerName(p):gsub("#%x%x%x%x%x%x", "") == playerName then
                targetPlayer = p
                break
            end
        end
    end
    
    -- Extract Data safely
    local name = getPlayerName(targetPlayer):gsub("#%x%x%x%x%x%x", "")
    local level = getElementData(targetPlayer, "Level") or 1
    local elo = getElementData(targetPlayer, "ELO_Value") or 100
    local wins = getElementData(targetPlayer, "ELO_Wins") or 0
    local streak = getElementData(targetPlayer, "ELO_Streak") or 0
    local mult = getElementData(root, "ELO_Multiplier") or 1
    
    guiSetText(eloNameLabel, name)
    
    -- Load corresponding level image (1-10)
    local path = "images/lvl" .. level .. ".png"
    if fileExists(path) then
        guiStaticImageLoadImage(eloImage, path)
    else
        guiStaticImageLoadImage(eloImage, "images/lvl1.png")
    end

    -- Calculate Expected ELO (Avg base 25 * streak bonus * global multiplier)
    local streakBonus = (streak >= 2) and 1.5 or 1.0
    local expectedWin = math.floor(25 * streakBonus * mult)
    local expectedLoss = math.floor(-20 * mult)

    -- Creative Touch: Next Level Requirement Calculation
    local nextLevelElo = "MAX"
    local eloRanges = {
        {level=1, max=500}, {level=2, max=750}, {level=3, max=900},
        {level=4, max=1050}, {level=5, max=1200}, {level=6, max=1350},
        {level=7, max=1530}, {level=8, max=1750}, {level=9, max=2000}
    }
    
    if level < 10 then
        for _, r in ipairs(eloRanges) do
            if level == r.level then
                nextLevelElo = tostring(r.max + 1)
                break
            end
        end
    end

    -- Update Stats UI
    local statsText = string.format(
        "Current ELO: %d\nNext Level At: %s\n\n1st Place Finishes: %d\nWin Streak: %d\n\nExpected ELO (+/-):\nWin: +%d | Loss: %d",
        elo, nextLevelElo, wins, streak, expectedWin, expectedLoss
    )
    guiSetText(statsLabel, statsText)
end

function toggleEloMenu()
    isMenuVisible = not isMenuVisible
    if not eloWindow then return end
    
    guiSetVisible(eloWindow, isMenuVisible)
    showCursor(isMenuVisible)
    
    if isMenuVisible then
        updateEloGrid()
        updatePreviewImage()
    end
end
bindKey("F6", "down", toggleEloMenu)

function updateEloGrid()
    guiGridListClear(eloGrid)
    
    local players = getElementsByType("player")
    local sortedPlayers = {}
    
    for _, p in ipairs(players) do
        local elo = getElementData(p, "ELO_Value") or 100
        local level = getElementData(p, "Level") or 1
        table.insert(sortedPlayers, {element = p, elo = elo, level = level})
    end
    
    -- Initial Sort (Highest ELO at top)
    table.sort(sortedPlayers, function(a, b) return a.elo > b.elo end)
    
    for i, data in ipairs(sortedPlayers) do
        local row = guiGridListAddRow(eloGrid)
        
        guiGridListSetItemText(eloGrid, row, 1, tostring(i), false, true)
        guiGridListSetItemText(eloGrid, row, 2, tostring(data.level), false, true)
        
        local name = getPlayerName(data.element):gsub("#%x%x%x%x%x%x", "")
        guiGridListSetItemText(eloGrid, row, 3, name, false, false)
        
        guiGridListSetItemText(eloGrid, row, 4, tostring(data.elo), false, true)
        
        -- Apply colors for 1st (Gold), 2nd (Silver), and 3rd (Bronze)
        if i == 1 then
            for col = 1, 4 do guiGridListSetItemColor(eloGrid, row, col, 255, 215, 0) end
        elseif i == 2 then
            for col = 1, 4 do guiGridListSetItemColor(eloGrid, row, col, 192, 192, 192) end
        elseif i == 3 then
            for col = 1, 4 do guiGridListSetItemColor(eloGrid, row, col, 205, 127, 50) end
        end
    end
end

-- Level Up Sound Trigger
addEvent("onClientPlayLevelUp", true)
addEventHandler("onClientPlayLevelUp", root, function()
    local sound = playSound("sounds/levelup.mp3")
    setSoundVolume(sound, 0.8)
end)