--[[
	Original Author: WTF//Jake
	Remixed by: Gemini
	Version: 2.3 (Rotor Fix)
]]--

local carhide = false
local mapAllowed = true
local localPlayer = getLocalPlayer()
local HIDE_OFFSET = 100 

-- Safer map check
function checkMapCompatibility()
    local mapName = getElementData(root, "mapname") or ""
    local upperMapName = string.upper(mapName)
    
    if string.find(upperMapName, "%[DD%]") or string.find(upperMapName, "%[SH%]") then
        mapAllowed = false
        if carhide then
            carhide = false
            outputChatBox("#ff6666[HIDE] #ffffffCarhide disabled for DD/SH.", 255, 255, 255, true)
        end
    else
        mapAllowed = true
    end
end

addEventHandler("onClientResourceStart", resourceRoot, checkMapCompatibility)
addEventHandler("onClientElementDataChange", root, function(dataName)
    if dataName == "mapname" then checkMapCompatibility() end
end)

addEventHandler("onClientRender", root, function()
    if not mapAllowed then return end

    local players = getElementsByType("player")
    local myVehicle = getPedOccupiedVehicle(localPlayer)
    local target = getCameraTarget()
    
    local myDim = getElementDimension(localPlayer)
    local hiddenDim = myDim + HIDE_OFFSET
    local isGhostModeActive = getElementData(root, "ghostmode_active")

    for i = 1, #players do
        local p = players[i]
        if p ~= localPlayer then
            local veh = getPedOccupiedVehicle(p)
            if veh then
                -- Check if we are spectating this specific person
                local isSpectating = (target == p or target == veh)

                if carhide and not isSpectating then
                    -- Move to hidden dimension & make invisible
                    if getElementDimension(veh) ~= hiddenDim then
                        setElementDimension(veh, hiddenDim)
                        setElementDimension(p, hiddenDim)
                        setElementAlpha(veh, 0)
                        setElementAlpha(p, 0)
                        setPlayerNametagShowing(p, false)
                        
                        -- CRITICAL: Disable collisions physically even if in other dim
                        if myVehicle then 
                            setElementCollidableWith(myVehicle, veh, false) 
                        end
                        -- CRITICAL: Disable rotor blades explicitly
                        if getVehicleType(veh) == "Helicopter" then
                            setHeliBladeCollisionsEnabled(veh, false)
                        end
                    end
                else
                    -- Restore only if they are currently hidden
                    if getElementDimension(veh) == hiddenDim then
                        setElementDimension(veh, myDim)
                        setElementDimension(p, myDim)
                        setElementAlpha(veh, 255)
                        setElementAlpha(p, 255)
                        setPlayerNametagShowing(p, true)
                        
                        -- Restore collisions ONLY if ghostmode is NOT active
                        if not isGhostModeActive then
                            if myVehicle then 
                                setElementCollidableWith(myVehicle, veh, true) 
                            end
                            if getVehicleType(veh) == "Helicopter" then
                                setHeliBladeCollisionsEnabled(veh, true)
                            end
                        end
                    end
                end
            end
        end
    end
end)

bindKey("c", "down", function()
    if not mapAllowed then return end
    carhide = not carhide
    outputChatBox("#ff6666[HIDE] #ffffffOther players: " .. (carhide and "#ff6666HIDDEN" or "#66ff66VISIBLE"), 255, 255, 255, true)
end)