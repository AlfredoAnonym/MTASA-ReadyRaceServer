local g_MapResName

-- Multilingual Messages
local translations = {
    ['PL'] = "Ta mapa nie została jeszcze oceniona. Wpisz /rate 1-10, aby zagłosować.",
    ['RU'] = "Эта карта еще не оценена. Введите /rate 1-10, чтобы оценить.",
    ['BR'] = "Este mapa ainda não foi avaliado. Digite /rate 1-10 para avaliar.",
    ['TR'] = "Bu harita henüz derecelendirilmedi. Oylamak için /rate 1-10 yazın.",
    ['SA'] = "لم يتم تقييم هذه الخريطة بعد. اكتب /rate 1-10 لتقييمها.",
    ['EG'] = "لم يتم تقييم هذه الخريطة بعد. اكتب /rate 1-10 لتقييمها.",
    ['default'] = "This map is not yet rated. Type /rate 1-10 to rate it."
}

function getPlayerCountryCode(player)
    local country = "XX"
    if getResourceFromName("admin") and getResourceState(getResourceFromName("admin")) == "running" then
        country = exports.admin:getPlayerCountry(player) or "XX"
    elseif getResourceFromName("ip2c") and getResourceState(getResourceFromName("ip2c")) == "running" then
        country = exports.ip2c:getCountry(player) or "XX"
    end
    return string.upper(tostring(country))
end

addEventHandler('onGamemodeMapStart', root,
    function(mapres)
        g_MapResName = getResourceName(mapres)
        setTimer(announceMapRating, 2000, 1, g_MapResName) -- Small delay to ensure chat is ready
    end
)

addEventHandler('onResourceStart', resourceRoot,
    function()
        executeSQLQuery("CREATE TABLE IF NOT EXISTS mapratings (mapname TEXT, playername TEXT, rating INTEGER)")
        
        -- Ensure Index exists for speed
        executeSQLQuery("CREATE UNIQUE INDEX IF NOT EXISTS IDX_MAPRATINGS_MAPNAME_PLAYERNAME on mapRatings(mapname, playername)")
        
        -- Get current map if resource was restarted mid-game
        local currentGamemodeMap = exports.mapmanager:getRunningGamemodeMap()
        if currentGamemodeMap then
            g_MapResName = getResourceName(currentGamemodeMap)
        end
    end
)

function announceMapRating(mapResName)
    local ratingData = getMapRating(mapResName)
    
    for _, player in ipairs(getElementsByType("player")) do
        if ratingData then
            local colorHex = getRatingColorAsHex(ratingData.average)
            outputChatBox("Current Map Rating: "..colorHex..ratingData.average.."/10 #E1AA5A("..ratingData.count.." votes)", player, 225, 170, 90, true)
        else
            local cc = getPlayerCountryCode(player)
            local msg = translations[cc] or translations['default']
            outputChatBox(msg, player, 255, 100, 100, true)
        end
    end
end

-- GUI Request Handler
addEvent("requestTopMaps", true)
addEventHandler("requestTopMaps", root,
    function()
        -- Query database
        local sql = executeSQLQuery("SELECT mapname, AVG(rating) as avg_rating, COUNT(rating) as count_rating FROM mapratings GROUP BY mapname")
        
        local preparedData = {}
        
        if sql then
            for i, row in ipairs(sql) do
                local realName = row.mapname -- Default to file name
                
                -- Try to get the fancy name from meta.xml
                local res = getResourceFromName(row.mapname)
                if res then
                    local infoName = getResourceInfo(res, "name")
                    if infoName then realName = infoName end
                end
                
                table.insert(preparedData, {
                    name = realName,
                    rating = math.floor(row.avg_rating * 100 + 0.5) / 100,
                    count = row.count_rating
                })
            end
        end
        
        -- Send back to client
        triggerClientEvent(client, "receiveTopMaps", resourceRoot, preparedData)
    end
)

function updateMapRating(player, mapresname, rating)
    local playername = getPlayerName(player)
    local sql = executeSQLQuery("SELECT rating FROM mapratings WHERE mapname=? AND playername=?", mapresname, playername)
    
    if #sql > 0 then
        local success = executeSQLQuery("UPDATE mapratings SET rating=? WHERE mapname=? AND playername=?", rating, mapresname, playername)
        if not success then return end
        if sql[1].rating == rating then
            outputChatBox("You already rated this map "..getRatingColorAsHex(rating)..rating.."/10#FF0000.", player, 255, 0, 0, true)
        else
            outputChatBox("Changed rating from "..getRatingColorAsHex(sql[1].rating)..sql[1].rating.."/10 #E1AA5Ato "..getRatingColorAsHex(rating)..rating.."/10#E1AA5A.", player, 225, 170, 90, true)
        end
    else
        local success = executeSQLQuery("INSERT INTO mapratings VALUES (?,?,?)", mapresname, playername, rating)
        if not success then return end
        outputChatBox("Rated '"..(getResourceInfo(getResourceFromName(mapresname), "name") or mapresname).."' "..getRatingColorAsHex(rating)..rating.."/10#E1AA5A.", player, 225, 170, 90, true)
    end
    triggerEvent("onMapRatingChange", player, getMapRating(mapresname), rating)
end

addEvent('onPollStarting')
addEventHandler('onPollStarting', root,
    function(poll)
        for index, item in ipairs(poll) do
            if item[1] ~= "Yes" and item[1] ~= "No" then
                local mapname = item[1]
                local map = item[4]
                if map then
                    local rating = getMapRating(getResourceName(map))
                    if rating then
                        item[1] = mapname.." ("..rating.average..")"
                    end
                end
            end
        end
        triggerEvent('onPollModified', source, poll)
    end
)

function getMapRating(mapresname)
    local sql = executeSQLQuery("SELECT AVG(rating) AS avg , COUNT(rating) AS count FROM mapratings WHERE mapname=?", mapresname)
    if sql and sql[1] and sql[1].count > 0 then
        local avg = math.floor(sql[1].avg*100+0.5)/100
        return {average = avg, count = sql[1].count}
    end
    return false
end

function getPlayerRating(playername, mapresname)
    if mapresname then
        local sql = executeSQLQuery("SELECT rating FROM mapratings WHERE playername=? AND mapname=?", playername, mapresname)
        if #sql > 0 then return sql[1].rating end
    else
        local sql = executeSQLQuery("SELECT AVG(rating) AS avg , COUNT(rating) AS count FROM mapratings WHERE playername=?", playername)
        if sql[1].count > 0 then
            local avg = math.floor(sql[1].avg*100+0.5)/100
            return {average = avg, count = sql[1].count}
        end
    end
    return false
end

function getRatingColor(rating)
    local r, g = -5.1*(rating^2) + 25.5*rating + 255, -5.1*(rating^2) + 76.5*rating
    r, g = r > 255 and 255 or math.floor(r+0.5), g > 255 and 255 or math.floor(g+0.5)
    return {r,g,0}
end

function getRatingColorAsHex(rating)
    local r, g = unpack(getRatingColor(rating))
    return "#"..string.format("%02X", r)..string.format("%02X", g).."00"
end

addCommandHandler('rate',
    function(player, cmd, rating)
        rating = tonumber(rating)
        if rating and rating >= 0 and rating <= 10 then
            if g_MapResName then
                updateMapRating(player, g_MapResName, math.floor(rating*100+0.5)/100)
            else
                outputChatBox("No map is currently running.", player, 255, 0, 0)
            end
        else
            outputChatBox("Choose a rating between 0 and 10.", player, 255, 0, 0)
        end
    end
)