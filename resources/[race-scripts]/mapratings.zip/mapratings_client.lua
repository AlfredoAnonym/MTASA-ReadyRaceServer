local sx, sy = guiGetScreenSize()
local window, grid
local btnClose, btnSortBest, btnSortWorst, btnSortPopular
local isVisible = false
local cachedMapData = {} -- Stores the maps so we can sort them instantly

function createRatingsWindow()
    local width, height = 600, 500
    local x, y = (sx - width) / 2, (sy - height) / 2
    
    window = guiCreateWindow(x, y, width, height, "Server Map Ratings", false)
    guiWindowSetSizable(window, false)
    guiSetVisible(window, false)
    
    -- Sorting Buttons
    btnSortBest = guiCreateButton(0.05, 0.06, 0.28, 0.06, "Sort: Best Rated", true, window)
    btnSortWorst = guiCreateButton(0.36, 0.06, 0.28, 0.06, "Sort: Worst Rated", true, window)
    btnSortPopular = guiCreateButton(0.67, 0.06, 0.28, 0.06, "Sort: Most Votes", true, window)

    -- The Grid
    grid = guiCreateGridList(0.05, 0.14, 0.9, 0.75, true, window)
    guiGridListAddColumn(grid, "Map Name", 0.55)
    guiGridListAddColumn(grid, "Rating", 0.2)
    guiGridListAddColumn(grid, "Votes", 0.2)
    guiGridListSetSortingEnabled(grid, false) -- We use our custom buttons

    -- Close Button
    btnClose = guiCreateButton(0.35, 0.91, 0.3, 0.07, "Close", true, window)

    -- Event Handlers
    addEventHandler("onClientGUIClick", btnClose, toggleRatingsWindow, false)
    addEventHandler("onClientGUIClick", btnSortBest, function() sortMaps("best") end, false)
    addEventHandler("onClientGUIClick", btnSortWorst, function() sortMaps("worst") end, false)
    addEventHandler("onClientGUIClick", btnSortPopular, function() sortMaps("votes") end, false)
end

function toggleRatingsWindow()
    if not window then createRatingsWindow() end
    
    isVisible = not isVisible
    guiSetVisible(window, isVisible)
    showCursor(isVisible)
    
    if isVisible then
        guiGridListClear(grid)
        guiGridListSetItemText(grid, guiGridListAddRow(grid), 1, "Loading maps from server...", true, false)
        -- Request data from server
        triggerServerEvent("requestTopMaps", resourceRoot)
    end
end
bindKey("F4", "down", toggleRatingsWindow)

addEvent("receiveTopMaps", true)
addEventHandler("receiveTopMaps", resourceRoot,
    function(data)
        if not window or not isVisible then return end
        
        cachedMapData = data -- Store data for sorting
        sortMaps("best") -- Default sort
    end
)

function sortMaps(method)
    if #cachedMapData == 0 then
        guiGridListClear(grid)
        guiGridListSetItemText(grid, guiGridListAddRow(grid), 1, "No maps found.", true, false)
        return
    end

    -- Sorting Logic
    table.sort(cachedMapData, function(a, b)
        if method == "best" then
            return tonumber(a.rating) > tonumber(b.rating) -- High to Low
        elseif method == "worst" then
            return tonumber(a.rating) < tonumber(b.rating) -- Low to High
        elseif method == "votes" then
            return tonumber(a.count) > tonumber(b.count) -- High to Low
        end
    end)

    populateGrid()
end

function populateGrid()
    guiGridListClear(grid)
    
    for _, item in ipairs(cachedMapData) do
        local row = guiGridListAddRow(grid)
        guiGridListSetItemText(grid, row, 1, item.name, false, false)
        guiGridListSetItemText(grid, row, 2, tostring(item.rating), false, false)
        guiGridListSetItemText(grid, row, 3, tostring(item.count), false, false)
        
        -- Color coding
        local r, g, b = 255, 255, 255
        local rating = tonumber(item.rating)
        if rating >= 8 then r,g,b = 0, 255, 0       -- Green
        elseif rating >= 5 then r,g,b = 255, 255, 0 -- Yellow
        else r,g,b = 255, 0, 0 end                  -- Red
        
        guiGridListSetItemColor(grid, row, 2, r, g, b)
    end
end