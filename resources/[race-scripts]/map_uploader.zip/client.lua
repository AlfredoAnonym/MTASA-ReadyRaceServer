local sx, sy = guiGetScreenSize()
local winW, winH = 700, 720
local uploadWin = guiCreateWindow((sx - winW) / 2, (sy - winH) / 2, winW, winH, "MTA:SA Community Map Uploader", false)
guiWindowSetSizable(uploadWin, false)
guiSetVisible(uploadWin, false)

-- Helper function for ComboBoxes
local function createCombo(x, y, w, h, options)
    local combo = guiCreateComboBox(x, y, w, h, "", false, uploadWin)
    for _, opt in ipairs(options) do guiComboBoxAddItem(combo, opt) end
    guiComboBoxSetSelected(combo, 0)
    return combo
end

local function getComboText(combo)
    local sel = guiComboBoxGetSelected(combo)
    return (sel ~= -1) and guiComboBoxGetItemText(combo, sel) or ""
end

-- --- LEFT COLUMN ---
guiCreateLabel(20, 40, 100, 20, "Map Name:", false, uploadWin)
local editMapName = guiCreateEdit(120, 35, 180, 25, "", false, uploadWin)

guiCreateLabel(20, 75, 100, 20, "Author:", false, uploadWin)
local editAuthor = guiCreateEdit(120, 70, 180, 25, "", false, uploadWin)

guiCreateLabel(20, 110, 100, 20, "Weather ID:", false, uploadWin)
local editWeather = guiCreateEdit(120, 105, 180, 25, "0", false, uploadWin)

guiCreateLabel(20, 145, 100, 20, "Time (e.g. 12.0):", false, uploadWin)
local editTime = guiCreateEdit(120, 140, 180, 25, "12.0", false, uploadWin)

guiCreateLabel(20, 180, 100, 20, "Ghostmode:", false, uploadWin)
local comboGhost = createCombo(120, 175, 180, 80, {"yes", "no"})

guiCreateLabel(20, 215, 100, 20, "Skins:", false, uploadWin)
local comboSkins = createCombo(120, 210, 180, 80, {"cj", "random"})

-- --- RIGHT COLUMN ---
guiCreateLabel(350, 40, 100, 20, "Locked Time:", false, uploadWin)
local comboLocked = createCombo(450, 35, 180, 80, {"yes", "no"})

guiCreateLabel(350, 75, 100, 20, "Autopimp:", false, uploadWin)
local comboAutopimp = createCombo(450, 70, 180, 80, {"false", "true"})

guiCreateLabel(350, 110, 100, 20, "Veh Weapons:", false, uploadWin)
local comboWeapons = createCombo(450, 105, 180, 80, {"false", "true"})

guiCreateLabel(350, 145, 100, 20, "Duration (sec):", false, uploadWin)
local editDuration = guiCreateEdit(450, 140, 180, 25, "1800", false, uploadWin)

-- CHECKBOXES
local chkPoleremover = guiCreateCheckBox(20, 250, 150, 20, "Pole Remover", false, false, uploadWin)
local chkOffroad = guiCreateCheckBox(180, 250, 150, 20, "Offroad Wheels", false, false, uploadWin)
local chk30FPS = guiCreateCheckBox(340, 250, 100, 20, "30 FPS Cap", false, false, uploadWin)

-- --- MAP CONTENT ---
guiCreateLabel(20, 280, 300, 20, "Paste Map Code Here (.map content):", false, uploadWin)
local memoMapContent = guiCreateMemo(20, 300, 660, 150, "", false, uploadWin)

-- --- CUSTOM META SECTION ---
local chkMeta = guiCreateCheckBox(20, 460, 200, 20, "Use Custom Meta.xml", false, false, uploadWin)
guiCreateLabel(20, 485, 300, 20, "Paste Meta.xml Code Here (Optional):", false, uploadWin)
local memoMetaContent = guiCreateMemo(20, 505, 660, 150, "", false, uploadWin)

-- Default state for meta box (Blacked out)
guiSetEnabled(memoMetaContent, false)
guiSetAlpha(memoMetaContent, 0.5)

addEventHandler("onClientGUIClick", chkMeta, function()
    local isCustom = guiCheckBoxGetSelected(chkMeta)
    local alpha = isCustom and 0.5 or 1.0
    
    guiSetEnabled(memoMetaContent, isCustom)
    guiSetAlpha(memoMetaContent, isCustom and 1.0 or 0.5)
    
    -- Disable settings and set Alpha correctly for all overridden fields
    local fields = {
        editMapName, editAuthor, editWeather, editTime, 
        comboGhost, comboSkins, comboLocked, comboAutopimp, 
        comboWeapons, editDuration, chkPoleremover, chkOffroad, chk30FPS
    }
    
    for _, element in ipairs(fields) do
        guiSetEnabled(element, not isCustom)
        guiSetAlpha(element, alpha)
    end
end, false)

addEvent("poleremoverRemoveObjects", true)
addEventHandler("poleremoverRemoveObjects", root, function() end)

local btnUpload = guiCreateButton(200, 665, 120, 35, "Upload", false, uploadWin)
local btnClose = guiCreateButton(380, 665, 120, 35, "Close", false, uploadWin)

-- Toggle Function
local function toggleUploader()
    local newState = not guiGetVisible(uploadWin)
    guiSetVisible(uploadWin, newState)
    showCursor(newState)
    guiSetInputMode(newState and "no_binds_when_editing" or "allow_binds")
end

bindKey("F10", "down", toggleUploader)

addEventHandler("onClientResourceStart", resourceRoot, function()
    outputChatBox("Press F10 to use the Map Uploader!", 0, 255, 0)
end)

-- Upload Logic
addEventHandler("onClientGUIClick", btnUpload, function()
    local isCustom = guiCheckBoxGetSelected(chkMeta)
    local metaText = guiGetText(memoMetaContent)
    
    if guiGetText(memoMapContent) == "" then
        outputChatBox("[Uploader] Error: Map Content (.map) is required!", 255, 0, 0)
        return
    end

    if not isCustom and guiGetText(editMapName) == "" then
        outputChatBox("[Uploader] Error: Map Name is required!", 255, 0, 0)
        return
    end

    if isCustom and string.find(metaText, "customMapEditorScriptingExtension_s%.lua") then
        outputChatBox("[Uploader] Error: customMapEditorScriptingExtension_s.lua detected in meta. Remove that script tag to upload.", 255, 0, 0)
        return
    end

    local mapData = {
        mapName = guiGetText(editMapName),
        author = guiGetText(editAuthor),
        weather = guiGetText(editWeather),
        time = guiGetText(editTime),
        ghostmode = getComboText(comboGhost),
        respawnTime = "1", 
        skins = getComboText(comboSkins),
        lockedTime = getComboText(comboLocked),
        autopimp = getComboText(comboAutopimp),
        vehicleWeapons = getComboText(comboWeapons),
        duration = guiGetText(editDuration),
        includePole = guiCheckBoxGetSelected(chkPoleremover),
        includeOffroad = guiCheckBoxGetSelected(chkOffroad),
        fpsCap = guiCheckBoxGetSelected(chk30FPS),
        useCustomMeta = isCustom,
        metaContent = metaText
    }
    triggerServerEvent("onMapUploaderSubmit", resourceRoot, mapData, guiGetText(memoMapContent))
end, false)

addEventHandler("onClientGUIClick", btnClose, toggleUploader, false)

addEvent("onMapUploaderSuccess", true)
addEventHandler("onMapUploaderSuccess", resourceRoot, function()
    guiSetText(editMapName, "")
    guiSetText(editAuthor, "")
    guiSetText(editWeather, "0")
    guiSetText(editTime, "12.0")
    guiSetText(editDuration, "1800")
    guiSetText(memoMapContent, "")
    guiSetText(memoMetaContent, "")
    
    guiComboBoxSetSelected(comboGhost, 0)
    guiComboBoxSetSelected(comboSkins, 0)
    guiComboBoxSetSelected(comboLocked, 0)
    guiComboBoxSetSelected(comboAutopimp, 0)
    guiComboBoxSetSelected(comboWeapons, 0)

    guiCheckBoxSetSelected(chkPoleremover, false)
    guiCheckBoxSetSelected(chkOffroad, false)
    guiCheckBoxSetSelected(chk30FPS, false)
    guiCheckBoxSetSelected(chkMeta, false)
    
    guiSetEnabled(memoMetaContent, false)
    guiSetAlpha(memoMetaContent, 0.5)
    
    local fields = {
        editMapName, editAuthor, editWeather, editTime, 
        comboGhost, comboSkins, comboLocked, comboAutopimp, 
        comboWeapons, editDuration, chkPoleremover, chkOffroad, chk30FPS
    }
    for _, element in ipairs(fields) do
        guiSetEnabled(element, true)
        guiSetAlpha(element, 1.0)
    end
end)