addEvent("onMapUploaderSubmit", true)
addEventHandler("onMapUploaderSubmit", resourceRoot, function(data, mapText)
    local player = client
    
    if isGuestAccount(getPlayerAccount(player)) then
        outputChatBox("[Uploader] You must be logged in to upload maps.", player, 255, 0, 0)
        return
    end

    -- 1. Determine safe Map Name and Folder Name
    local rawName = tostring(data.mapName or "")
    if data.useCustomMeta then
        local parsedName = string.match(data.metaContent, '<info[^>]-name%s*=%s*["\']([^"\']+)["\']')
        if not parsedName then
            parsedName = string.match(data.metaContent, 'name%s*=%s*["\']([^"\']+)["\']')
        end
        if parsedName and parsedName ~= "" then 
            rawName = parsedName
        elseif rawName == "" then
            rawName = "CustomMap_" .. tostring(getTickCount())
        end
    end

    local safeFolderName = string.gsub(tostring(rawName), "%s+", "_")
    safeFolderName = string.gsub(safeFolderName, "[^%w_%-]", "")
    if not safeFolderName or safeFolderName == "" then safeFolderName = "unnamed_map_" .. tostring(getTickCount()) end

    if getResourceFromName(safeFolderName) then
        safeFolderName = safeFolderName .. "_" .. math.random(100, 999)
    end

    -- 2. Create Map Resource Folder
    local newResource = createResource(safeFolderName, "[uploaded_maps]")
    if not newResource then 
        outputChatBox("[Uploader] Critical Error: Failed to create resource folder.", player, 255, 0, 0)
        return 
    end

    -- 3. Write Map File
    local mapFile = fileCreate(":" .. safeFolderName .. "/" .. safeFolderName .. ".map")
    if mapFile then
        fileWrite(mapFile, mapText)
        fileClose(mapFile)
    else
        outputChatBox("[Uploader] Error: Could not write map file.", player, 255, 0, 0)
        return
    end

    -- 4. Set up Base Meta String & Async Fetch Queue
    local metaStr = ""
    local fetchesPending = 0
    local baseMetaGenerated = false
    local injectedTags = ""

    local function addMetaTag(tag)
        injectedTags = injectedTags .. "    " .. tag .. "\n"
    end

    -- Helper: Finalize Upload once all fetches are complete
    local function finalizeUpload()
        -- Safely inject tags before the closing </meta>
        if data.useCustomMeta then
            metaStr = string.gsub(metaStr, "</meta>", injectedTags .. "</meta>")
        else
            metaStr = metaStr .. injectedTags .. "</meta>"
        end

        local metaFile = fileCreate(":" .. safeFolderName .. "/meta.xml")
        if metaFile then
            fileWrite(metaFile, metaStr)
            fileClose(metaFile)
        end

        setResourceInfo(newResource, "type", "map")
        setResourceInfo(newResource, "name", rawName)
        if not data.useCustomMeta then
            setResourceInfo(newResource, "gamemodes", "race")
            setResourceInfo(newResource, "author", data.author)
        end

        setTimer(refreshResources, 1000, 1, false)

        if isElement(player) then
            outputChatBox("[Uploader] " .. getPlayerName(player) .. " successfully uploaded map: " .. rawName, root, 0, 255, 0)
            outputChatBox("[Uploader] To play it, type: /start " .. safeFolderName, root, 255, 200, 0)
            triggerClientEvent(player, "onMapUploaderSuccess", resourceRoot)
        end
    end

    local function checkDone()
        if baseMetaGenerated and fetchesPending == 0 then finalizeUpload() end
    end

    -- 5. Fetch Logic System
    local function fetchResourceScript(resName, fileName, scriptType, forceFallbackToMap, specificURL)
        if getResourceFromName(resName) then
            addMetaTag('<include resource="' .. resName .. '" />')
            return
        end

        fetchesPending = fetchesPending + 1
        local url = specificURL or ("https://raw.githubusercontent.com/AlfredoAnonym/MTASA-Race-Server/main/" .. resName .. "/" .. fileName)

        fetchRemote(url, function(responseData, errorInfo)
            if errorInfo == 0 then
                local createdRes = false
                
                -- Try creating global resource if not forced to map
                if not forceFallbackToMap then
                    local newRes = createResource(resName)
                    if newRes then
                        local sFile = fileCreate(":" .. resName .. "/" .. fileName)
                        if sFile then fileWrite(sFile, responseData) fileClose(sFile) end
                        
                        local mFile = fileCreate(":" .. resName .. "/meta.xml")
                        if mFile then
                            fileWrite(mFile, '<meta>\n    <script src="'..fileName..'" type="'..scriptType..'" />\n</meta>')
                            fileClose(mFile)
                        end
                        addMetaTag('<include resource="' .. resName .. '" />')
                        createdRes = true
                    end
                end

                -- Fallback: Attach directly to the uploaded map's folder
                if not createdRes then
                    local localFileName = resName .. "_" .. fileName
                    local mapFile = fileCreate(":" .. safeFolderName .. "/" .. localFileName)
                    if mapFile then
                        fileWrite(mapFile, responseData)
                        fileClose(mapFile)
                        addMetaTag('<script src="' .. localFileName .. '" type="' .. scriptType .. '" />')
                    end
                end
            else
                if isElement(player) then
                    outputChatBox("[Uploader] Warning: Could not fetch " .. resName .. " (Error " .. errorInfo .. ")", player, 255, 100, 0)
                end
            end
            fetchesPending = fetchesPending - 1
            checkDone()
        end)
    end

    -- Process Required Fetches
    if data.includePole then
        fetchResourceScript("poleremover", "client.lua", "client", false)
    end

    if data.includeOffroad then
        fetchResourceScript("forceoffroadwheels", "client.lua", "client", true) -- Forced to attach to map
    end

    if data.includeFoliage then
        fetchResourceScript("randomfoliage", "client.lua", "client", false)
    end

    if data.fpsCap then
        fetchesPending = fetchesPending + 1
        fetchRemote("https://raw.githubusercontent.com/AlfredoAnonym/MTASA-Race-Server/main/30fps_cap.lua", function(res, err)
            if err == 0 then
                local f = fileCreate(":" .. safeFolderName .. "/30fps_cap.lua")
                if f then fileWrite(f, res) fileClose(f) end
                addMetaTag('<script src="30fps_cap.lua" type="server" />')
                addMetaTag('<script src="30fps_cap.lua" type="client" />')
            end
            fetchesPending = fetchesPending - 1
            checkDone()
        end)
    end

    if data.includeMapExt then
        local extensionFiles = {
            {name = "customMapEditorScriptingExtension_s.lua", type = "server"},
            {name = "mapEditorScriptingExtension_s.lua", type = "server"},
            {name = "mapEditorScriptingExtension_c.lua", type = "client"}
        }

        for _, fileInfo in ipairs(extensionFiles) do
            fetchesPending = fetchesPending + 1
            local url = "https://raw.githubusercontent.com/AlfredoAnonym/MTASA-Race-Server/main/" .. fileInfo.name
            
            fetchRemote(url, function(res, err)
                if err == 0 then
                    local f = fileCreate(":" .. safeFolderName .. "/" .. fileInfo.name)
                    if f then
                        fileWrite(f, res)
                        fileClose(f)
                    end
                    addMetaTag('<script src="' .. fileInfo.name .. '" type="' .. fileInfo.type .. '" />')
                else
                    if isElement(player) then
                        outputChatBox("[Uploader] Warning: Could not fetch " .. fileInfo.name .. " (Error " .. tostring(err) .. ")", player, 255, 100, 0)
                    end
                end
                fetchesPending = fetchesPending - 1
                checkDone()
            end)
        end
    end

    -- Generate Meta Base Strings
    if data.useCustomMeta and data.metaContent ~= "" then
        local rawMeta = data.metaContent
        metaStr = string.gsub(rawMeta, 'src%s*=%s*"[^"]-%.map"', 'src="' .. safeFolderName .. '.map"')
        metaStr = string.gsub(metaStr, "src%s*=%s*'[^']-%.map'", "src='" .. safeFolderName .. ".map'")
    else
        local formattedTime = string.gsub(tostring(data.time), "%.", ":")
        if not formattedTime:find(":") then formattedTime = formattedTime .. ":0" end

        metaStr = string.format([[<meta>
    <info gamemodes="race" type="map" name="%s" author="%s" version="1.0.0" />
    <map src="%s.map" dimension="0" />
    <settings>
        <setting name="#ghostmode" value='[ "%s" ]' />
        <setting name="#vehicleweapons" value='[ "%s" ]' />
        <setting name="#skins" value='[ "%s" ]' />
        <setting name="#duration" value="[ %s ]" />
        <setting name="#time" value="%s" />
        <setting name="#autopimp" value='[ "%s" ]' />
        <setting name="#weather" value="[ %s ]" />
        <setting name="#locked_time" value="[ %s ]" />
        <setting name="#respawntime" value="[ 1 ]" />
    </settings>
]], 
        rawName, data.author, safeFolderName, 
        (data.ghostmode == "yes" and "true" or "false"), data.vehicleWeapons, data.skins, 
        data.duration, formattedTime, data.autopimp, data.weather, 
        (data.lockedTime == "yes" and "true" or "false"))
    end

    baseMetaGenerated = true
    checkDone()
end)