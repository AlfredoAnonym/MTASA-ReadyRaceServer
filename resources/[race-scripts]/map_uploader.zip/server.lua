addEvent("onMapUploaderSubmit", true)
addEventHandler("onMapUploaderSubmit", resourceRoot, function(data, mapText)
    local player = client
    
    if isGuestAccount(getPlayerAccount(player)) then
        outputChatBox("[Uploader] You must be logged in to upload maps.", player, 255, 0, 0)
        return
    end

    -- 1. Determine safe Map Name and Folder Name
    local rawName = tostring(data.mapName or "")
    if data.useCustomMeta then
        -- First, safely attempt to grab the name specifically from the <info> tag
        local parsedName = string.match(data.metaContent, '<info[^>]-name%s*=%s*["\']([^"\']+)["\']')
        
        -- Fallback to a general search if <info> pattern isn't found
        if not parsedName then
            parsedName = string.match(data.metaContent, 'name%s*=%s*["\']([^"\']+)["\']')
        end

        if parsedName and parsedName ~= "" then 
            rawName = parsedName
        elseif rawName == "" then
            rawName = "CustomMap_" .. tostring(getTickCount())
        end
    end

    local safeFolderName = string.gsub(tostring(rawName), "%s+", "_")
    safeFolderName = string.gsub(safeFolderName, "[^%w_%-]", "")
    
    if not safeFolderName or safeFolderName == "" then 
        safeFolderName = "unnamed_map_" .. tostring(getTickCount()) 
    end

    -- Check if resource already exists
    if getResourceFromName(safeFolderName) then
        safeFolderName = safeFolderName .. "_" .. math.random(100, 999)
    end

    -- 2. Create Resource
    local newResource = createResource(safeFolderName, "[uploaded_maps]")
    if not newResource then 
        outputChatBox("[Uploader] Critical Error: Failed to create resource folder.", player, 255, 0, 0)
        return 
    end

    -- 3. Write Map File
    local mapFile = fileCreate(":" .. safeFolderName .. "/" .. safeFolderName .. ".map")
    if mapFile then
        fileWrite(mapFile, mapText)
        fileClose(mapFile)
    else
        outputChatBox("[Uploader] Error: Could not write map file.", player, 255, 0, 0)
        return
    end

    -- 4. Handle Meta Generation
    local metaStr = ""
    if data.useCustomMeta and data.metaContent ~= "" then
        local rawMeta = data.metaContent
        metaStr = string.gsub(rawMeta, 'src%s*=%s*"[^"]-%.map"', 'src="' .. safeFolderName .. '.map"')
        metaStr = string.gsub(metaStr, "src%s*=%s*'[^']-%.map'", "src='" .. safeFolderName .. ".map'")
    else
        local formattedTime = string.gsub(tostring(data.time), "%.", ":")
        if not formattedTime:find(":") then formattedTime = formattedTime .. ":0" end

        metaStr = string.format([[
<meta>
    <info gamemodes="race" type="map" name="%s" author="%s" version="1.0.0" />
    <map src="%s.map" dimension="0" />
    <settings>
        <setting name="#ghostmode" value='[ "%s" ]' />
        <setting name="#vehicleweapons" value='[ "%s" ]' />
        <setting name="#skins" value='[ "%s" ]' />
        <setting name="#duration" value="[ %s ]" />
        <setting name="#time" value="%s" />
        <setting name="#autopimp" value='[ "%s" ]' />
        <setting name="#weather" value="[ %s ]" />
        <setting name="#locked_time" value="[ %s ]" />
        <setting name="#respawntime" value="[ 1 ]" />
    </settings>
]], 
        rawName, data.author, safeFolderName, 
        (data.ghostmode == "yes" and "true" or "false"), 
        data.vehicleWeapons, 
        data.skins, 
        data.duration, formattedTime, data.autopimp, data.weather, 
        (data.lockedTime == "yes" and "true" or "false"))

        if data.includePole then metaStr = metaStr .. '    <include resource="poleremover" />\n' end
        if data.includeOffroad then metaStr = metaStr .. '    <include resource="forceoffroadwheels" />\n' end
        
        -- Insert 30 FPS script tags correctly inside <meta>
        if data.fpsCap then 
            metaStr = metaStr .. '    <script src="30fps_cap.lua" type="server" />\n'
            metaStr = metaStr .. '    <script src="30fps_cap.lua" type="client" />\n'
        end
        
        metaStr = metaStr .. "</meta>"
    end

    -- 5. Helper function to finish upload (because fetchRemote is async)
    local function finalizeUpload()
        local metaFile = fileCreate(":" .. safeFolderName .. "/meta.xml")
        if metaFile then
            fileWrite(metaFile, metaStr)
            fileClose(metaFile)
        end

        setResourceInfo(newResource, "type", "map")
        setResourceInfo(newResource, "name", rawName)
        if not data.useCustomMeta then
            setResourceInfo(newResource, "gamemodes", "race")
            setResourceInfo(newResource, "author", data.author)
        end

        setTimer(refreshResources, 1000, 1, false)

        -- Only output if the player hasn't disconnected during the fetch
        if isElement(player) then
            outputChatBox("[Uploader] " .. getPlayerName(player) .. " successfully uploaded map: " .. rawName, root, 0, 255, 0)
            outputChatBox("[Uploader] To play it, type: /start " .. safeFolderName, root, 255, 200, 0)
            triggerClientEvent(player, "onMapUploaderSuccess", resourceRoot)
        end
    end

    -- 6. Execute fetchRemote if checked, otherwise finish immediately
    if data.fpsCap then
        local scriptURL = "https://raw.githubusercontent.com/AlfredoAnonym/MTASA-Race-Server/main/30fps_cap.lua"
        fetchRemote(scriptURL, function(responseData, errorInfo)
            if errorInfo == 0 then
                local scriptFile = fileCreate(":" .. safeFolderName .. "/30fps_cap.lua")
                if scriptFile then
                    fileWrite(scriptFile, responseData)
                    fileClose(scriptFile)
                end
            else
                if isElement(player) then
                    outputChatBox("[Uploader] Warning: Could not fetch 30fps_cap.lua (Error: " .. tostring(errorInfo) .. "). Map uploaded without cap.", player, 255, 100, 0)
                end
            end
            finalizeUpload()
        end)
    else
        finalizeUpload()
    end
end)