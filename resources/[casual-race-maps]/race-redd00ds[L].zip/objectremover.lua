local models = {
	["1412"] = false,
}


addEventHandler("onResourceStart", resourceRoot, function()
	for m, t in pairs(models) do
		if t then
			removeWorldModel(m, t.radius, t.x, t.y, t.z)
		else
			removeWorldModel(m, 10000, 0, 0, 0)
		end
	end
end)

addEventHandler("onResourceStop", resourceRoot, function()
	restoreAllWorldModels()
end)
