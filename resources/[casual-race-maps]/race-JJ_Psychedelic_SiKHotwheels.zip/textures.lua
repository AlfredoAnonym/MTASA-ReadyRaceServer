    addEventHandler('onClientResourceStart', resourceRoot,
        function()
     
            local txd = engineLoadTXD('3458.txd',true)
            engineImportTXD(txd, 3458)
            engineImportTXD(txd, 8558)
        end
)