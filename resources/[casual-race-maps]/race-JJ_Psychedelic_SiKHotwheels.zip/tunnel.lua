addEventHandler('onClientResourceStart', resourceRoot,
    function()

        local txd = engineLoadTXD('files/tunnel2.txd',true)
        engineImportTXD(txd, 2045)
 
        local dff = engineLoadDFF('files/tunnel2.dff', 0)
        engineReplaceModel(dff, 2045)
 
        local col = engineLoadCOL('files/tunnel2.col')
        engineReplaceCOL(col, 2045)
        engineSetModelLODDistance(2045, 4000)
        
        local txd = engineLoadTXD('files/tunnel.txd',true)
        engineImportTXD(txd, 2046)
 
        local dff = engineLoadDFF('files/tunnel.dff', 0)
        engineReplaceModel(dff, 2046)
 
        local col = engineLoadCOL('files/tunnel.col')
        engineReplaceCOL(col, 2046)
        engineSetModelLODDistance(2046, 4000)
    end
)