addEventHandler('onClientResourceStart', resourceRoot,
    function()
        outputChatBox ( "JJ Productions")
 
        local txd = engineLoadTXD('files/cat1.txd',true)
        engineImportTXD(txd, 2053)
 
        local dff = engineLoadDFF('files/cat1.dff', 0)
        engineReplaceModel(dff, 2053)
 
        local col = engineLoadCOL('files/cat1.col')
        engineReplaceCOL(col, 2053)
        engineSetModelLODDistance(2053, 1000)
    end
)