addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('files/pancat.txd',true)
        engineImportTXD(txd, 2051)
 
        local dff = engineLoadDFF('files/pancat.dff', 0)
        engineReplaceModel(dff, 2051)
 
        local col = engineLoadCOL('files/pancat.col')
        engineReplaceCOL(col, 2051)
        engineSetModelLODDistance(2051, 4000)
    end
)