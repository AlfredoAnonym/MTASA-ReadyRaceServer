addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('files/cat3.txd',true)
        engineImportTXD(txd, 2055)
 
        local dff = engineLoadDFF('files/cat3.dff', 0)
        engineReplaceModel(dff, 2055)
 
        local col = engineLoadCOL('files/cat3.col')
        engineReplaceCOL(col, 2055)
        engineSetModelLODDistance(2055, 1000)
    end
)