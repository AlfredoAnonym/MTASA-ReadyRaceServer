addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('files/cat2.txd',true)
        engineImportTXD(txd, 2054)
 
        local dff = engineLoadDFF('files/cat2.dff', 0)
        engineReplaceModel(dff, 2054)
 
        local col = engineLoadCOL('files/cat2.col')
        engineReplaceCOL(col, 2054)
        engineSetModelLODDistance(2054, 1000)
    end
)