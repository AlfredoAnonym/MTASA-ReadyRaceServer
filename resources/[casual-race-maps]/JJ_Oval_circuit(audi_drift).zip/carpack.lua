function replaceModel() 
  txd = engineLoadTXD("car/comet.txd", 480 )
  engineImportTXD(txd, 480)
  dff = engineLoadDFF("car/comet.dff", 480 )
  engineReplaceModel(dff, 480)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)

addCommandHandler ( "reloadcar", replaceModel )