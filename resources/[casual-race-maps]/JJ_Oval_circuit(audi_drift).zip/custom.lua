addEventHandler('onClientResourceStart', resourceRoot,
    function()
        outputChatBox ( "JJ Oval loaded")
 
        local txd = engineLoadTXD('files/oval.txd',true)
        engineImportTXD(txd, 2053)
 
        local dff = engineLoadDFF('files/oval.dff', 0)
        engineReplaceModel(dff, 2053)
 
        local col = engineLoadCOL('files/oval.col')
        engineReplaceCOL(col, 2053)
        engineSetModelLODDistance(2053, 500)
    end
)