addEventHandler('onClientResourceStart', resourceRoot,
    function()
        outputChatBox ( "JJ Productions...")
 
        local txd = engineLoadTXD('files/girls.txd',true)
        engineImportTXD(txd, 2053)
 
        local dff = engineLoadDFF('files/girls.dff', 0)
        engineReplaceModel(dff, 2053)
 
        local col = engineLoadCOL('files/girls.col')
        engineReplaceCOL(col, 2053)
        engineSetModelLODDistance(2053, 1000)
    end
)