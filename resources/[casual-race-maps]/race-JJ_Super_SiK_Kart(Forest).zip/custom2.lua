addEventHandler('onClientResourceStart', resourceRoot,
    function()

        local txd = engineLoadTXD('files/mario.txd',true)
        engineImportTXD(txd, 2054)
 
        local dff = engineLoadDFF('files/mario.dff', 0)
        engineReplaceModel(dff, 2054)
 
        local col = engineLoadCOL('files/mario.col')
        engineReplaceCOL(col, 2054)
        engineSetModelLODDistance(2054, 4000)
    end
)