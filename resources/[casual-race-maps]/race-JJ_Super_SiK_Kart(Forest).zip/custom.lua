addEventHandler('onClientResourceStart', resourceRoot, 
function() 

outputChatBox ( "JJ Productions...")
local txd = engineLoadTXD('files/circuito.txd',true)
        engineImportTXD(txd, 2053)

	
	local dff = engineLoadDFF('files/circuito.dff', 0) 
	engineReplaceModel(dff, 2053)


	local col = engineLoadCOL('files/circuito.col') 
	engineReplaceCOL(col, 2053)

		
	engineSetModelLODDistance(2053, 500)
end 
)