addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('files/mario.txd',true)
        engineImportTXD(txd, 2048)
 
        local dff = engineLoadDFF('files/mario.dff', 0)
        engineReplaceModel(dff, 2048)
 
        local col = engineLoadCOL('files/mario.col')
        engineReplaceCOL(col, 2048)
        engineSetModelLODDistance(2048, 4000)
    end
)