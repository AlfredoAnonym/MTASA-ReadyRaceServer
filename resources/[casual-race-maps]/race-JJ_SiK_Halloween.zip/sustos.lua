-- DDC OMG generated script, PLACE IT SERVER-SIDE

function omg_sustos()
  susto2 = createObject(2053, -2297.3999023438, -814, 142.60000610352, 0, 260, 220)
  omgMovesusto2(1)
  susto1 = createObject(2052, -2358.6999511719, -697.5, 176.69999694824, 0.0604248046875, 230.74584960938, 194.57336425781)
  omgMovesusto1(1)
end

function omgMovesusto2(point)
  if point == 1 then
    moveObject(susto2, 1000, -2259.3999023438, -784.20001220703, 146.39999389648, 0, 0, -11.999984741211)
    setTimer(omgMovesusto2, 1000, 1, 2)
  elseif point == 2 then
    moveObject(susto2, 1000, -2223.6999511719, -769.40002441406, 152.39999389648, 0, 0, 0)
    setTimer(omgMovesusto2, 1000, 1, 3)
  elseif point == 3 then
    moveObject(susto2, 100, -2223.6999511719, -769.40002441406, 133, 0, 0, 0)
    setTimer(omgMovesusto2, 100, 1, 4)
  elseif point == 4 then
    moveObject(susto2, 100, -2303.3999023438, -814.5, 116.19999694824, 0, 0, 0)
    setTimer(omgMovesusto2, 100, 1, 5)
  elseif point == 5 then
    moveObject(susto2, 100, -2297.3999023438, -814, 142.60000610352, 0, 0, 11.999984741211)
    setTimer(omgMovesusto2, 100, 1, 1)
  end
end

function omgMovesusto1(point)
  if point == 1 then
    moveObject(susto1, 1000, -2297.1999511719, -678, 176.69999694824, 0, -3.0517581762979e-005, -20)
    setTimer(omgMovesusto1, 1000, 1, 2)
  elseif point == 2 then
    moveObject(susto1, 100, -2297.3000488281, -679.59997558594, 155.89999389648, 0, 0, 0)
    setTimer(omgMovesusto1, 100, 1, 3)
  elseif point == 3 then
    moveObject(susto1, 100, -2365.1000976563, -693.20001220703, 155.89999389648, 0, 0, 0)
    setTimer(omgMovesusto1, 100, 1, 4)
  elseif point == 4 then
    moveObject(susto1, 100, -2358.6999511719, -697.5, 176.69999694824, 0, 3.0517581762979e-005, 20)
    setTimer(omgMovesusto1, 100, 1, 1)
  end
end

addEventHandler("onResourceStart", getResourceRootElement(getThisResource()), omg_sustos)
