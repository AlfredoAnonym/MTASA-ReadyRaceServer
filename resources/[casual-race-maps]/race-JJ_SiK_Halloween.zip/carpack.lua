function replaceModel() 
  txd = engineLoadTXD("car/club.txd", 545 )
  engineImportTXD(txd, 545)
  dff = engineLoadDFF("car/club.dff", 545 )
  engineReplaceModel(dff, 545)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)

addCommandHandler ( "reloadcar", replaceModel )