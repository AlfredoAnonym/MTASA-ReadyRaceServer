addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('files/kart.txd',true)
        engineImportTXD(txd, 2050)
 
        local dff = engineLoadDFF('files/kart.dff', 0)
        engineReplaceModel(dff, 2050)
 
        local col = engineLoadCOL('files/kart.col')
        engineReplaceCOL(col, 2050)
        engineSetModelLODDistance(2050, 2000)
    end
)