addEventHandler('onClientResourceStart', resourceRoot,
    function()
        outputChatBox ( "JJ Productions" )
        local txd = engineLoadTXD('files/sentul.txd',true)
        engineImportTXD(txd, 2052)
 
        local dff = engineLoadDFF('files/sentul.dff', 0)
        engineReplaceModel(dff, 2052)
 
        local col = engineLoadCOL('files/sentul.col')
        engineReplaceCOL(col, 2052)
        engineSetModelLODDistance(2052, 1000)
    end
)