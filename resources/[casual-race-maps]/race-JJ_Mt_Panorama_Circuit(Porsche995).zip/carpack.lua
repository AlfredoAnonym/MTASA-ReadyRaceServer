function replaceModel() 
  txd = engineLoadTXD("car/club.txd", 494 )
  engineImportTXD(txd, 494)
  dff = engineLoadDFF("car/club.dff", 494 )
  engineReplaceModel(dff, 494)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)

addCommandHandler ( "reloadcar", replaceModel )