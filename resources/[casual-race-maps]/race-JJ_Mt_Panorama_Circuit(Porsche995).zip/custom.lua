addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('files/bath.txd',true)
        engineImportTXD(txd, 2052)
 
        local dff = engineLoadDFF('files/bath.dff', 0)
        engineReplaceModel(dff, 2052)
 
        local col = engineLoadCOL('files/bath.col')
        engineReplaceCOL(col, 2052)
        engineSetModelLODDistance(2052, 1000)
    end
)