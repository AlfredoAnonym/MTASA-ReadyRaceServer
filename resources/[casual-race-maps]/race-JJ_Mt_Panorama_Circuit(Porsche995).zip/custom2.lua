addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('files/bath2.txd',true)
        engineImportTXD(txd, 2053)
 
        local dff = engineLoadDFF('files/bath2.dff', 0)
        engineReplaceModel(dff, 2053)
 
        local col = engineLoadCOL('files/bath2.col')
        engineReplaceCOL(col, 2053)
        engineSetModelLODDistance(2053, 2000)
    end
)