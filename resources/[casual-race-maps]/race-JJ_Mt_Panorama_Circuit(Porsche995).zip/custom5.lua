addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('files/bath5.txd',true)
        engineImportTXD(txd, 2056)
 
        local dff = engineLoadDFF('files/bath5.dff', 0)
        engineReplaceModel(dff, 2056)
 
        local col = engineLoadCOL('files/bath5.col')
        engineReplaceCOL(col, 2056)
        engineSetModelLODDistance(2056, 2000)
    end
)