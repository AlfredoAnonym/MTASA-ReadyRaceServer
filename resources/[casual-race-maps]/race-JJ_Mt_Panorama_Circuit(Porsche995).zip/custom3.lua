addEventHandler('onClientResourceStart', resourceRoot,
    function()
         
        local txd = engineLoadTXD('files/bath3.txd',true)
        engineImportTXD(txd, 2054)
 
        local dff = engineLoadDFF('files/bath3.dff', 0)
        engineReplaceModel(dff, 2054)
 
        local col = engineLoadCOL('files/bath3.col')
        engineReplaceCOL(col, 2054)
        engineSetModelLODDistance(2054, 2000)
    end
)