addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('files/bath4.txd',true)
        engineImportTXD(txd, 2055)
 
        local dff = engineLoadDFF('files/bath4.dff', 0)
        engineReplaceModel(dff, 2055)
 
        local col = engineLoadCOL('files/bath4.col')
        engineReplaceCOL(col, 2055)
        engineSetModelLODDistance(2055, 2000)
    end
)