addEventHandler('onClientResourceStart', resourceRoot,
    function()

        local txd = engineLoadTXD('files/bath6.txd',true)
        engineImportTXD(txd, 2057)
 
        local dff = engineLoadDFF('files/bath6.dff', 0)
        engineReplaceModel(dff, 2057)
 
        local col = engineLoadCOL('files/bath6.col')
        engineReplaceCOL(col, 2057)
        engineSetModelLODDistance(2057, 2000)
    end
)