addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('files/face.txd',true)
        engineImportTXD(txd, 2049)
 
        local dff = engineLoadDFF('files/face.dff', 0)
        engineReplaceModel(dff, 2049)
 
        local col = engineLoadCOL('files/face.col')
        engineReplaceCOL(col, 2049)
        engineSetModelLODDistance(2049, 4000)
    end
)