addEventHandler('onClientResourceStart', resourceRoot, 
function() 

local txd = engineLoadTXD('files/hell2.txd',true)
        engineImportTXD(txd, 2053)

	
	local dff = engineLoadDFF('files/hell2.dff', 0) 
	engineReplaceModel(dff, 2053)


	local col = engineLoadCOL('files/hell2.col') 
	engineReplaceCOL(col, 2053)

		
	engineSetModelLODDistance(2053, 500)
end 
)