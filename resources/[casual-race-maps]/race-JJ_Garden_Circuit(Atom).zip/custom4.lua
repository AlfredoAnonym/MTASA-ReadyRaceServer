addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('files/ebay.txd',true)
        engineImportTXD(txd, 2051)
 
        local dff = engineLoadDFF('files/ebay.dff', 0)
        engineReplaceModel(dff, 2051)
 
        local col = engineLoadCOL('files/ebay.col')
        engineReplaceCOL(col, 2051)
        engineSetModelLODDistance(2051, 4000)
    end
)