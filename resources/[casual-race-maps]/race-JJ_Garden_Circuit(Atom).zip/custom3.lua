addEventHandler('onClientResourceStart', resourceRoot, 
function() 

local txd = engineLoadTXD('files/hell3.txd',true)
        engineImportTXD(txd, 2054)

	
	local dff = engineLoadDFF('files/hell3.dff', 0) 
	engineReplaceModel(dff, 2054)


	local col = engineLoadCOL('files/hell3.col') 
	engineReplaceCOL(col, 2054)

		
	engineSetModelLODDistance(2054, 500)
end 
)