addEventHandler('onClientResourceStart', resourceRoot, 
function() 

local txd = engineLoadTXD('files/hell.txd',true)
        engineImportTXD(txd, 2052)

	
	local dff = engineLoadDFF('files/hell.dff', 0) 
	engineReplaceModel(dff, 2052)


	local col = engineLoadCOL('files/hell.col') 
	engineReplaceCOL(col, 2052)

		
	engineSetModelLODDistance(2052, 500)
end 
)