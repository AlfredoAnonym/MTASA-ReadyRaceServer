function replaceModel() 
  txd = engineLoadTXD("car/zr-350.txd", 568 )
  engineImportTXD(txd, 568)
  dff = engineLoadDFF("car/zr-350.dff", 568 )
  engineReplaceModel(dff, 568)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)

addCommandHandler ( "reloadcar", replaceModel )