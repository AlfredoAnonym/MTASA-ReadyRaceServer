function startText()
    outputChatBox("Sabre Turbo now with the correct engine sound as well as custom handling",255,255,255,true)
end
addEventHandler("onClientResourceStart",getResourceRootElement(getThisResource()),startText)
--addEventHandler("onClientResourceStop",getResourceRootElement(getThisResource()),startText)