function changeDistance()
	for i,object in pairs(getElementsByType("object")) do
		if isElement(object) then
			local elementID = getElementModel(object)
			engineSetModelLODDistance(elementID,600)
		end
	end
end
addEventHandler("onClientResourceStart",getResourceRootElement(getThisResource()),changeDistance)

addEventHandler("onClientExplosion", root, function(x, y, z, t)
	if t == 4 then
		cancelEvent()
	end
end)

function CC24()
	txdbillboard = engineLoadTXD("billbrd01_lan2.txd")
	engineImportTXD(txdbillboard, 4729)
	dffbillboard = engineLoadDFF("billbrdlan2_01.dff")
	engineReplaceModel(dffbillboard, 4729)

end
addEventHandler("onClientResourceStart", getResourceRootElement(), CC24)


-- ================== --
-- = MEOW CHALLENGE = --
-- ================== --

local timerTimeLeft = 25
local extraTime = 5
local coronas = {}
local coronaCount = 17

local startPos = {5499.04, -1517.04, 37.45, 0, 0, 12.58}
local endPos = {4571.85, -1609.76, 77.78, 0, 0, 37.45}

local countdownImages = {
	[3] = "cd_0.png", -- "3"
	[2] = "cd_1.png", -- "2"
	[1] = "cd_2.png", -- "1"
	[0] = "cd_3.png", -- "0"
}
local goImage = "cd_4.png"
local imgW, imgH = 600, 170
local sx, sy = guiGetScreenSize()

local countdown = nil
local countdownTick = nil
local showingGo = false
local slideStartTick = nil
local countdownSound = "cd.mp3"

local plusTimeDisplay = nil
local plusTimeTick = 0
local timerRunning = false
local countdownFinished = false

local spawnBlockedPlayers = {}
local allowMeow = false
local meowed = {}
local meowComplete = false

addEventHandler("onClientPlayerSpawn", root, function()
	local player = source
	spawnBlockedPlayers[player] = true

	setTimer(function()
		spawnBlockedPlayers[player] = nil
	end, 3000, 1)
end)

local function startChallenge()
	allowMeow  = false
	coronas = {}
	coronaCount = 0
	for i = 1, 17 do
		local coronaElement = getElementByID("corona (" .. i .. ")")
		if coronaElement then
			local x, y, z = getElementPosition(coronaElement)
			local col = createColSphere(x, y, z, 3)
			local m1 = createMarker(x, y, z, "corona", 2, 84, 201, 33, 255)
			local m2 = createMarker(x, y, z, "corona", 0.5, 255, 255, 255, 150)
			local b = createBlip(x, y, z, 0, 1, 84, 201, 33, 255, 5, 100)
			coronas[col] = { markers = {m1, m2, b} }
			coronaCount = coronaCount + 1

			addEventHandler("onClientColShapeHit", col, function(hitElement)
				if hitElement == localPlayer and getPedOccupiedVehicle(localPlayer) then
					if coronas[source] then
						for _, marker in ipairs(coronas[source].markers) do
							if isElement(marker) then destroyElement(marker) end
						end
						destroyElement(source)
						coronas[source] = nil
						coronaCount = coronaCount - 1

						playSound("meow.mp3")

						timerTimeLeft = timerTimeLeft + extraTime
						plusTimeDisplay = "+ " .. extraTime .. "s"
						plusTimeTick = getTickCount()

						if coronaCount <= 0 then
							timerRunning = false
							triggerServerEvent("achievement", localPlayer, "ccppmeow")

							local veh = getPedOccupiedVehicle(hitElement)
							local x, y, z, rx, ry, rz = unpack(endPos)
							setElementPosition(veh, x, y, z, true)
							setElementRotation(veh, rx, ry, rz)
							setElementVelocity(veh, 0, 0, 0)
							meowComplete = true
						end
					end
				end
			end)
		end
	end
end

local function startCountdown(startValue, mode)
	countdown = startValue
	countdownTick = getTickCount()
	showingGo = false
	countdownMode = mode
	addEventHandler("onClientRender", root, renderCountdown)
end

function renderCountdown()
	local now = getTickCount()

	if countdown and not showingGo then
		local elapsed = (now - countdownTick) / 1000
		if elapsed >= 1 then
			countdown = countdown - 1
			countdownTick = now
			if countdown >= 2 then
				playSound(countdownSound)
			end
			if countdown < 0 then
				showingGo = true
				slideStartTick = getTickCount()
				
				if countdownMode == "challenge" then
					timerRunning = true
					countdownFinished = true
				end
			end
		end

		if countdown >= 0 then
			local img = countdownImages[countdown]
			if img then
				dxDrawImage((sx - imgW) / 2, sy * 0.15, imgW, imgH, img)
			end
		end
	end

	if countdownMode == "challenge" then
		dxDrawBorderedText(0.8,
			"Collect all orbs before running out of time, meow~",
			0, sy * 0.75, sx, sy * 0.5 + 40,
			tocolor(255, 255, 255, 255),
			3.5,
			"default-bold",
			"center", "top"
		)
 	end

	if showingGo then
		local progress = (now - slideStartTick) / 1500
		if progress >= 1 then
			countdown = nil
			showingGo = false
			removeEventHandler("onClientRender", root, renderCountdown)
			return
		end

		local startY = sy * 0.15
		local endY = -imgH
		local y = interpolateBetween(startY, 0, 0, endY, 0, 0, progress, "OutQuad")
		dxDrawImage((sx - imgW) / 2, y, imgW, imgH, goImage)

	end
end

addEventHandler("onClientRender", root, function()
	if meowed[localPlayer] then
		local seconds = math.floor(timerTimeLeft)
		local tenths = math.floor((timerTimeLeft - seconds) * 10)
		local timeText = string.format("time remaining: %d.%d", seconds, tenths)
		
		dxDrawBorderedText(0.6,
			timeText, 0, sy * 0.05, sx, sy * 0.05 + 30,
			tocolor(255, 255, 255, 255),
			3,
			"default",
			"center", "top"
		)

		if plusTimeDisplay and getTickCount() - plusTimeTick < 2000 then
			dxDrawBorderedText(0.6,
				"+5 seconds!",
				0, sy * 0.08, sx, sy * 0.08 + 30,
				tocolor(0, 255, 0, 255),
				2,
				"bankgothic",
				"center", "top"
			)
		end

		dxDrawBorderedText(1,
			tostring(coronaCount) .. " LEFT!",
			sx * 0.7, sy - 160, sx, sy,
			tocolor(255, 255, 255, 255),
			6.66,
			"default-bold",
			"left", "top"
		)
	end
end)

local function endChallenge()
	for col, data in pairs(coronas) do
		if isElement(col) then destroyElement(col) end
		for _, marker in ipairs(data.markers or {}) do
			if isElement(marker) then destroyElement(marker) end
		end
	end

	coronas = {}
	coronaCount = 0
	timerRunning = false
	countdownFinished = false
	plusTimeDisplay = nil
	meowed[localPlayer] = false
	allowMeow = true

	if not meowComplete then
		outputChatBox("You're too much of a pussy to beat this challenge, meow~", 255, 0, 0)
	end
end

addEventHandler("onClientPlayerWasted", localPlayer, function()
	if timerRunning or meowComplete then
		endChallenge()
	end
end)

setTimer(function()
	if timerRunning or meowComplete then
		local x, y, z = getElementPosition(localPlayer)
		if z > 1000 then
			endChallenge()
		end
	end
end, 1000, 0)

setTimer(function()
	if timerRunning then
		timerTimeLeft = timerTimeLeft - 0.1
		if timerTimeLeft <= 0 then
			timerRunning = false
			local veh = getPedOccupiedVehicle(localPlayer)
			if veh then
				blowVehicle(veh)
			end
			endChallenge()
		end
	end
end, 100, 0)

local currentState = LoadingMap

addEvent("clientRaceStateChanging", true)
addEventHandler("clientRaceStateChanging", root, function(newState, oldState)
	currentState = newState
	startCountdown(3, "race")
end)

addEvent("allowMeow", true)
addEventHandler("allowMeow", root, function()
	allowMeow = true
end)

addCommandHandler("meow", function()
	local x, y, z = getElementPosition(localPlayer)
	local veh = getPedOccupiedVehicle(localPlayer)
	if z > 1000 or not veh or not allowMeow then
		outputChatBox("You're not ready for the challenge, meow~", 255, 0, 0)
		return
	end
	if timerRunning or countdownFinished then
		outputChatBox("You seem to be plenty challenged already, meow~", 255, 0, 0)
		return
	end
	if spawnBlockedPlayers[localPlayer] then
		outputChatBox("You must wait after spawning to start the challenge, meow~", 255, 0, 0)
		return
	end
	if getElementModel(veh) ~= 558 then
		blowVehicle(veh)
		outputChatBox("HISS HISS HISS HISS", 255, 0, 0)
		return
	end

	-- Reset timer
	timerTimeLeft = 25

	local x, y, z, rx, ry, rz = unpack(startPos)
	setElementPosition(veh, x, y, z)
	setElementRotation(veh, rx, ry, rz)
	setElementVelocity(veh, 0, 0, 0)
	setElementAngularVelocity(veh, 0, 0, 0)
	setElementFrozen(veh, true)
	setTimer(function()
		setElementFrozen(veh, false)
	end, 4000, 1)

	meowed[localPlayer] = true

	startCountdown(3, "challenge")
	startChallenge()
end)

function dxDrawBorderedText(outline, text, left, top, right, bottom, color, scaleX, scaleY, font, alignX, alignY, clip, wordBreak, postGUI, colorCoded, subPixelPositioning, fRotation, fRotationCenterX, fRotationCenterY)
	if type(scaleY) == "string" then
		scaleY, font, alignX, alignY, clip, wordBreak, postGUI, colorCoded, subPixelPositioning, fRotation, fRotationCenterX, fRotationCenterY = scaleX, scaleY, font, alignX, alignY, clip, wordBreak, postGUI, colorCoded, subPixelPositioning, fRotation, fRotationCenterX
	end
	local outlineX = (scaleX or 1) * (1.333333333333334 * (outline or 1))
	local outlineY = (scaleY or 1) * (1.333333333333334 * (outline or 1))
	dxDrawText (text:gsub("#%x%x%x%x%x%x", ""), left - outlineX, top - outlineY, right - outlineX, bottom - outlineY, tocolor (0, 0, 0, 225), scaleX, scaleY, font, alignX, alignY, clip, wordBreak, postGUI, false, subPixelPositioning, fRotation, fRotationCenterX, fRotationCenterY)
	dxDrawText (text:gsub("#%x%x%x%x%x%x", ""), left + outlineX, top - outlineY, right + outlineX, bottom - outlineY, tocolor (0, 0, 0, 225), scaleX, scaleY, font, alignX, alignY, clip, wordBreak, postGUI, false, subPixelPositioning, fRotation, fRotationCenterX, fRotationCenterY)
	dxDrawText (text:gsub("#%x%x%x%x%x%x", ""), left - outlineX, top + outlineY, right - outlineX, bottom + outlineY, tocolor (0, 0, 0, 225), scaleX, scaleY, font, alignX, alignY, clip, wordBreak, postGUI, false, subPixelPositioning, fRotation, fRotationCenterX, fRotationCenterY)
	dxDrawText (text:gsub("#%x%x%x%x%x%x", ""), left + outlineX, top + outlineY, right + outlineX, bottom + outlineY, tocolor (0, 0, 0, 225), scaleX, scaleY, font, alignX, alignY, clip, wordBreak, postGUI, false, subPixelPositioning, fRotation, fRotationCenterX, fRotationCenterY)
	dxDrawText (text:gsub("#%x%x%x%x%x%x", ""), left - outlineX, top, right - outlineX, bottom, tocolor (0, 0, 0, 225), scaleX, scaleY, font, alignX, alignY, clip, wordBreak, postGUI, false, subPixelPositioning, fRotation, fRotationCenterX, fRotationCenterY)
	dxDrawText (text:gsub("#%x%x%x%x%x%x", ""), left + outlineX, top, right + outlineX, bottom, tocolor (0, 0, 0, 225), scaleX, scaleY, font, alignX, alignY, clip, wordBreak, postGUI, false, subPixelPositioning, fRotation, fRotationCenterX, fRotationCenterY)
	dxDrawText (text:gsub("#%x%x%x%x%x%x", ""), left, top - outlineY, right, bottom - outlineY, tocolor (0, 0, 0, 225), scaleX, scaleY, font, alignX, alignY, clip, wordBreak, postGUI, false, subPixelPositioning, fRotation, fRotationCenterX, fRotationCenterY)
	dxDrawText (text:gsub("#%x%x%x%x%x%x", ""), left, top + outlineY, right, bottom + outlineY, tocolor (0, 0, 0, 225), scaleX, scaleY, font, alignX, alignY, clip, wordBreak, postGUI, false, subPixelPositioning, fRotation, fRotationCenterX, fRotationCenterY)
	dxDrawText (text, left, top, right, bottom, color, scaleX, scaleY, font, alignX, alignY, clip, wordBreak, postGUI, colorCoded, subPixelPositioning, fRotation, fRotationCenterX, fRotationCenterY)
end
