-- ============================================================================
--  LOS SANTOS STROLL - FIRST PERSON RACE SCRIPT (FINAL STABLE VERSION + WINDOW FIX)
--  Features: Chassis-locked Camera, Animated Text, Input Lock, Forced Permanent Window Removal
--  Author: Gemini (for Jacob)
-- ============================================================================

local isOurMap = false
local fpActive = false
local mapStartTime = 0

-- ============================================================================
--  CONFIGURATION
-- ============================================================================

-- Camera Position (Tuned for FLASH)
-- X = Left/Right (Negative is Left)
-- Y = Forward/Back (Negative is Back)
-- Z = Up/Down (Positive is Up)
-- FINAL: (-0.50 = slightly left, -0.40 = slightly forward, 0.40 = down)
local camOffset = Vector3(-0.50, -0.40, 0.40) 

-- Text Timing Settings (in milliseconds)
local TIME_DELAY    = 3500
local TIME_FADE_IN  = 2000
local TIME_HOLD     = 4000
local TIME_FADE_OUT = 2000

-- Text Content
local titleText  = "Los Santos Stroll - First Person Race Map"
local authorText = "Made by Jacob"

-- ============================================================================
--  WINDSHIELD LOGIC (Cracked Fix - using setVehiclePanelState)
-- ============================================================================
local WINDSCREEN_PANEL_ID = 4
local BROKEN_STATE = 3 -- State 3 means severely damaged/removed

local function removeWindshield(veh)
    -- Panel state 3 means "removed" (no glass visible).
    -- Setting the side windows to 'open' also removes their rendering, which helps clear the view.
    setVehiclePanelState(veh, WINDSCREEN_PANEL_ID, BROKEN_STATE, false, false)
    
    -- Remove the main front side windows
    setVehicleWindowOpen(veh, 2, true) -- Right Front Window
    setVehicleWindowOpen(veh, 4, true) -- Left Front (Driver) Window
    
    -- Attempt to remove rear windows too (for multi-seater vehicles)
    setVehicleWindowOpen(veh, 3, true) -- Right Back Window
    setVehicleWindowOpen(veh, 5, true) -- Left Back Window
end

local function restoreWindshield(veh)
    -- Panel state 0 is "undamaged" (glass restored)
    setVehiclePanelState(veh, WINDSCREEN_PANEL_ID, 0, false, false)
    
    -- Close all windows
    setVehicleWindowOpen(veh, 2, false) 
    setVehicleWindowOpen(veh, 4, false) 
    setVehicleWindowOpen(veh, 3, false)
    setVehicleWindowOpen(veh, 5, false)
end

-- FIX 1: Add handler to re-remove the glass if the vehicle takes damage (crash)
-- We use the full argument list when attached to 'root' for stability.
addEventHandler("onClientVehicleDamage", root, function(loss, component, attacker, damagedVehicle)
    local currentVeh = getPedOccupiedVehicle(localPlayer)
    
    -- FIX 2: Safely check for damage and active state to prevent the NIL error.
    -- 'damagedVehicle' is the vehicle element when attached to root.
    if damagedVehicle == currentVeh and fpActive and type(loss) == "number" and loss > 0 then
        -- This forces the glass to be "removed" again.
        removeWindshield(currentVeh)
    end
end)

-- ============================================================================
--  CAMERA LOGIC (Matrix Locked)
-- ============================================================================
local function updateFPCamera()
    if not fpActive then return end

    local veh = getPedOccupiedVehicle(localPlayer)
    if not veh or getPedOccupiedVehicleSeat(localPlayer) ~= 0 then
        restoreCamera()
        return
    end
    
    -- FIX 3: CALL REMOVE WINDOWS EVERY FRAME TO GUARANTEE THEY NEVER CRACK
    removeWindshield(veh)

    -- 1. Get the Vehicle's Matrix (Coordinate System)
    local matrix = getElementMatrix(veh)
    
    -- Extract direction vectors
    local mRight = Vector3(matrix[1][1], matrix[1][2], matrix[1][3])
    local mFwd   = Vector3(matrix[2][1], matrix[2][2], matrix[2][3])
    local mUp    = Vector3(matrix[3][1], matrix[3][2], matrix[3][3])
    local mPos   = Vector3(matrix[4][1], matrix[4][2], matrix[4][3])

    -- 2. Calculate Camera Position
    local camPos = mPos + (mRight * camOffset.x) + (mFwd * camOffset.y) + (mUp * camOffset.z)

    -- 3. Calculate Look-At Target
    -- Look far forward (20 units), slight tilt down (-0.2)
    local targetPos = camPos + (mFwd * 20) + (mUp * -0.2)

    -- 4. Get Roll (for loops/ramps)
    local _, ry, _ = getElementRotation(veh)

    -- 5. Set Camera
    setCameraMatrix(camPos.x, camPos.y, camPos.z, targetPos.x, targetPos.y, targetPos.z, ry, 85)
end

-- ============================================================================
--  3D TEXT LOGIC (Unchanged)
-- ============================================================================
local function renderIntroText()
    local now = getTickCount()
    local elapsed = now - mapStartTime

    if elapsed < TIME_DELAY then return end

    local alpha = 0
    local animProgress = 0 

    local totalTime = TIME_DELAY + TIME_FADE_IN + TIME_HOLD + TIME_FADE_OUT

    if elapsed < (TIME_DELAY + TIME_FADE_IN) then
        local progress = (elapsed - TIME_DELAY) / TIME_FADE_IN
        alpha = 255 * progress
        animProgress = progress
    elseif elapsed < (TIME_DELAY + TIME_FADE_IN + TIME_HOLD) then
        alpha = 255
        animProgress = 1
    elseif elapsed < totalTime then
        local fadeOutStart = TIME_DELAY + TIME_FADE_IN + TIME_HOLD
        local progress = (elapsed - fadeOutStart) / TIME_FADE_OUT
        alpha = 255 * (1 - progress) 
        animProgress = 1 + (progress * 0.2) 
    else
        removeEventHandler("onClientRender", root, renderIntroText)
        return
    end

    if alpha > 255 then alpha = 255 end
    if alpha < 0 then alpha = 0 end

    local sx, sy = guiGetScreenSize()
    local startY = sy * 0.3
    local endY = sy * 0.25
    local currentY = startY + ((endY - startY) * animProgress)

    -- Draw Title
    dxDrawText(titleText, 2, currentY + 2, sx + 2, sy + 2, tocolor(0, 0, 0, alpha), 2.0, "default-bold", "center", "top")
    dxDrawText(titleText, 0, currentY, sx, sy, tocolor(255, 200, 0, alpha), 2.0, "default-bold", "center", "top")

    -- Draw Author
    local gap = 40 
    dxDrawText(authorText, 2, currentY + gap + 2, sx + 2, sy + 2, tocolor(0, 0, 0, alpha), 1.5, "default", "center", "top")
    dxDrawText(authorText, 0, currentY + gap, sx, sy, tocolor(255, 255, 255, alpha), 1.5, "default", "center", "top")
end

-- ============================================================================
--  EVENTS & ACTIVATION
-- ============================================================================
function enableFP()
    if fpActive then return end
    fpActive = true
    mapStartTime = getTickCount()
    
    -- Disable the V key
    toggleControl("change_camera", false) 
    
    local veh = getPedOccupiedVehicle(localPlayer)
    if veh then
        -- Initial window removal
        removeWindshield(veh)
    end
    
    addEventHandler("onClientPreRender", root, updateFPCamera)
    addEventHandler("onClientRender", root, renderIntroText)
end

function restoreCamera()
    if not fpActive then return end
    fpActive = false
    
    -- Restore controls
    toggleControl("change_camera", true)
    
    local veh = getPedOccupiedVehicle(localPlayer)
    if veh then
        restoreWindshield(veh)
    end

    removeEventHandler("onClientPreRender", root, updateFPCamera)
    removeEventHandler("onClientRender", root, renderIntroText)
    setCameraTarget(localPlayer)
end

addEventHandler("onClientResourceStart", resourceRoot, function()
    local name = getResourceName(getThisResource())
    if name == "fp-lossantosstroll" or name:find("lossantosstroll") or true then
        isOurMap = true
        if isPedInVehicle(localPlayer) then
            enableFP()
        end
    end
end)

addEventHandler("onClientPlayerVehicleEnter", localPlayer, function(veh, seat)
    if isOurMap and seat == 0 then
        enableFP()
    end
end)

addEventHandler("onClientPlayerVehicleExit", localPlayer, function(veh)
    restoreCamera()
    if veh then
        restoreWindshield(veh) 
    end
end)

addEventHandler("onClientResourceStop", resourceRoot, function()
    restoreCamera()
end)