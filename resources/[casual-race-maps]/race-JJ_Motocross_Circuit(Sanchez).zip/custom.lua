addEventHandler('onClientResourceStart', resourceRoot,
    function()
        outputChatBox ( "Motocross circuit loaded")
 
        local txd = engineLoadTXD('files/motocross.txd',true)
        engineImportTXD(txd, 2053)
 
        local dff = engineLoadDFF('files/motocross.dff', 0)
        engineReplaceModel(dff, 2053)
 
        local col = engineLoadCOL('files/motocross.col')
        engineReplaceCOL(col, 2053)
        engineSetModelLODDistance(2053, 500)
    end
)