-- DDC OMG generated script, PLACE IT SERVER-SIDE

function omg_holo()
  holo3 = createObject(2039, -1073, -3965, 15, 88, 180, 180)
  holo3Attach1 = createObject(2040, -1075.5999755859, -3965.8000488281, 14.10000038147, 270, 179, 180)
  attachElements(holo3Attach1, holo3, 2.5999755859375, 0.80004858970642, -0.89999961853027, -178, -1, 0)
  omgMoveholo3(1)
  holo5 = createObject(2040, -924, -3718, 14, 270, 179, 180)
  holo5Attach1 = createObject(2039, -924, -3718, 14, 88, 180, 180)
  attachElements(holo5Attach1, holo5, -0, 0, 0, 178, 1, 0)
  omgMoveholo5(1)
  holo2 = createObject(2039, -642, -3591, 39, 88, 180, 180)
  holo2Attach1 = createObject(2040, -642, -3591, 39, 270, 179, 180)
  attachElements(holo2Attach1, holo2, -0, 0, 0, -178, -1, 0)
  omgMoveholo2(1)
  holoa1 = createObject(2039, -886, -3463, 14, 88, 180, 180)
  holoa1Attach1 = createObject(2040, -886, -3463, 14, 270, 179, 180)
  attachElements(holoa1Attach1, holoa1, -0, 0, 0, -178, -1, 0)
  omgMoveholoa1(1)
end

function omgMoveholo3(point)
    moveObject(holo3, 1000, -1073, -3965, 15, 0, 180, 0)
    setTimer(moveObject, 1000, 0, holo3, 1000, -1073, -3965, 15, 0, 180, 0)
end

function omgMoveholo5(point)
    moveObject(holo5, 1000, -924, -3718, 14, 0, 180, 0)
    setTimer(moveObject, 1000, 0, holo5, 1000, -924, -3718, 14, 0, 180, 0)
end

function omgMoveholo2(point)
    moveObject(holo2, 1000, -642, -3591, 39, 0, 180, 0)
    setTimer(moveObject, 1000, 0, holo2, 1000, -642, -3591, 39, 0, 180, 0)
end

function omgMoveholoa1(point)
    moveObject(holoa1, 1000, -886, -3463, 14, 0, 180, 0)
    setTimer(moveObject, 1000, 0, holoa1, 1000, -886, -3463, 14, 0, 180, 0)
end

addEventHandler("onResourceStart", getResourceRootElement(getThisResource()), omg_holo)
