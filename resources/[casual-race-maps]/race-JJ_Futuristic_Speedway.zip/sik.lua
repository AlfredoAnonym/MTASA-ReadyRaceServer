addEventHandler('onClientResourceStart', resourceRoot,
    function()

    local txd = engineLoadTXD('files/sik.txd',true)
        engineImportTXD(txd, 2039)
 
        local dff = engineLoadDFF('files/sik.dff', 0)
        engineReplaceModel(dff, 2039)
 
        local col = engineLoadCOL('files/sik.col')
        engineReplaceCOL(col, 2039)
        engineSetModelLODDistance(2039, 4000)
    end
)