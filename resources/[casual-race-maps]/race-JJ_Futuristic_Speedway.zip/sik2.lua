addEventHandler('onClientResourceStart', resourceRoot,
    function()

        local txd = engineLoadTXD('files/sik2.txd',true)
        engineImportTXD(txd, 2040)
 
        local dff = engineLoadDFF('files/sik2.dff', 0)
        engineReplaceModel(dff, 2040)
 
        local col = engineLoadCOL('files/sik2.col')
        engineReplaceCOL(col, 2040)
        engineSetModelLODDistance(2040, 4000)
    end
)