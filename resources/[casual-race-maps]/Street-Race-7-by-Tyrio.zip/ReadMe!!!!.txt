Map is playable on a server without needing of download on MTA:SA also. IP here:

mtasa://144.76.57.59:28773

Installation:

- put ghostmode.zip to the resource folder of MTA:SA (server/mods/deathmatch/resources)
- put the map .zip file in the same folder as ghostmode
- replace race_client.lua on gamemodes / race / race to make the map run with 1 spawnpoint only (unpack the race resource from the zip and replace race_client)