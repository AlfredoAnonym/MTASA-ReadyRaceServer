addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('Files/dsher.txd',true)
        engineImportTXD(txd, 288)
 
        local dff = engineLoadDFF('Files/dsher.dff', 0)
        engineReplaceModel(dff, 288)

        local txd = engineLoadTXD('Files/infernus.txd',true)
        engineImportTXD(txd, 411)

        local dff = engineLoadDFF('Files/infernus.dff', 0)
        engineReplaceModel(dff, 411)

        local txd = engineLoadTXD('Files/1337.txd',true)
        engineImportTXD(txd, 1337)

        local dff = engineLoadDFF('Files/1337.dff', 0)
        engineReplaceModel(dff, 1337)

	end 
)
