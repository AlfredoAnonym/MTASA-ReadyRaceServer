addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('Files/dsher.txd',true)
        engineImportTXD(txd, 2438)
 
        local dff = engineLoadDFF('Files/dsher.dff', 0)
        engineReplaceModel(dff, 2438)

        local col = engineLoadCOL('Files/dsher.col', 0)
        engineReplaceModel(col, 2438)

	end 
)
