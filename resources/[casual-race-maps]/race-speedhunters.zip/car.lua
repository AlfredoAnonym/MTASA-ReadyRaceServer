addEventHandler('onClientResourceStart', resourceRoot, 
function() 
	txd = engineLoadTXD ( "texture.txd" )
	engineImportTXD ( txd, 451 )

	dff = engineLoadDFF ( "model.dff", 451 )
	engineReplaceModel ( dff, 451 )
end)