local screenWidth,screenHeight = guiGetScreenSize()  -- Get screen resolution.


function renderDisplay ( )
    local seconds = getTickCount() / 1000
    local angle = math.sin(seconds) * 80
    -- This will draw the graphic file 'test.png' at the top middle of the screen
    -- using the size of 100 pixels wide, and 240 pixels high.
    -- The center of rotation is at the top of the image.
    dxDrawImage ( screenWidth/2 - 50, 0, 100, 240, 'test.png', angle, 0, -120 )
end


function HandleTheRendering ( )
    addEventHandler("onClientRender", getRootElement(), renderDisplay)  -- Keep everything visible with onClientRender.
end
addEventHandler("onClientResourceStart",resourceRoot, HandleTheRendering)
