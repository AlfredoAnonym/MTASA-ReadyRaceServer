addEventHandler('onClientResourceStart', resourceRoot,
    function()
    outputChatBox ( "curvas derechas")
 
        local txd = engineLoadTXD('files/vallalarga.txd',true)
        engineImportTXD(txd, 2053)
 
        local dff = engineLoadDFF('files/vallalarga.dff', 0)
        engineReplaceModel(dff, 2053)
 
        local col = engineLoadCOL('files/vallalarga.col')
        engineReplaceCOL(col, 2053)
        engineSetModelLODDistance(2053, 4000)
    end
)