function handling()
	for _,veh in pairs(getElementsByType("vehicle")) do
		if getElementModel(veh) == 558 then
			setVehicleHandling(veh,"collisionDamageMultiplier",0.3)
		end
	end
end
addEventHandler("onPlayerVehicleEnter",getRootElement(),handling)

function onStart()
	setCloudsEnabled(false)
	setFogDistance(10)
	setFarClipDistance(300)
end
addEventHandler("onResourceStart", resourceRoot, onStart)

-- ================== --
-- = MEOW CHALLENGE = --
-- ================== --

addEventHandler("onRaceStateChanging", root, function(newState, oldState)
	currentState = newState
	if oldState == "PreGridCountdown" and newState == "GridCountdown" then
		triggerClientEvent(root, "clientRaceStateChanging", root, newState, oldState)
	end

	if newState == "Running" then
		triggerClientEvent(root, "allowMeow", root)
	end
end)

addEventHandler("onPlayerJoin", root, function()
	if currentState == "Running" then
		triggerClientEvent(source, "allowMeow", root)
	end
end)

addEvent("achievement", true)
addEventHandler("achievement", root, function(achievementID)
	if exports.achievements then
		exports.achievements:triggerAchievement(client, achievementID, nil)
	end
end)

addEvent("onPlayerFinish")
addEventHandler("onPlayerFinish", root, function()
	local player = source
	if not isElement(player) then return end

	setTimer(function()
		outputChatBox("How about you try the #FFFFFF/meow #FF0000challenge next time, meow~", player, 255, 0, 0, true)
	end, 1500, 1)
end)
