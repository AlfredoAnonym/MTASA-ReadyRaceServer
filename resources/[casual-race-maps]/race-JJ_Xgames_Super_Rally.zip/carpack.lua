function replaceModel() 
  txd = engineLoadTXD("car/club.txd", 429 )
  engineImportTXD(txd, 429)
  dff = engineLoadDFF("car/club.dff", 429 )
  engineReplaceModel(dff, 429)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)

addCommandHandler ( "reloadcar", replaceModel )