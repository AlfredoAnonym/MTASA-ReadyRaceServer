addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('Files/dsher.txd',true)
        engineImportTXD(txd, 288)
 
        local dff = engineLoadDFF('Files/dsher.dff', 0)
        engineReplaceModel(dff, 288)

	end 
)
