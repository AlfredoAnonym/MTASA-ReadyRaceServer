addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('files/mario.txd',true)
        engineImportTXD(txd, 2050)
 
        local dff = engineLoadDFF('files/mario.dff', 0)
        engineReplaceModel(dff, 2050)
 
        local col = engineLoadCOL('files/mario.col')
        engineReplaceCOL(col, 2050)
        engineSetModelLODDistance(2050, 4000)
    end
)