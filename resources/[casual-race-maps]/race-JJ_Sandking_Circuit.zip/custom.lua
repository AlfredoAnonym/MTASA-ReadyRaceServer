addEventHandler('onClientResourceStart', resourceRoot, 
function() 

outputChatBox ( "JJ productions")
local txd = engineLoadTXD('files/cross.txd',true)
        engineImportTXD(txd, 2053)

	
	local dff = engineLoadDFF('files/cross.dff', 0) 
	engineReplaceModel(dff, 2053)


	local col = engineLoadCOL('files/cross.col') 
	engineReplaceCOL(col, 2053)

		
	engineSetModelLODDistance(2053, 500)
end 
)