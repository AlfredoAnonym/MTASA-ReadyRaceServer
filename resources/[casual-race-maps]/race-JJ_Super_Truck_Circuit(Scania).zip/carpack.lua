function replaceModel() 
  txd = engineLoadTXD("car/club.txd", 403 )
  engineImportTXD(txd, 403)
  dff = engineLoadDFF("car/club.dff", 403 )
  engineReplaceModel(dff, 403)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)

addCommandHandler ( "reloadcar", replaceModel )