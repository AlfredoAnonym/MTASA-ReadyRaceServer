addEventHandler('onClientResourceStart', resourceRoot,
    function()
        outputChatBox ( "Only for test")
 
        local txd = engineLoadTXD('files/monaco1.txd',true)
        engineImportTXD(txd, 2052)
 
        local dff = engineLoadDFF('files/monaco1.dff', 0)
        engineReplaceModel(dff, 2052)
 
        local col = engineLoadCOL('files/monaco1.col')
        engineReplaceCOL(col, 2052)
        engineSetModelLODDistance(2052, 2000)
    end
)