--Shader cinema FL
--based on nyan resource by Gamesnert

local shader_cinema
--how many images are in shader_cinema folder (0 to 58)
local image_list     = 14
--The song to be played in sync with the movie
--local cinemamusic    = "shishi.mp3"
--define the milisecond gab between images (the higher value the slower animation)
local frequencyTic   = 30
--((image_list*frequencyTic)/1000) predicted "movie" length in sec,it should equal with sound length
--leave dem vars alone
local numberTex      = { }
local numberId       = 1
local getLastTick = getTickCount ( )
local getLastTock = getTickCount ( )
local totalTickCount,singleTickCount = 0,0
local frames,lastsec=0,0,0
local numberOd = image_list
--set the rotation angle
local radian=math.rad(0)
 
addEventHandler( "onClientResourceStart", getResourceRootElement( getThisResource()),
    function()
        -- Create shader
        shader_cinema, tec = dxCreateShader ( "texreptransform.fx" )
        if not shader_cinema then return end
        -- If the image is too bright, you can darken it
        dxSetShaderValue ( shader_cinema, "gBrighten", -0.25 )
        -- Set the angle, grayscaled, rgb
        dxSetShaderValue ( shader_cinema, "gRotAngle", radian )
        dxSetShaderValue ( shader_cinema, "gGrayScale", 0 )
        dxSetShaderValue ( shader_cinema, "gRedColor", 0 )
        dxSetShaderValue ( shader_cinema, "gGrnColor", 0 )
        dxSetShaderValue ( shader_cinema, "gBluColor", 0 )
        -- Set image alpha (1 max)
        dxSetShaderValue ( shader_cinema, "gAlpha", 1 )
        -- Set scrolling (san set negative and positive values)
        dxSetShaderValue ( shader_cinema, "gScrRig",  0)
        dxSetShaderValue ( shader_cinema, "gScrDow", 0)
        -- Scale and offset (don't need to change that)
        dxSetShaderValue ( shader_cinema, "gHScale", 1 )
        dxSetShaderValue ( shader_cinema, "gVScale", 1 )
        dxSetShaderValue ( shader_cinema, "gHOffset", 0 )
        dxSetShaderValue ( shader_cinema, "gVOffset", 0 ) 
        if not shader_cinema then
            outputChatBox( "Could not create shader. Please use debugscript 3" )
            return
        else
            engineApplyShaderToWorldTexture ( shader_cinema, "drvin_screen" )   
            if not loadCinemaTextures ( ) then
                outputChatBox ( "Loading textures failed")
                destroyElement ( shader_cinema )
                return
            end
            addEventHandler ( "onClientHUDRender", getRootElement (), renderScreen )
        end
    end
)

function loadCinemaTextures ( )
    -- Textures to load
for i = 0, image_list do
  local tex = dxCreateTexture ( "shader_cinema_images/"..i..".jpg" )        
   if not tex then
    unloadTextures ( )
    return false
    end
   table.insert ( numberTex, tex )
   end
  return true
end

function unloadTextures ( )
 for index, tex in ipairs ( numberTex ) do
 destroyElement ( tex )
 end
end

-- renders and counts frames
function renderScreen ( )
    if getTickCount ( ) - getLastTick < frequencyTic  then return end
    -- Play movie sound on first frame   
    if numberId <numberOd then 
----outputChatBox('Movie cycle: '..((getTickCount ( ) - getLastTock)/1000)..' s')
    getLastTock=getTickCount ( )
    --change seek position of the sound element
    play_sound()
    end
    if numberOd<image_list then 
    if ((getTickCount ( ) - getLastTick))-frequencyTic>0 then
    singleTickCount=((getTickCount ( ) - getLastTick)-frequencyTic)/(frequencyTic)
    totalTickCount=totalTickCount+singleTickCount
     if totalTickCount>1 then 
     numberId = numberId + math.floor(totalTickCount) 
-----outputChatBox('First frame ommited: '..numberId..' Frames total: '..math.floor(totalTickCount)) 
     totalTickCount=totalTickCount-math.floor(totalTickCount)   
     end 
    end
    end
    numberOd=numberId
    numberId = numberId + 1
    if numberId > #numberTex then
        numberId = numberId - #numberTex
    end
    getLastTick = getTickCount ( )
    if not numberTex [ numberId ] then return end
    dxSetShaderValue ( shader_cinema, "gTexture", numberTex [ numberId ] )      
end

function play_sound()
    local cinemasound =playSound3D(cinemamusic,111.3,1027,13.6, false)
  local music_length=getSoundLength (cinemasound)
  setSoundVolume(cinemasound,1)
  setSoundMaxDistance(cinemasound, 190)
----outputChatBox('Predicted mov cycle: '..((image_list*frequencyTic)/1000)..' s')
----outputChatBox('Predicted snd cycle: '..(music_length)..' s')
end
