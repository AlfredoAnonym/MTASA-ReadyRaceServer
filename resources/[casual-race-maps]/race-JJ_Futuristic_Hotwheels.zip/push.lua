marker = createMarker(4670.2001953125, -1065.2998046875, 512.29998779297, 'corona', 3.5, 255, 0, 0, 255)

function MarkerHit(player)
if getElementType(player) == 'player' then
local vehicle = getPedOccupiedVehicle(player)
if source == marker then
setElementVelocity(vehicle, 0, 1, 0)
setElementRotation(vehicle, 0, 0, 0)
end
end
end
addEventHandler('onClientMarkerHit', getRootElement(), MarkerHit)