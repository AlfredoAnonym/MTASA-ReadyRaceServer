addEventHandler('onClientResourceStart', resourceRoot,
    function()
    outputChatBox ( "hw loaded")
    local txd = engineLoadTXD('files/hw.txd',true)
    engineImportTXD(txd, 2050)
    engineImportTXD(txd, 2051) 
    engineImportTXD(txd, 2052)
    engineImportTXD(txd, 2053)
    engineImportTXD(txd, 2054)
    engineImportTXD(txd, 2055)
    engineImportTXD(txd, 2056)
    engineImportTXD(txd, 2057)
    
        local dff = engineLoadDFF('files/road.dff', 0)
        engineReplaceModel(dff, 2050)
 
        local col = engineLoadCOL('files/road.col')
        engineReplaceCOL(col, 2050)
        engineSetModelLODDistance(2050, 4000)

        local dff = engineLoadDFF('files/roadup.dff', 0)
        engineReplaceModel(dff, 2051)
 
        local col = engineLoadCOL('files/roadup.col')
        engineReplaceCOL(col, 2051)
        engineSetModelLODDistance(2051, 4000)
        
        local dff = engineLoadDFF('files/roaddown.dff', 0)
        engineReplaceModel(dff, 2052)
 
        local col = engineLoadCOL('files/roaddown.col')
        engineReplaceCOL(col, 2052)
        engineSetModelLODDistance(2052, 4000)
        
        local dff = engineLoadDFF('files/fire.dff', 0)
        engineReplaceModel(dff, 2053)
 
        local col = engineLoadCOL('files/fire.col')
        engineReplaceCOL(col, 2053)
        engineSetModelLODDistance(2053, 4000)

        local dff = engineLoadDFF('files/loop.dff', 0)
        engineReplaceModel(dff, 2054)
 
        local col = engineLoadCOL('files/loop.col')
        engineReplaceCOL(col, 2054)
        engineSetModelLODDistance(2054, 4000)

        local dff = engineLoadDFF('files/wall.dff', 0)
        engineReplaceModel(dff, 2055)
 
        local col = engineLoadCOL('files/wall.col')
        engineReplaceCOL(col, 2055)
        engineSetModelLODDistance(2055, 4000)       
       
        local dff = engineLoadDFF('files/vallaext.dff', 0)
        engineReplaceModel(dff, 2056)
 
        local col = engineLoadCOL('files/vallaext.col')
        engineReplaceCOL(col, 2056)
        engineSetModelLODDistance(2056, 4000)

        local dff = engineLoadDFF('files/vallaint.dff', 0)
        engineReplaceModel(dff, 2057)
 
        local col = engineLoadCOL('files/vallaint.col')
        engineReplaceCOL(col, 2057)
        engineSetModelLODDistance(2057, 4000)         
        
        end
)