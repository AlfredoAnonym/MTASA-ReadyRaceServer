-- DDC OMG generated script, PLACE IT SERVER-SIDE

function omg_deco()
  square6 = createObject(9126, 4734.7001953125, 15.39999961853, 401.10000610352, 0, 324, 348)
  omgMovesquare6(1)
  square = createObject(9126, 4670.5, -823.29998779297, 498.70001220703, 344.25, 0, 0)
  omgMovesquare(1)
  omg6266 = createObject(5992, 4604.2998046875, 117.69999694824, 280.5, 0, 0, 69.937438964844)
  omgMoveomg6266(1)
  square4 = createObject(9126, 4667.8999023438, -378.39999389648, 453.60000610352, 347.90985107422, 40.579833984375, 264.17022705078)
  omgMovesquare4(1)
  square2 = createObject(9126, 4670.3999023438, -814.5, 498.70001220703, 347.9098815918, 40.579833984375, 10.170257568359)
  omgMovesquare2(1)
  square5 = createObject(9126, 4667.8999023438, -378.39999389648, 453.60000610352, 347.90985107422, 40.579833984375, 264.17022705078)
  omgMovesquare5(1)
  decolight = createObject(5992, 4604.2998046875, 117.69999694824, 280.5, 0, 0, 69.937438964844)
  omgMovedecolight(1)
  square8 = createObject(9126, 4734.7001953125, 15.39999961853, 401.10000610352, 0, 324, 258)
  omgMovesquare8(1)
  square3 = createObject(9126, 4667.8999023438, -378.39999389648, 453.60000610352, 347.9098815918, 40.579833984375, 10.170257568359)
  omgMovesquare3(1)
  square7 = createObject(9126, 4734.7001953125, 15.39999961853, 401.10000610352, 0, 324, 348)
  omgMovesquare7(1)
end

function omgMovesquare6(point)
    moveObject(square6, 500, 4734.7001953125, 15.39999961853, 401.10000610352, 0, 0, 180)
    setTimer(moveObject, 500, 0, square6, 500, 4734.7001953125, 15.39999961853, 401.10000610352, 0, 0, 180)
end

function omgMovesquare(point)
    moveObject(square, 1000, 4670.5, -823.29998779297, 498.70001220703, 0, 180, 0)
    setTimer(moveObject, 1000, 0, square, 1000, 4670.5, -823.29998779297, 498.70001220703, 0, 180, 0)
end

function omgMoveomg6266(point)
    moveObject(omg6266, 500, 4604.2998046875, 117.69999694824, 280.5, 0, 0, -180)
    setTimer(moveObject, 500, 0, omg6266, 500, 4604.2998046875, 117.69999694824, 280.5, 0, 0, -180)
end

function omgMovesquare4(point)
    moveObject(square4, 1000, 4667.8999023438, -378.39999389648, 453.60000610352, 0, 0, 180)
    setTimer(moveObject, 1000, 0, square4, 1000, 4667.8999023438, -378.39999389648, 453.60000610352, 0, 0, 180)
end

function omgMovesquare2(point)
    moveObject(square2, 1000, 4670.3999023438, -814.5, 498.70001220703, 0, 180, 0)
    setTimer(moveObject, 1000, 0, square2, 1000, 4670.3999023438, -814.5, 498.70001220703, 0, 180, 0)
end

function omgMovesquare5(point)
    moveObject(square5, 1000, 4667.8999023438, -378.39999389648, 453.60000610352, 0, 0, -180)
    setTimer(moveObject, 1000, 0, square5, 1000, 4667.8999023438, -378.39999389648, 453.60000610352, 0, 0, -180)
end

function omgMovedecolight(point)
    moveObject(decolight, 500, 4604.2998046875, 117.69999694824, 280.5, 0, 0, 180)
    setTimer(moveObject, 500, 0, decolight, 500, 4604.2998046875, 117.69999694824, 280.5, 0, 0, 180)
end

function omgMovesquare8(point)
    moveObject(square8, 500, 4734.7001953125, 15.39999961853, 401.10000610352, 0, 0, -180)
    setTimer(moveObject, 500, 0, square8, 500, 4734.7001953125, 15.39999961853, 401.10000610352, 0, 0, -180)
end

function omgMovesquare3(point)
    moveObject(square3, 1000, 4667.8999023438, -378.39999389648, 453.60000610352, 0, 0, 180)
    setTimer(moveObject, 1000, 0, square3, 1000, 4667.8999023438, -378.39999389648, 453.60000610352, 0, 0, 180)
end

function omgMovesquare7(point)
    moveObject(square7, 500, 4734.7001953125, 15.39999961853, 401.10000610352, 0, 0, -180)
    setTimer(moveObject, 500, 0, square7, 500, 4734.7001953125, 15.39999961853, 401.10000610352, 0, 0, -180)
end

addEventHandler("onResourceStart", getResourceRootElement(getThisResource()), omg_deco)
