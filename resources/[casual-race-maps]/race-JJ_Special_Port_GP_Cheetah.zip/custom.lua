addEventHandler('onClientResourceStart', resourceRoot,
    function()
        outputChatBox ( "JJ Productions...")
 
        local txd = engineLoadTXD('files/textures.txd',true)
        engineImportTXD(txd, 2040)
        engineImportTXD(txd, 2041)
        engineImportTXD(txd, 2043)
        engineImportTXD(txd, 2044)
        engineImportTXD(txd, 2045)
        engineImportTXD(txd, 2046)
        engineImportTXD(txd, 2047)
        engineImportTXD(txd, 2048)
        engineImportTXD(txd, 2049)
        engineImportTXD(txd, 2050) 
  
        local dff = engineLoadDFF('files/curva90.dff', 0)
        engineReplaceModel(dff, 2040)
 
        local dff = engineLoadDFF('files/curva180.dff', 0)
        engineReplaceModel(dff, 2041)
        
        local dff = engineLoadDFF('files/jump.dff', 0)
        engineReplaceModel(dff, 2043)        
        
        local dff = engineLoadDFF('files/road.dff', 0)
        engineReplaceModel(dff, 2044)        
        
        local dff = engineLoadDFF('files/solar.dff', 0)
        engineReplaceModel(dff, 2045)        
        
        local dff = engineLoadDFF('files/spyral.dff', 0)
        engineReplaceModel(dff, 2046)        
        
        local dff = engineLoadDFF('files/tunnel.dff', 0)
        engineReplaceModel(dff, 2047)        
        
        local dff = engineLoadDFF('files/tunnelgrande.dff', 0)
        engineReplaceModel(dff, 2048)        
        
        local dff = engineLoadDFF('files/valla.dff', 0)
        engineReplaceModel(dff, 2049)
        
        local dff = engineLoadDFF('files/vallalarga.dff', 0)
        engineReplaceModel(dff, 2050)        
        
        local col = engineLoadCOL('files/curva90.col')
        engineReplaceCOL(col, 2040)
        engineSetModelLODDistance(2040, 4000)
        
        local col = engineLoadCOL('files/curva180.col')
        engineReplaceCOL(col, 2041)
        engineSetModelLODDistance(2041, 4000)        

        local col = engineLoadCOL('files/jump.col')
        engineReplaceCOL(col, 2043)
        engineSetModelLODDistance(2043, 4000)        
        
        local col = engineLoadCOL('files/road.col')
        engineReplaceCOL(col, 2044)
        engineSetModelLODDistance(2044, 4000)        
        
        local col = engineLoadCOL('files/solar.col')
        engineReplaceCOL(col, 2045)
        engineSetModelLODDistance(2045, 1000)        
        
        local col = engineLoadCOL('files/spyral.col')
        engineReplaceCOL(col, 2046)
        engineSetModelLODDistance(2046, 4000)        
        
        local col = engineLoadCOL('files/tunnel.col')
        engineReplaceCOL(col, 2047)
        engineSetModelLODDistance(2047, 4000)
        
        local col = engineLoadCOL('files/tunnelgrande.col')
        engineReplaceCOL(col, 2048)
        engineSetModelLODDistance(2048, 4000)                
                
        local col = engineLoadCOL('files/valla.col')
        engineReplaceCOL(col, 2049)
        engineSetModelLODDistance(2049, 4000)                
                
        local col = engineLoadCOL('files/vallalarga.col')
        engineReplaceCOL(col, 2050)
        engineSetModelLODDistance(2050, 4000)   
    end
)