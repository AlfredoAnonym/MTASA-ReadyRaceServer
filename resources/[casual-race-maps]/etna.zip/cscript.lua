local k = 0
function onResourceStartOrStop()
  for _,object in ipairs(getElementsByType("removeWorldObject",source)) do
    local model = getElementData(object,"model")
    local lodModel = getElementData(object,"lodModel") or 0
    local posX = getElementData(object,"posX")
    local posY = getElementData(object,"posY")
    local posZ = getElementData(object,"posZ")
    local radius = getElementData(object,"radius")
    if eventName == "onClientResourceStart" then
	removeWorldModel(model,radius,posX,posY,posZ,0)
	removeWorldModel(lodModel,radius,posX,posY,posZ,0)
    else
	restoreWorldModel(model,radius,posX,posY,posZ,0)
	restoreWorldModel(lodModel,radius,posX,posY,posZ,0)
    end
  end
  if eventName == "onClientResourceStart" then
    for i,object in ipairs(getElementsByType("object",source)) do
	local objID = getElementModel(object)
	local lodModel = LOD_MAP[objID]
	if lodModel then
	  if k > 2 then
	    local x,y,z = getElementPosition(object)
	    local rx,ry,rz = getElementRotation(object)
	    local lodObj = createObject(lodModel,x,y,z,rx,ry,rz,true)
	    if getElementData(object,"doublesided") then
		setElementDoubleSided(lodObj,true)
	    end
	    local scl = getElementData(object,"scale")
	    if scl then
		setObjectScale(lodObj,scl)
	    end
	    setElementParent(lodObj,object)
	    setLowLODElement(object,lodObj)
	    if k == 3 then
		k = 0
	    end
	  else
	    k = k + 1
	  end
	  engineSetModelLODDistance(objID,296)
	end
    end
  end
end
addEventHandler("onClientResourceStop",resourceRoot,
function()
  onResourceStartOrStop()
end)
addEventHandler("onClientResourceStart",resourceRoot,
function()
  setOcclusionsEnabled(false)
  engineImportTXD(engineLoadTXD("tags_lavagos.txd"),1530)
  engineReplaceCOL(engineLoadCOL("airportland1.col"),18005)
  engineImportTXD(engineLoadTXD("airportland.txd"),18005)
  engineReplaceModel(engineLoadDFF("airportland1.dff"),18005)
  engineReplaceCOL(engineLoadCOL("airportland6.col"),18006)
  engineImportTXD(engineLoadTXD("airportland.txd"),18006)
  engineReplaceModel(engineLoadDFF("airportland6.dff"),18006)
  engineReplaceCOL(engineLoadCOL("airportland9.col"),18007)
  engineImportTXD(engineLoadTXD("airportland.txd"),18007)
  engineReplaceModel(engineLoadDFF("airportland9.dff"),18007)
  engineSetModelLODDistance(647,224)
  engineSetModelLODDistance(673,160)
  engineSetModelLODDistance(700,256)
  engineSetModelLODDistance(736,256)
  engineSetModelLODDistance(789,256)
  engineSetModelLODDistance(978,256)
  engineSetModelLODDistance(979,256)
  engineSetModelLODDistance(1218,160)
  engineSetModelLODDistance(1225,160)
  engineSetModelLODDistance(1530,192)
  engineSetModelLODDistance(1638,160)
  engineSetModelLODDistance(1677,296)
  engineSetModelLODDistance(2971,160)
  engineSetModelLODDistance(3801,128)
  engineSetModelLODDistance(5450,160)
  engineSetModelLODDistance(6204,160)
  engineSetModelLODDistance(10079,192)
  engineSetModelLODDistance(10280,296)
  engineSetModelLODDistance(11428,296)
  engineSetModelLODDistance(11426,296)
  engineSetModelLODDistance(11433,256)
  engineSetModelLODDistance(11440,256)
  engineSetModelLODDistance(11442,256)
  engineSetModelLODDistance(11444,256)
  engineSetModelLODDistance(11447,256)
  engineSetModelLODDistance(11457,256)
  engineSetModelLODDistance(11459,256)
  engineSetModelLODDistance(14469,256)
  engineSetModelLODDistance(16601,296)
  engineSetModelLODDistance(17543,256)
  engineSetModelLODDistance(18088,296)
  local mr1 = createMarker(1162,900.7,9.5,"ring",7,252,32,32)
  setMarkerTarget(mr1,1218,987.1,5.8)
  local my1 = createMarker(1154,845.6,9.8,"ring",7,200,84,32)
  setMarkerTarget(my1,1340.6,926.4,16.9)
  local mr2 = createMarker(1208.3,2171.6,5.7,"ring",7,252,32,32)
  setMarkerTarget(mr2,1208.3,2279,5.7)
  local my2 = createMarker(1241.7,2191,5.7,"ring",7,200,84,32)
  setMarkerTarget(my2,1311.7,2287,11)
  local version = getVersion()
  if version.number > 340 then
    k = 4
    setFarClipDistance(1024)
  else
    setFarClipDistance(400)
  end
  onResourceStartOrStop()
  createBlip(1227,1298,7,27)
  createBlip(949,2595,11,27)
  createBlip(652,1729,6,53)
  createBlip(1208,1026,7,54)
  createBlip(1207,2285,7,54)
  createBlip(838,-1615,112,56)
end)
LOD_MAP = { [721]=721; [3285]=3300; [3601]=3727; [3608]=3730; [3639]=3718; [3640]=3719; [3641]=3721; [3642]=3720; [3644]=3645; [3655]=3656; [3673]=3682; [3820]=3831; [3822]=3883; [3824]=3835; [3825]=3841; [3827]=3838; [3828]=3837; [3829]=3839; [3830]=3836; [3845]=3846; [4563]=4566; [4603]=4581; [5033]=5055; [5520]=5671; [5740]=5957; [6048]=6131; [6100]=6107; [5642]=5613; [9680]=9681; [9900]=9900; [9901]=9963; [9918]=9945; [10377]=10525; [10398]=10319; [10736]=10884; [10951]=11020; [11425]=11668; [11427]=11670; [11436]=11669; [16055]=16379; [16056]=16383; [16057]=16382; [17538]=17932; [17853]=17856; [18005]=18005; [18006]=18006; [18007]=18007; [18241]=18533;
}
