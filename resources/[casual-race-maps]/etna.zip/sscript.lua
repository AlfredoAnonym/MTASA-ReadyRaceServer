local skins = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,19,66,67,96,133,159,162,181,292}
local drivers = {}
addEventHandler("onVehicleEnter",root,
function(driver)
  for i=1,#drivers do
    if drivers[i] == driver then
	return
    end
  end
  table.insert(drivers,driver)
  setclothes(driver)
  setcolor(source)
end)
addEventHandler("onResourceStart",resourceRoot,
function()
  setTimer(setTime,500,1,math.random(24),0)
end)
addEventHandler("onPlayerReachCheckpoint",root,
function(chk)
  if chk == 14 then
    setPlayerHudComponentVisible(source,"radar",true)
  end
end)
function setclothes(ped)
  local skin = skins[math.random(#skins)]
  if skin > 17 then
    setElementModel(ped,skin)
  else
    setElementModel(ped,0)
  if skin == 0 then
    addPedClothes(ped,"coachsemi","coach",0)
    addPedClothes(ped,"chinosblack","chinosb",2)
    addPedClothes(ped,"watchpro2","watch",14)
    addPedClothes(ped,"glasses03dark","glasses03",15)
    addPedClothes(ped,"boaterblk","boater",16)
  elseif skin == 1 then
    addPedClothes(ped,"moto","moto",16)
    addPedClothes(ped,"garageleg","garagetr",17)
  elseif skin == 2 then
    addPedClothes(ped,"bikerhelmet","bikerhelmet",16)
    addPedClothes(ped,"gimpleg","gimpleg",17)
  elseif skin == 3 then
    addPedClothes(ped,"trackytop1pro","trackytop1",0)
    addPedClothes(ped,"tracktrpro","tracktr",2)
    addPedClothes(ped,"helmet","helmet",16)
  elseif skin == 4 then
    addPedClothes(ped,"baldbeard","head",1)
    addPedClothes(ped,"glasses01","glasses01",15)
    addPedClothes(ped,"capknitgrn","capknit",16)
    addPedClothes(ped,"countrytr","countrytr",17)
  elseif skin == 5 then
    addPedClothes(ped,"sleevtbrown","sleevt",0)
    addPedClothes(ped,"worktrgrey","worktr",2)
    addPedClothes(ped,"cowboy","cowboy",16)
  elseif skin == 6 then
    addPedClothes(ped,"leather","leather",0)
    addPedClothes(ped,"baldtash","head",1)
    addPedClothes(ped,"leathertr","leathertr",2)
    addPedClothes(ped,"glasses03","glasses03",15)
  elseif skin == 7 then
    addPedClothes(ped,"jhericurl","jheri",1)
    addPedClothes(ped,"glasses04","glasses04",15)
    addPedClothes(ped,"croupier","valet",17)
  elseif skin == 8 then
    addPedClothes(ped,"denimfade","denim",0)
    addPedClothes(ped,"baldgoatee","head",1)
    addPedClothes(ped,"worktrgrey","worktr",2)
    addPedClothes(ped,"beretblk","beret",16)
  elseif skin == 9 then
    addPedClothes(ped,"tshirtproblk","tshirt",0)
    addPedClothes(ped,"suit1trblk2","suit1tr",2)
    addPedClothes(ped,"zorro","zorromask",15)
    addPedClothes(ped,"hatmancblk","hatmanc",16)
  elseif skin == 10 then
    addPedClothes(ped,"hawaiiwht","hawaii",0)
    addPedClothes(ped,"goatee","head",1)
    addPedClothes(ped,"chinosbiege","chinosb",2)
    addPedClothes(ped,"glasses03red","glasses03",15)
    addPedClothes(ped,"capzip","cap",16)
  elseif skin == 11 then
    addPedClothes(ped,"bald","head",1)
    addPedClothes(ped,"tracktrgang","tracktr",2)
    addPedClothes(ped,"watchsub1","watch",14)
    addPedClothes(ped,"bowler","bowler",16)
    addPedClothes(ped,"policetr","policetr",17)
  elseif skin == 12 then
    addPedClothes(ped,"tash","head",1)
    addPedClothes(ped,"bikerhelmet","bikerhelmet",16)
    addPedClothes(ped,"policetr","policetr",17)
  elseif skin == 13 then
    addPedClothes(ped,"stopwatch","neck",13)
    addPedClothes(ped,"glasses04","glasses04",15)
    addPedClothes(ped,"captruck","captruck",16)
    addPedClothes(ped,"medictr","medictr",17)
  elseif skin == 14 then
    addPedClothes(ped,"tash","head",1)
    addPedClothes(ped,"watchzip1","watch",14)
    addPedClothes(ped,"moto","moto",16)
    addPedClothes(ped,"medictr","medictr",17)
  elseif skin == 15 then
    addPedClothes(ped,"shirtayellow","shirta",0)
    addPedClothes(ped,"beard","head",1)
    addPedClothes(ped,"worktrkhaki","worktr",2)
    addPedClothes(ped,"watchzip2","watch",14)
    addPedClothes(ped,"glasses01dark","glasses01",15)
    addPedClothes(ped,"hattiger","cowboy",16)
  elseif skin == 16 then
    addPedClothes(ped,"bballjackrstar","bbjack",0)
    addPedClothes(ped,"baldgoatee","head",1)
    addPedClothes(ped,"denimsred","jeans",2)
    addPedClothes(ped,"neckgold","neck2",13)
    addPedClothes(ped,"glasses03blue","glasses03",15)
    addPedClothes(ped,"beretred","beret",16)
  elseif skin == 17 then
    addPedClothes(ped,"hoodyabase5","hoodya",0)
    addPedClothes(ped,"worktrcamogrn","worktr",2)
    addPedClothes(ped,"glasses05","glasses03",15)
    addPedClothes(ped,"skullygrn","skullycap",16)
    addPedClothes(ped,"balaclava","balaclava",17)
    end
  end
end
function setcolor(veh)
  local r = 256 - math.random(8)*math.random(16)
  local g = math.random(256-r,r)
  local b = math.random(g)
  local vc = math.random(3)
  if vc == 1 then
    setVehicleColor(veh,r,g,b,255,255,255,r,g,b)
  elseif vc == 2 then
    setVehicleColor(veh,r,g/3,b/4,r,g,b,r,g/2,b/3)
  else
    setVehicleColor(veh,r,g,b,r,g,b,255,255,255)
  end
end
