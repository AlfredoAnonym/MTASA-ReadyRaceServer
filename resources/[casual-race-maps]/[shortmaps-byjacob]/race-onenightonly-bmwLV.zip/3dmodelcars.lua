addEventHandler('onClientResourceStart', resourceRoot,
    function()
 
        local txd = engineLoadTXD('Files/sultan.txd',true)
        engineImportTXD(txd, 560)
 
        local dff = engineLoadDFF('Files/sultan.dff', 0)
        engineReplaceModel(dff, 560)

	end 
)
