function replaceModel() 
  txd = engineLoadTXD("car/club.txd", 549 )
  engineImportTXD(txd, 549)
  dff = engineLoadDFF("car/club.dff", 549 )
  engineReplaceModel(dff, 549)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)

addCommandHandler ( "reloadcar", replaceModel )