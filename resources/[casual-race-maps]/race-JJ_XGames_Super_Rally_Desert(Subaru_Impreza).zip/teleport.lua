addEvent('onPlayerReachCheckpoint', true)
addEventHandler('onPlayerReachCheckpoint', getRootElement(),
function(checkpoint)
        if checkpoint == 3 then
                outputChatBox ( "#FF0000Alien #FF0000teleport", getRootElement(), 255, 255, 255, true )
                x,y,z = getElementVelocity(getPedOccupiedVehicle(source))
                setElementPosition(getPedOccupiedVehicle(source), 537.40002441406, 1644.5999755859, 38.099998474121)
                setElementRotation(getPedOccupiedVehicle(source), 0, 0 , 32)
        end
end
)