-- FILE: customMapEditorScriptingExtension_s.lua
-- PURPOSE: Handle remove world objects (if present) and add lod models for custom objects (if enabled)
-- VERSION: 16/February/2025 , custom edit by LotsOfS

local resourceName = getResourceName(resource)

-- Makes removeWorldObject map entries and LODs work
local function onResourceStartOrStop(startedResource)
	local startEvent = eventName == "onResourceStart"
	local removeObjects = getElementsByType("removeWorldObject", source)

	for removeID = 1, #removeObjects do
		local objectElement = removeObjects[removeID]
		local objectModel = getElementData(objectElement, "model")
		local objectLODModel = getElementData(objectElement, "lodModel")
		local posX = getElementData(objectElement, "posX")
		local posY = getElementData(objectElement, "posY")
		local posZ = getElementData(objectElement, "posZ")
		local objectInterior = getElementData(objectElement, "interior") or 0
		local objectRadius = getElementData(objectElement, "radius")

		if startEvent then
			removeWorldModel(objectModel, objectRadius, posX, posY, posZ, objectInterior)
			removeWorldModel(objectLODModel, objectRadius, posX, posY, posZ, objectInterior)
		else
			restoreWorldModel(objectModel, objectRadius, posX, posY, posZ, objectInterior)
			restoreWorldModel(objectLODModel, objectRadius, posX, posY, posZ, objectInterior)
		end
	end

	if startEvent then
		local useLODs = get(resourceName..".useLODs")

		if useLODs then
			local objectsTable = getElementsByType("object", source)

			for objectID = 1, #objectsTable do
				local objectElement = objectsTable[objectID]
				local objectModel = getElementModel(objectElement)
				local lodModel = LOD_MAP[objectModel]

				if lodModel then
					local objectX, objectY, objectZ = getElementPosition(objectElement)
					local objectRX, objectRY, objectRZ = getElementRotation(objectElement)
					local objectInterior = getElementInterior(objectElement)
					local objectDimension = getElementDimension(objectElement)
					local objectAlpha = getElementAlpha(objectElement)
					local objectScale = getObjectScale(objectElement)

					local lodObject = createObject(lodModel, objectX, objectY, objectZ, objectRX, objectRY, objectRZ, true)

					if (lodObject) then
						setElementInterior(lodObject, objectInterior)
						setElementDimension(lodObject, objectDimension)
						setElementAlpha(lodObject, objectAlpha)
						setObjectScale(lodObject, objectScale)

						setElementParent(lodObject, objectElement)
						setLowLODElement(objectElement, lodObject)
					else
						iprint("[MapEditorScriptingExtension] failed to create lodObject " .. lodModel .. " for objectModel " .. objectModel)
					end
				end
			end
		end
	end
end
addEventHandler("onResourceStart", resourceRoot, onResourceStartOrStop, false)
addEventHandler("onResourceStop", resourceRoot, onResourceStartOrStop, false)

-- MTA LOD Table [object] = [lodmodel] 
LOD_MAP = {
	[10468] = 10339, -- roadssfs14 => lodroadssfs31 (SFs)
	[9707] = 9804, -- road_sfw26 => lodroads_sfw50 (SFw)
	[9708] = 9810, -- road_sfw27 => lodroads_sfw55 (SFw)
	[10471] = 10539, -- roadssfs27 => lodroadssfs15 (SFs)
	[9710] = 9806, -- road_sfw29 => lodroads_sfw52 (SFw)
	[18284] = 18550, -- cw_tscanopy => cw_tscanopy_lod (countryS)
	[10477] = 10541, -- roadssfs30 => lodroadssfs16 (SFs)
	[10478] = 10343, -- roadssfs24 => lodroadssfs14 (SFs)
	[8194] = 8195, -- vgsscorrag_fence01 => lodscorrag_fence01 (vegasS)
	[9958] = 10285, -- submarr_sfe => lodmarr_sfe (SFe)
	[5711] = 5984, -- cem02_law => lodcem02 (LaWn)
	[10483] = 10545, -- roadssfs36 => lodroadssfs22 (SFs)
	[10230] = 10141, -- freighter_sfe => lodighter2_sfe (SFe)
	[10866] = 11184, -- roadssfse16 => lodroadssfse16 (SFSe)
	[8947] = 8958, -- vgelkup => lodelockup_01 (vegasE)
	[10995] = 11045, -- mission_08_sfs => lod_sfs035 (SFSe)
	[8149] = 8274, -- vgsselecfence03 => lodselecfence03 (vegasS)
	[11124] = 11189, -- roadssfse71 => lodroadssfse71 (SFSe)
	[18312] = 18598, -- cs_landbit_23 => lod_cs_landbit_23 (countryS)
	[10999] = 11042, -- haightshop_sfs02 => lod_sfs032 (SFSe)
	[3414] = 3421, -- ce_oldhut1 => lodce_oldhut1 (countrye)
	[4199] = 4200, -- garages1_lan => lodgarages1_lan (LAn)
	[9605] = 9882, -- land_01_sfw => lod_land_01_sfw (SFw)
	[9606] = 9661, -- land_34_sfw => lodd_34_sfw (SFw)
	[10356] = 10679, -- hashbury_01_sfs => lodhbury_01_sfs (SFs)
	[3450] = 3538, -- vegashseplot1 => lodashseplot1 (vegasW)
	[9595] = 9537, -- tempbuild_sfw22 => lodpbuild_sfw22 (SFw)
	[9737] = 9768, -- blokmod3_sfw69 => lodkmod3_sfw69 (SFw)
	[6228] = 6243, -- canalbrij02_law => lodcanbrij02_law (LAw)
	[13295] = 13298, -- ce_terminal1 => lodce_terminal1 (countrye)
	[8077] = 8115, -- vgsfrates06 => lodfrates06 (vegasS)
	[9741] = 9757, -- blokmod1_sfwc => lodkmod1_sfwc (SFw)
	[11012] = 11270, -- crackfact_sfs => lodcrackfact_sfs (SFSe)
	[6872] = 7115, -- vgn_corpbuild1 => lod_corpbuild1 (vegasN)
	[9547] = 9771, -- blokcut_sfw04 => lodkcut_sfw04 (SFw)
	[4832] = 4948, -- airtwer_las => lodtwer_las01 (LAs)
	[7191] = 7195, -- vegasnnewfence2b => lodasnnewfence2b (vegasN)
	[10763] = 10884, -- controltower_sfse => lodtroltower_sfse (SFSe)
	[3866] = 3869, -- demolish1_sfxrf => loddemolish1_sfxrf (SFSe)
	[5986] = 5989, -- chateau01_lawn => lodteau_lawn (LaWn)
	[9496] = 9543, -- sboxbld4_sfw02 => lodxbld4_sfw02 (SFw)
	[6928] = 6936, -- vegasplant03 => lodasplant03 (vegasN)
	[9498] = 9542, -- sboxbld4_sfw70 => lodxbld4_sfw70 (SFw)
	[8483] = 8782, -- pirateland02_lvs => lodateland02_lvs (vegasE)
	[5036] = 5037, -- btoland1ct_las => lodland1ct_las (LAs)
	[10390] = 10509, -- mission_12_sfs => lod_sfs043 (SFs)
	[10618] = 10656, -- lastbit_02_sfs => lodtbit_02_sfs (SFs)
	[10138] = 10219, -- road46_sfe => lodd46_sfe (SFe)
	[10139] = 10218, -- road47_sfe => lodd47_sfe (SFe)
	[10775] = 10796, -- bigfactory_sfse => lod_sfs080e (SFSe)
	[9732] = 9791, -- road_sfw50 => lodroads_sfw37 (SFw)
	[10904] = 10906, -- sf_landbut01 => lodsfandbut201 (SFSe)
	[791] = 785, -- vbg_fir_copse => lod_vbg_fir_co (countrye)
	[8493] = 8977, -- pirtshp01_lvs => lodtshp01_lvs (vegasE)
	[5145] = 5235, -- sanpdmdock2_las2 => lodpdmdock2_las2 (LAs2)
	[9765] = 9548, -- blokcut_sfw03 => lodkmod3_sfw03 (SFw)
	[8832] = 9107, -- pirtebrdg01_lvs => lodtebrdg01_lvs (vegasE)
	[10630] = 10670, -- queens_10_sfs => lodens_10_sfs (SFs)
	[6313] = 6402, -- beacliff01_law2 => lodcliff01_law2 (LAw2)
	[17124] = 17392, -- cuntwland58b => lodcuntw37 (countryw)
	[10631] = 10659, -- ammunation_sfs => lodunation_sfs (SFs)
	[6356] = 6494, -- sunset06_law2 => lodset06_law2 (LAw2)
	[8883] = 8963, -- vgsefrght01 => lodefrght01 (vegasE)
	[3867] = 3868, -- ws_scaffolding_sfx => lodscaffolding_sfx (SFSe)
	[6443] = 6445, -- beacliff02_law2 => lodcliff02_law2 (LAw2)
	[4058] = 4062, -- fighotblok2_lan => lodfighotblok2_lan (LAn)
	[10458] = 10529, -- roadssfs04 => lodroadssfs18 (SFs)
	[10031] = 10006, -- landshit_24_sfe => loda72 (SFe)
	[9524] = 9532, -- blokmod1_sfw => lodkmod1_sfw (SFw)
	[10795] = 11329, -- car_ship_05_sfse => lod_carship05 (SFSe)
	[5176] = 5237, -- sanpdmdocka_las2 => lodpdmdocka_las2 (LAs2)
	[3330] = 3333, -- cxrf_brigleg => cxrf_lodbriglg (countn2)
	[6232] = 6245, -- canal_arch => lodcanal_arch (LAw)
	[10951] = 11020, -- shoppie3_sfs => lod_sfs006 (SFSe)
	[6448] = 6452, -- pier01_law2 => lodr01_law2 (LAw2)
	[8885] = 8961, -- vgsefrght03 => lodefrght03 (vegasE)
	[6449] = 6453, -- pier02_law2 => lodr02_law2 (LAw2)
	[10793] = 11330, -- car_ship_03_sfse => lodcarship_03 (SFSe)
	[3749] = 3750, -- clubgate01_lax => lodbgate01_lax (LAw2)
	[5244] = 5305, -- lasntrk1im03 => lodlasntrk1im (LAs2)
	[6959] = 7343, -- vegasnbball1 => lodasnbball1 (vegasN)
	[9918] = 9945, -- posh2_sfe => loda13 (SFe)
	[8649] = 8986, -- shbbyhswall05_lvs => lodbyhswall05_lvs (vegasE)
	[10428] = 10513, -- hashblock1_02_sfs => lod_sfs050 (SFs)
	[6961] = 7132, -- vgsnwedchap3 => lodnwedchap3 (vegasN)
	[6390] = 6392, -- sanclifft04_law2 => lodclifft04_law2 (LAw2)
	[10050] = 9994, -- vicstuff_sfe50 => loda58 (SFe)
	[10794] = 11331, -- car_ship_04_sfse => lod_carshipbase (SFSe)
	[3434] = 3482, -- skllsgn01_lvs => lodlsgn01_lvs (vegasE)
	[8656] = 8996, -- shbbyhswall09_lvs => lodbyhswall09_lvs (vegasE)
	[3625] = 3769, -- crgostntrmp => lodostntrmp (LAs)
	[17950] = 17952, -- cjsaveg => lodcjsaveg (LAe2)
	[11326] = 11328, -- sfse_hublockup => lod_hublockup (SFSe)
	[3715] = 3716, -- arch_sign => lodarch_sign (LAe2)
	[10439] = 10518, -- hashbury_08_sfs => lod_sfs055 (SFs)
	[3620] = 3746, -- redockrane_las => lodredockrane_las (LAs2)
	[6306] = 6471, -- roads24_law2 => lodds24_law2 (LAw2)
	[13871] = 13873, -- lahills_border1 => lodlahills_border1 (LAhills)
	[3627] = 3686, -- dckcanpy => lod_dckcanpy (LAs2)
	[3820] = 3831, -- box_hse_09_sfxrf => lod_hse_09_sfxrf (SFs)
	[9901] = 9963, -- ferybuild_1 => loda20 (SFe)
	[6398] = 6401, -- beacliff06_law2 => lodcliff06_law2 (LAw2)
	[6388] = 6395, -- sanclifft02_law2 => lodclifft02_law2 (LAw2)
	[9919] = 9937, -- grnwhite_sfe => loda03 (SFe)
	[4603] = 4581, -- sky4plaz2_lan => lod4plaz2_lan (LAn2)
	[12990] = 13483, -- sw_jetty => lodsw_jetty (countrye)
	[13237] = 13240, -- cuntehil03 => lodcuntehil03 (countrye)
	[1267] = 1261, -- billbd2 => lodlbd2 (LAe)
	[11088] = 11282, -- cf_ext_dem_sfs => lodext_dem_sfs (SFSe)
	[10827] = 10897, -- subbunker_ext_sfse => lodbunker_ext_sfse (SFSe)
	[8678] = 8777, -- wdngchplgrnd01_lvs => lodgchplgrnd01_lvs (vegasE)
	[7102] = 7169, -- plantbox12 => lodntbox12 (vegasN)
	[9950] = 10158, -- pier2_sfe => loda74 (SFe)
	[10840] = 10912, -- bigshed_sfse => lodbigshed_sfse (SFSe)
	[11095] = 11350, -- stadbridge_sfs => lod_stadbridge_sfs (SFSe)
	[6342] = 6475, -- century01_law2 => lodtury01_law2 (LAw2)
	[4730] = 4758, -- billbrdlan2_03 => lodbillbrdlan2_03 (LAn2)
	[3886] = 3880, -- ws_jettynol_sfx => lodws_jetty_sfx (SFSe)
	[10971] = 11064, -- roadssfse31 => lodroadssfse31 (SFSe)
	[3569] = 3747, -- lasntrk3 => lodlasntrk3 (LAs2)
	[10847] = 10913, -- gen_whouse03_sfse01 => lodwhouse03_sfse01 (SFSe)
	[694] = 784, -- sm_redwoodgrp => lod_redwoodgrp (countryS)
	[3887] = 3888, -- demolish4_sfxrf => loddemolish4_sfxrf (SFSe)
}