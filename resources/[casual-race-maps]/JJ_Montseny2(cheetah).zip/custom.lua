addEventHandler('onClientResourceStart', resourceRoot,
    function()
        outputChatBox ( "Test")
 
        local txd = engineLoadTXD('files/mario.txd',true)
        engineImportTXD(txd, 2053)
 
        local dff = engineLoadDFF('files/mario.dff', 0)
        engineReplaceModel(dff, 2053)
 
        local col = engineLoadCOL('files/mario.col')
        engineReplaceCOL(col, 2053)
        engineSetModelLODDistance(2053, 500)
    end
)