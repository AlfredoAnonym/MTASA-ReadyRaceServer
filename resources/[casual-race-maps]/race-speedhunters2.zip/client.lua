
--------------
-- vehicles --
--------------


addEventHandler("onClientResourceStart",resourceRoot,
	function ()
		for i,vehicle in ipairs (getElementsByType ("vehicle")) do
			if not getVehicleController (vehicle) then
				setVehicleOverrideLights (vehicle, 2)
				setVehicleEngineState (vehicle, true)
				setVehicleSirensOn (vehicle, true) 
				setElementData (vehicle, "race.collideothers", 1)
			end
		end
	end
)

-----------------
-- Disable Col --
-----------------

	addEventHandler("onClientResourceStart",resourceRoot,
		function ()
			for i,obj in ipairs (getElementsByType("object")) do
				if getElementModel(obj) == 3437 then
					setElementCollisionsEnabled (obj, false)
				end

				if getElementModel(obj) == 2960 then
					setElementCollisionsEnabled (obj, false)
				end
			end
		end
	)


--
dft01 = createVehicle (578, -1530, 720, 7.9, 0, 0, 270)
dftobj01a = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj01b = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj01c = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj01d = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj01e = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj01f = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj01g = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj01h = createObject (2960, 0, 0, 0, 0, 0, 0)

dftobj01i = createObject (1649, 0, 0, 0, 0, 0, 0)
setElementDoubleSided (dftobj01i, true)
dftobj01j = createObject (1649, 0, 0, 0, 0, 0, 0)
setElementDoubleSided (dftobj01j, true)

attachElements (dftobj01a, dft01, 0, 1.3, 2.1, 0, 90, 0)
attachElements (dftobj01b, dft01, 0, 1, 2.1, 0, 90, 0)
attachElements (dftobj01c, dft01, 0, -3.8, 2.1, 0, 90, 0)
attachElements (dftobj01d, dft01, 0, -4.1, 2.1, 0, 90, 0)
attachElements (dftobj01e, dft01, 0, -1.4, -0.04, 90, 0, 90)
attachElements (dftobj01f, dft01, 0, -1.4, 0.33, 90, 0, 90)
attachElements (dftobj01g, dft01, 0, -1.4, 3.83, 90, 0, 90)
attachElements (dftobj01h, dft01, 0, -1.4, 4.204, 90, 0, 90)

attachElements (dftobj01i, dft01, -0.35, -1.4, 2.1, 0, 0, 90)
attachElements (dftobj01j, dft01, 0.06, -1.4, 2.1, 0, 0, 90)

--

dft02 = createVehicle (578, -1530, 725, 7.9, 0, 0, 270)
dftobj02a = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj02b = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj02c = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj02d = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj02e = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj02f = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj02g = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj02h = createObject (2960, 0, 0, 0, 0, 0, 0)


dftobj02i = createObject (1649, 0, 0, 0, 0, 0, 0)
setElementDoubleSided (dftobj02i, true)
dftobj02j = createObject (1649, 0, 0, 0, 0, 0, 0)
setElementDoubleSided (dftobj02j, true)

attachElements (dftobj02a, dft02, 0, 1.3, 2.1, 0, 90, 0)
attachElements (dftobj02b, dft02, 0, 1, 2.1, 0, 90, 0)
attachElements (dftobj02c, dft02, 0, -3.8, 2.1, 0, 90, 0)
attachElements (dftobj02d, dft02, 0, -4.1, 2.1, 0, 90, 0)
attachElements (dftobj02e, dft02, 0, -1.4, -0.04, 90, 0, 90)
attachElements (dftobj02f, dft02, 0, -1.4, 0.33, 90, 0, 90)
attachElements (dftobj02g, dft02, 0, -1.4, 3.83, 90, 0, 90)
attachElements (dftobj02h, dft02, 0, -1.4, 4.204, 90, 0, 90)

attachElements (dftobj02i, dft02, -0.35, -1.4, 2.1, 0, 0, 90)
attachElements (dftobj02j, dft02, 0.06, -1.4, 2.1, 0, 0, 90)

--

dft03 = createVehicle (578, -1530, 730, 7.9, 0, 0, 270)
dftobj03a = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj03b = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj03c = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj03d = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj03e = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj03f = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj03g = createObject (2960, 0, 0, 0, 0, 0, 0)
dftobj03h = createObject (2960, 0, 0, 0, 0, 0, 0)

dftobj03i = createObject (1649, 0, 0, 0, 0, 0, 0)
setElementDoubleSided (dftobj03i, true)
dftobj03j = createObject (1649, 0, 0, 0, 0, 0, 0)
setElementDoubleSided (dftobj03j, true)

attachElements (dftobj03a, dft03, 0, 1.3, 2.1, 0, 90, 0)
attachElements (dftobj03b, dft03, 0, 1, 2.1, 0, 90, 0)
attachElements (dftobj03c, dft03, 0, -3.8, 2.1, 0, 90, 0)
attachElements (dftobj03d, dft03, 0, -4.1, 2.1, 0, 90, 0)
attachElements (dftobj03e, dft03, 0, -1.4, -0.04, 90, 0, 90)
attachElements (dftobj03f, dft03, 0, -1.4, 0.33, 90, 0, 90)
attachElements (dftobj03g, dft03, 0, -1.4, 3.83, 90, 0, 90)
attachElements (dftobj03h, dft03, 0, -1.4, 4.204, 90, 0, 90)

attachElements (dftobj03i, dft03, -0.35, -1.4, 2.1, 0, 0, 90)
attachElements (dftobj03j, dft03, 0.06, -1.4, 2.1, 0, 0, 90)

--

train01 = createVehicle (538, -1543.7, 751.5, 8.5, 0, 0, 0)
	setTrainDirection (train01, false)
train02 = createVehicle (569, -1543.7, 769.1, 8.5, 0, 0, 0)
	setTrainDirection (train02, false)
train03 = createVehicle (569, -1538.6, 787.2, 8.5, 0, 0, 0)
	setTrainDirection (train03, false)
train04 = createVehicle (569, -1538.6, 805.3, 8.5, 0, 0, 0)
	setTrainDirection (train04, false)
boat01 = createVehicle (452, 0, 0, 0, 0, 0, 0)
boat02 = createVehicle (446, 0, 0, 0, 0, 0, 0)

attachElements (boat01, train02, 0, 0, -0.5, 0, 0, 0)
attachElements (boat02, train03, 0, 0, -0.5, 0, 0, 0)


-----------------
-- Moving Boat --
-----------------

boatobj01 = createObject (1337, -1498.2, 816.2, 30.3, 0, 0, 350)
boatobj02 = createObject (1337, -1507, 766.4, 30.3, 0, 0, 350)
boatobj03 = createObject (1337, -1502, 773, 8, 0, 0, 0)
	attachElements (boatobj03, boatobj02, 0, 0, -17.8, 0, 0, 0)
boatobj04 = createObject (1337, -1502, 773, 8, 0, 0, 0)
	attachElements (boatobj04, boatobj02, -8, 0, -20.5, 0, 0, 0)
boatobj05 = createObject (1337, -1502, 773, 8, 0, 0, 0)
	attachElements (boatobj05, boatobj02, 2.3, 0, -20.7, 0, 0, 0)
boat03 = createVehicle (493, -1502, 773, 8, 0, 0, 0)
	attachElements (boat03, boatobj02, 0, 0, -21.7, 0, 0, 90)

setElementCollisionsEnabled (boatobj01, false)
setElementCollisionsEnabled (boatobj02, false)
setElementCollisionsEnabled (boatobj03, false)
setElementCollisionsEnabled (boatobj04, false)
setElementCollisionsEnabled (boatobj05, false)

setElementAlpha (boatobj01, 0)
setElementAlpha (boatobj02, 0)
setElementAlpha (boatobj03, 0)
setElementAlpha (boatobj04, 0)
setElementAlpha (boatobj05, 0)


function startMoveBoat ()

	moveObject (boatobj02, 3600, -1507, 766.4, 30.3, 0, 20, 0)
	setTimer (moveBoat01, 3600, 1)

end
addEventHandler ("onClientResourceStart", resourceRoot, startMoveBoat)

function moveBoat01 ()
	moveObject (boatobj02, 7200, -1507, 766.4, 30.3, 0, -40, 0)
	setTimer (moveBoat02, 7200, 1)
end

function moveBoat02 ()
	moveObject (boatobj02, 7200, -1507, 766.4, 30.3, 0, 40, 0)
	setTimer (moveBoat01, 7200, 1)
end


----------------
-- Moving Box --
----------------

boxobj01 = createObject (1337, -1694.8, 188.8, 31.5, 0, 0, 0)
boxobj02 = createObject (1337, -1694.8, 188.8, 13.5, 0, 0, 0)
	attachElements (boxobj02, boxobj01, 0, 0, -18, 0, 0, 0)
boxobj03 = createObject (2932, -1694.8, 188.8, 9, 0, 0, 0)
	attachElements (boxobj03, boxobj01, 0, 0, -22.5, 0, 0, 0)

boxobj04 = createObject (1337, -1696.3, 185.4, 10.3, 0, 0, 0)
boxobj05 = createObject (1337, -1693.3, 185.4, 10.3, 0, 0, 0)
boxobj06 = createObject (1337, -1696.3, 192.2, 10.3, 0, 0, 0)
boxobj07 = createObject (1337, -1693.3, 192.2, 10.3, 0, 0, 0)
	attachElements (boxobj04, boxobj01, -1.5, -3.4, -21.2, 0, 0, 0)
	attachElements (boxobj05, boxobj01, 1.5, -3.4, -21.2, 0, 0, 0)
	attachElements (boxobj06, boxobj01, -1.5, 3.4, -21.2, 0, 0, 0)
	attachElements (boxobj07, boxobj01, 1.5, 3.4, -21.2, 0, 0, 0)

setElementCollisionsEnabled (boxobj01, false)
setElementCollisionsEnabled (boxobj02, false)
setElementCollisionsEnabled (boxobj04, false)
setElementCollisionsEnabled (boxobj05, false)
setElementCollisionsEnabled (boxobj06, false)
setElementCollisionsEnabled (boxobj07, false)

setElementAlpha (boxobj01, 0)
setElementAlpha (boxobj02, 0)
setElementAlpha (boxobj04, 0)
setElementAlpha (boxobj05, 0)
setElementAlpha (boxobj06, 0)
setElementAlpha (boxobj07, 0)



function startMoveBox ()

	moveObject (boxobj01, 3600, -1694.8, 188.8, 31.5, 0, 20, 0)
	setTimer (moveBox01, 3600, 1)

end
addEventHandler ("onClientResourceStart", resourceRoot, startMoveBox)

function moveBox01 ()
	moveObject (boxobj01, 7200, -1694.8, 188.8, 31.5, 0, -40, 0)
	setTimer (moveBox02, 7200, 1)
end

function moveBox02 ()
	moveObject (boxobj01, 7200, -1694.8, 188.8, 31.5, 0, 40, 0)
	setTimer (moveBox01, 7200, 1)
end

-----------
-- Wires --
-----------

function createWires ()
	--Boat
	xbo01, ybo01, zbo01 = getElementPosition (boatobj01)
	xbo02, ybo02, zbo02 = getElementPosition (boatobj02)
	xbo03, ybo03, zbo03 = getElementPosition (boatobj03)
	xbo04, ybo04, zbo04 = getElementPosition (boatobj04)
	xbo05, ybo05, zbo05 = getElementPosition (boatobj05)
	dxDrawLine3D (xbo01, ybo01, zbo01, xbo02, ybo02, zbo02, tocolor (84, 84, 84, 255), 5)
	dxDrawLine3D (xbo02, ybo02, zbo02, xbo03, ybo03, zbo03, tocolor (84, 84, 84, 255), 5)
	dxDrawLine3D (xbo03, ybo03, zbo03, xbo04, ybo04, zbo04, tocolor (84, 84, 84, 255), 5)
	dxDrawLine3D (xbo03, ybo03, zbo03, xbo05, ybo05, zbo05, tocolor (84, 84, 84, 255), 5)

	--Box
	xbox01, ybox01, zbox01 = getElementPosition (boxobj01)
	xbox02, ybox02, zbox02 = getElementPosition (boxobj02)
	xbox04, ybox04, zbox04 = getElementPosition (boxobj04)
	xbox05, ybox05, zbox05 = getElementPosition (boxobj05)
	xbox06, ybox06, zbox06 = getElementPosition (boxobj06)
	xbox07, ybox07, zbox07 = getElementPosition (boxobj07)
	dxDrawLine3D (xbox01, ybox01, zbox01, xbox02, ybox02, zbox02, tocolor (84, 84, 84, 255), 5)
	dxDrawLine3D (xbox04, ybox04, zbox04, xbox02, ybox02, zbox02, tocolor (84, 84, 84, 255), 5)
	dxDrawLine3D (xbox05, ybox05, zbox05, xbox02, ybox02, zbox02, tocolor (84, 84, 84, 255), 5)
	dxDrawLine3D (xbox06, ybox06, zbox06, xbox02, ybox02, zbox02, tocolor (84, 84, 84, 255), 5)
	dxDrawLine3D (xbox07, ybox07, zbox07, xbox02, ybox02, zbox02, tocolor (84, 84, 84, 255), 5)

	--Line
	dxDrawLine3D (-1545, 1065, 6.5, -1572.54, 1065, 6.5, tocolor (0, 255, 255, 255), 20)
	dxDrawLine3D (-1545, 1065, 7, -1572.54, 1065, 7, tocolor (0, 255, 255, 255), 20)
	dxDrawLine3D (-1545, 1065, 7.5, -1572.54, 1065, 7.5, tocolor (0, 255, 255, 255), 20)

	dxDrawLine3D (-1625, 1065, 6.5, -1596.85, 1065, 6.5, tocolor (0, 255, 255, 255), 20)
	dxDrawLine3D (-1625, 1065, 7, -1596.85, 1065, 7, tocolor (0, 255, 255, 255), 20)
	dxDrawLine3D (-1625, 1065, 7.5, -1596.85, 1065, 7.5, tocolor (0, 255, 255, 255), 20)

	dxDrawLine3D (-2785.1, -475.6, 6.3, -2796.5, -491.2, 6.3, tocolor (255, 80, 60, 255), 20)
	dxDrawLine3D (-2785.1, -475.6, 6.8, -2796.5, -491.2, 6.8, tocolor (255, 80, 60, 255), 20)

	dxDrawLine3D (-2795.2, -467.6, 6.3, -2807.1, -484, 6.3, tocolor (255, 80, 60, 255), 20)
	dxDrawLine3D (-2795.2, -467.6, 6.8, -2807.1, -484, 6.8, tocolor (255, 80, 60, 255), 20)

end
addEventHandler("onClientRender", getRootElement(), createWires)

-----------
-- Train --
-----------

traincol01 = createColCuboid (-1755, -103.5, 2, 30, 10, 10)
function train01 (theElement, matchingDimensions)
	if theElement == getLocalPlayer() then

		train01a = createVehicle (537, -1768, -33.3, 5)
			setTrainDerailable (train01a , false)
			setTrainDirection (train01a, false)
			setVehicleOverrideLights (train01a, 2)
			setVehicleEngineState (train01a, true)
			setElementData (train01a, "race.collideothers", 1)
        		setTimer (setTrainSpeed, 100, 250, train01a, -0.4)

		train01b = createVehicle (569, -1786, -35.5, 6.5)
			setTrainDerailable (train01b , false)
			setTrainDirection (train01b, false)
			setVehicleOverrideLights (train01b, 2)
			setVehicleEngineState (train01b, true)
			setElementData (train01b, "race.collideothers", 1)
        		setTimer (setTrainSpeed, 100, 250, train01b, -0.4)

		train01c = createVehicle (590, -1804, -35.5, 7.5)
			setTrainDerailable (train01c , false)
			setTrainDirection (train01c, false)
			setVehicleOverrideLights (train01c, 2)
			setVehicleEngineState (train01c, true)
			setElementData (train01c, "race.collideothers", 1)
        		setTimer (setTrainSpeed, 100, 250, train01c, -0.4)

		setTimer (destroyElement, 30000, 1, train01a)
		setTimer (destroyElement, 30000, 1, train01b)
		setTimer (destroyElement, 30000, 1, train01c)

	end
end
addEventHandler("onClientColShapeHit", traincol01, train01)