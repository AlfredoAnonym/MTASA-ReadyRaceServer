local myShader
addEventHandler( "onClientResourceStart", resourceRoot,function()
	if getVersion ().sortable < "1.1.0" then
		return
	end
	local tec
	myShader, tec = dxCreateShader ( "tex_names.fx" )
		if not myShader then
	else
		engineApplyShaderToWorldTexture ( myShader, "ballywall01_64" )
	end
end)
