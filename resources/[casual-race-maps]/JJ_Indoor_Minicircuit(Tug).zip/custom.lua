addEventHandler('onClientResourceStart', resourceRoot,
    function()
        outputChatBox ( "Indoor loaded")
 
        local txd = engineLoadTXD('files/indoor.txd',true)
        engineImportTXD(txd, 2053)
 
        local dff = engineLoadDFF('files/indoor.dff', 0)
        engineReplaceModel(dff, 2053)
 
        local col = engineLoadCOL('files/indoor.col')
        engineReplaceCOL(col, 2053)
        engineSetModelLODDistance(2053, 500)
    end
)