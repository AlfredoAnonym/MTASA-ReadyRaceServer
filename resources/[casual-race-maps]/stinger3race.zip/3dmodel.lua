addEventHandler('onClientResourceStart', resourceRoot,
    function()

txd = engineLoadTXD ( "Files/banshee.txd" )	engineImportTXD ( txd, 429 )

dff = engineLoadDFF ( "Files/banshee.dff", 0 )   engineReplaceModel ( dff, 429 )
	end 
)
