local models = {1412, 1413}

addEventHandler("onClientResourceStart",resourceRoot,
	function()
		for _,model in pairs(models) do
			removeWorldModel(model, 50000, 0, 0, 0)
		end
		
	end
)

addEventHandler("onClientResourceStop",resourceRoot,
	function()
		for _,model in pairs(models) do
			restoreWorldModel(model, 50000, 0, 0, 0)
		end
		
	end
)